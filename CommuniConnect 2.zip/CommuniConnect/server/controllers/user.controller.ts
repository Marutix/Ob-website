import { Request, Response } from 'express';
import { storage } from '../storage';
import { hashSync } from 'bcryptjs';

// Get current user profile
export const getCurrentUser = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Get user's servers
    const servers = await storage.getServersByUser(userId);
    
    // Get user's DM channels
    const dmChannels = await storage.getDmChannelsByUser(userId);
    
    // Map DM channels to include the other user
    const dmChannelsWithUsers = await Promise.all(dmChannels.map(async (dmChannel) => {
      const dmMembers = await Promise.all(
        Array.from(new Array(2)).map(async (_, i) => {
          const key = `${dmChannel.id}-${i+1}`;
          const memberId = i+1; // This is simplified, actual implementation would be different
          return await storage.getUser(memberId);
        })
      );
      
      // Filter out current user to get the other user
      const otherUsers = dmMembers.filter(user => user && user.id !== userId);
      
      return {
        ...dmChannel,
        users: otherUsers
      };
    }));
    
    return res.status(200).json({
      user: {
        id: user.id,
        username: user.username,
        discriminator: user.discriminator,
        email: user.email,
        avatar: user.avatar,
        banner: user.banner,
        bio: user.bio,
        status: user.status,
        verified: user.verified,
        mfaEnabled: user.mfaEnabled,
        createdAt: user.createdAt,
        locale: user.locale
      },
      servers,
      dmChannels: dmChannelsWithUsers
    });
  } catch (error) {
    console.error("Get current user error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Update user profile
export const updateProfile = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { username, bio, avatar, banner, locale } = req.body;
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Update user data
    const updatedData: any = {};
    if (username) updatedData.username = username;
    if (bio !== undefined) updatedData.bio = bio;
    if (avatar) updatedData.avatar = avatar;
    if (banner) updatedData.banner = banner;
    if (locale) updatedData.locale = locale;
    
    const updatedUser = await storage.updateUser(userId, updatedData);
    
    return res.status(200).json({
      message: "Profile updated successfully",
      user: {
        id: updatedUser!.id,
        username: updatedUser!.username,
        discriminator: updatedUser!.discriminator,
        email: updatedUser!.email,
        avatar: updatedUser!.avatar,
        banner: updatedUser!.banner,
        bio: updatedUser!.bio,
        status: updatedUser!.status,
        locale: updatedUser!.locale
      }
    });
  } catch (error) {
    console.error("Update profile error:", error);
    return res.status(500).json({ message: "An error occurred while updating profile" });
  }
};

// Update user password
export const updatePassword = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: "Current password and new password are required" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Verify current password
    const bcrypt = require('bcryptjs');
    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }
    
    // Hash and update new password
    const hashedPassword = hashSync(newPassword, 10);
    await storage.updateUser(userId, { password: hashedPassword });
    
    return res.status(200).json({ message: "Password updated successfully" });
  } catch (error) {
    console.error("Update password error:", error);
    return res.status(500).json({ message: "An error occurred while updating password" });
  }
};

// Enable/disable MFA
export const toggleMfa = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { enable } = req.body;
    
    if (enable === undefined) {
      return res.status(400).json({ message: "Enable parameter is required" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Toggle MFA
    await storage.updateUser(userId, { mfaEnabled: !!enable });
    
    return res.status(200).json({ 
      message: enable ? "MFA enabled successfully" : "MFA disabled successfully",
      mfaEnabled: !!enable
    });
  } catch (error) {
    console.error("Toggle MFA error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Update user status
export const updateStatus = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { status } = req.body;
    
    if (!status || !['online', 'offline', 'idle', 'dnd'].includes(status)) {
      return res.status(400).json({ message: "Valid status is required" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Update status
    await storage.updateUser(userId, { status });
    
    return res.status(200).json({ 
      message: "Status updated successfully",
      status
    });
  } catch (error) {
    console.error("Update status error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Get user by ID
export const getUserById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    
    const user = await storage.getUser(parseInt(id));
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Return public user data
    return res.status(200).json({
      id: user.id,
      username: user.username,
      discriminator: user.discriminator,
      avatar: user.avatar,
      banner: user.banner,
      bio: user.bio,
      status: user.status,
      createdAt: user.createdAt
    });
  } catch (error) {
    console.error("Get user by ID error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Create DM channel with another user
export const createDmChannel = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { otherUserId } = req.body;
    
    if (!otherUserId) {
      return res.status(400).json({ message: "Other user ID is required" });
    }
    
    const otherUser = await storage.getUser(parseInt(otherUserId));
    if (!otherUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Create or get existing DM channel
    const dmChannel = await storage.createDmChannel(userId, parseInt(otherUserId));
    
    return res.status(200).json({
      message: "DM channel created successfully",
      dmChannel: {
        id: dmChannel.id,
        createdAt: dmChannel.createdAt,
        otherUser: {
          id: otherUser.id,
          username: otherUser.username,
          discriminator: otherUser.discriminator,
          avatar: otherUser.avatar,
          status: otherUser.status
        }
      }
    });
  } catch (error) {
    console.error("Create DM channel error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};
