import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertChannelSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { formatZodError } from 'zod-validation-error';

// Create a new channel in a server
export const createChannel = async (req: Request, res: Response) => {
  try {
    const { serverId } = req.params;
    const userId = (req as any).userId;
    
    // Validate request body
    const channelData = insertChannelSchema.parse({
      ...req.body,
      serverId: parseInt(serverId)
    });
    
    // Check if server exists
    const server = await storage.getServer(parseInt(serverId));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user has permission to create channels
    // TODO: Check user roles and permissions
    // For now, only server owner can create channels
    if (server.ownerId !== userId) {
      return res.status(403).json({ message: "You don't have permission to create channels in this server" });
    }
    
    // Create channel
    const channel = await storage.createChannel(channelData);
    
    return res.status(201).json({
      message: "Channel created successfully",
      channel: {
        id: channel.id,
        name: channel.name,
        description: channel.description,
        type: channel.type,
        serverId: channel.serverId,
        createdAt: channel.createdAt
      }
    });
  } catch (error) {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error",
        errors: formatZodError(error).message 
      });
    }
    console.error("Channel creation error:", error);
    return res.status(500).json({ message: "An error occurred while creating channel" });
  }
};

// Get channel by ID
export const getChannel = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const channel = await storage.getChannel(parseInt(id));
    if (!channel) {
      return res.status(404).json({ message: "Channel not found" });
    }
    
    // Check if channel belongs to a server
    if (channel.serverId) {
      // Check if user is a member of this server
      const server = await storage.getServer(channel.serverId);
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }
      
      const members = await storage.getServerMembers(server.id);
      const isMember = members.some(member => member.id === userId);
      
      if (!isMember && server.ownerId !== userId) {
        return res.status(403).json({ message: "You are not a member of this server" });
      }
    } else {
      // This is a DM channel
      // TODO: Check if user is a member of this DM channel
    }
    
    // Get messages
    const messages = await storage.getMessagesByChannel(channel.id);
    
    // Populate sender info for each message
    const messagesWithSender = await Promise.all(messages.map(async (message) => {
      const sender = await storage.getUser(message.senderId);
      return {
        ...message,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          discriminator: sender.discriminator,
          avatar: sender.avatar
        } : null
      };
    }));
    
    return res.status(200).json({
      channel: {
        id: channel.id,
        name: channel.name,
        description: channel.description,
        type: channel.type,
        serverId: channel.serverId,
        createdAt: channel.createdAt
      },
      messages: messagesWithSender
    });
  } catch (error) {
    console.error("Get channel error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Update channel
export const updateChannel = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const channel = await storage.getChannel(parseInt(id));
    if (!channel) {
      return res.status(404).json({ message: "Channel not found" });
    }
    
    // Check if user has permission to update this channel
    // TODO: Check user roles and permissions
    // For now, only server owner can update channels
    if (channel.serverId) {
      const server = await storage.getServer(channel.serverId);
      if (!server || server.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this channel" });
      }
    }
    
    const { name, description, type } = req.body;
    
    const updatedData: any = {};
    if (name) updatedData.name = name;
    if (description !== undefined) updatedData.description = description;
    if (type) updatedData.type = type;
    
    const updatedChannel = await storage.updateChannel(channel.id, updatedData);
    
    return res.status(200).json({
      message: "Channel updated successfully",
      channel: updatedChannel
    });
  } catch (error) {
    console.error("Update channel error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Delete channel
export const deleteChannel = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const channel = await storage.getChannel(parseInt(id));
    if (!channel) {
      return res.status(404).json({ message: "Channel not found" });
    }
    
    // Check if user has permission to delete this channel
    // TODO: Check user roles and permissions
    // For now, only server owner can delete channels
    if (channel.serverId) {
      const server = await storage.getServer(channel.serverId);
      if (!server || server.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to delete this channel" });
      }
    }
    
    await storage.deleteChannel(channel.id);
    
    return res.status(200).json({ message: "Channel deleted successfully" });
  } catch (error) {
    console.error("Delete channel error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Get all channels for a server
export const getServerChannels = async (req: Request, res: Response) => {
  try {
    const { serverId } = req.params;
    const userId = (req as any).userId;
    
    const server = await storage.getServer(parseInt(serverId));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is a member of this server
    const members = await storage.getServerMembers(server.id);
    const isMember = members.some(member => member.id === userId);
    
    if (!isMember && server.ownerId !== userId) {
      return res.status(403).json({ message: "You are not a member of this server" });
    }
    
    const channels = await storage.getChannelsByServer(server.id);
    
    return res.status(200).json({ channels });
  } catch (error) {
    console.error("Get server channels error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Get DM channel or create one if it doesn't exist
export const getDmChannel = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { otherUserId } = req.params;
    
    if (!otherUserId || userId === parseInt(otherUserId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const otherUser = await storage.getUser(parseInt(otherUserId));
    if (!otherUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Get or create DM channel
    const dmChannel = await storage.createDmChannel(userId, parseInt(otherUserId));
    
    // Get messages
    const messages = await storage.getDirectMessagesByDmChannel(dmChannel.id);
    
    // Populate sender info
    const messagesWithSender = await Promise.all(messages.map(async (message) => {
      const sender = await storage.getUser(message.senderId);
      return {
        ...message,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          discriminator: sender.discriminator,
          avatar: sender.avatar
        } : null
      };
    }));
    
    return res.status(200).json({
      dmChannel: {
        id: dmChannel.id,
        createdAt: dmChannel.createdAt
      },
      otherUser: {
        id: otherUser.id,
        username: otherUser.username,
        discriminator: otherUser.discriminator,
        avatar: otherUser.avatar,
        status: otherUser.status
      },
      messages: messagesWithSender
    });
  } catch (error) {
    console.error("Get DM channel error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};
