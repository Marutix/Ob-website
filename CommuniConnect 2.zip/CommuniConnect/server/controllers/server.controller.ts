import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertServerSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { formatZodError } from 'zod-validation-error';

// Create a new server
export const createServer = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    
    // Validate request body
    const serverData = insertServerSchema.parse({ 
      ...req.body,
      ownerId: userId
    });

    // Create server
    const server = await storage.createServer(serverData);

    // Create default role
    const everyoneRole = await storage.createRole({
      name: "@everyone",
      color: "#99AAB5",
      serverId: server.id,
      permissions: {
        READ_MESSAGES: true,
        SEND_MESSAGES: true,
        EMBED_LINKS: true,
        ATTACH_FILES: true,
        USE_VOICE: true,
        ADD_REACTIONS: true
      }
    });

    // Create admin role for owner
    const adminRole = await storage.createRole({
      name: "Admin",
      color: "#FF0000",
      serverId: server.id,
      permissions: {
        MANAGE_SERVER: true,
        MANAGE_CHANNELS: true,
        MANAGE_ROLES: true,
        MANAGE_INVITES: true,
        KICK_MEMBERS: true,
        BAN_MEMBERS: true,
        CREATE_INVITES: true,
        CHANGE_NICKNAME: true,
        MANAGE_NICKNAMES: true,
        SEND_MESSAGES: true,
        EMBED_LINKS: true,
        ATTACH_FILES: true,
        ADD_REACTIONS: true,
        USE_VOICE: true,
        PRIORITY_SPEAKER: true,
        STREAM: true,
        READ_MESSAGES: true
      }
    });

    // Assign admin role to owner
    await storage.assignRoleToUser(userId, adminRole.id);

    return res.status(201).json({
      message: "Server created successfully",
      server: {
        id: server.id,
        name: server.name,
        description: server.description,
        icon: server.icon,
        banner: server.banner,
        ownerId: server.ownerId,
        createdAt: server.createdAt
      }
    });
  } catch (error) {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error",
        errors: formatZodError(error).message 
      });
    }
    console.error("Server creation error:", error);
    return res.status(500).json({ message: "An error occurred while creating server" });
  }
};

// Get server by ID
export const getServer = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const server = await storage.getServer(parseInt(id));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is a member of this server
    const members = await storage.getServerMembers(server.id);
    const isMember = members.some(member => member.id === userId);
    
    if (!isMember && server.ownerId !== userId) {
      return res.status(403).json({ message: "You are not a member of this server" });
    }
    
    // Get channels
    const channels = await storage.getChannelsByServer(server.id);
    
    // Get roles
    const roles = await storage.getRolesByServer(server.id);
    
    return res.status(200).json({
      server: {
        id: server.id,
        name: server.name,
        description: server.description,
        icon: server.icon,
        banner: server.banner,
        ownerId: server.ownerId,
        createdAt: server.createdAt
      },
      channels,
      members,
      roles
    });
  } catch (error) {
    console.error("Get server error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Update server
export const updateServer = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const server = await storage.getServer(parseInt(id));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is the owner
    if (server.ownerId !== userId) {
      return res.status(403).json({ message: "Only the server owner can update server details" });
    }
    
    const { name, description, icon, banner } = req.body;
    
    const updatedData: any = {};
    if (name) updatedData.name = name;
    if (description !== undefined) updatedData.description = description;
    if (icon) updatedData.icon = icon;
    if (banner) updatedData.banner = banner;
    
    const updatedServer = await storage.updateServer(server.id, updatedData);
    
    return res.status(200).json({
      message: "Server updated successfully",
      server: updatedServer
    });
  } catch (error) {
    console.error("Update server error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Delete server
export const deleteServer = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const server = await storage.getServer(parseInt(id));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is the owner
    if (server.ownerId !== userId) {
      return res.status(403).json({ message: "Only the server owner can delete the server" });
    }
    
    await storage.deleteServer(server.id);
    
    return res.status(200).json({ message: "Server deleted successfully" });
  } catch (error) {
    console.error("Delete server error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Join server with invite code
export const joinServer = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    const { inviteCode } = req.body;
    
    if (!inviteCode) {
      return res.status(400).json({ message: "Invite code is required" });
    }
    
    // Use the invite
    const invite = await storage.useInvite(inviteCode);
    if (!invite) {
      return res.status(404).json({ message: "Invalid or expired invite code" });
    }
    
    const server = await storage.getServer(invite.serverId);
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is already a member
    const members = await storage.getServerMembers(server.id);
    const isMember = members.some(member => member.id === userId);
    
    if (isMember) {
      return res.status(400).json({ message: "You are already a member of this server" });
    }
    
    // Add user to server
    await storage.addServerMember(server.id, userId);
    
    return res.status(200).json({
      message: "Joined server successfully",
      server: {
        id: server.id,
        name: server.name,
        description: server.description,
        icon: server.icon
      }
    });
  } catch (error) {
    console.error("Join server error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Leave server
export const leaveServer = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const server = await storage.getServer(parseInt(id));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user is the owner
    if (server.ownerId === userId) {
      return res.status(400).json({ message: "Server owner cannot leave the server. Transfer ownership or delete the server instead." });
    }
    
    // Check if user is a member
    const members = await storage.getServerMembers(server.id);
    const isMember = members.some(member => member.id === userId);
    
    if (!isMember) {
      return res.status(400).json({ message: "You are not a member of this server" });
    }
    
    // Remove user from server
    await storage.removeServerMember(server.id, userId);
    
    return res.status(200).json({ message: "Left server successfully" });
  } catch (error) {
    console.error("Leave server error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Create server invite
export const createInvite = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    const { maxUses, expiresAt } = req.body;
    
    const server = await storage.getServer(parseInt(id));
    if (!server) {
      return res.status(404).json({ message: "Server not found" });
    }
    
    // Check if user has permission to create invites
    // TODO: Check user roles and permissions
    // For now, all members can create invites
    const members = await storage.getServerMembers(server.id);
    const isMember = members.some(member => member.id === userId);
    
    if (!isMember && server.ownerId !== userId) {
      return res.status(403).json({ message: "You don't have permission to create invites for this server" });
    }
    
    // Create invite
    const invite = await storage.createInvite({
      serverId: server.id,
      creatorId: userId,
      maxUses: maxUses ? parseInt(maxUses) : undefined,
      expiresAt: expiresAt ? new Date(expiresAt) : undefined
    });
    
    return res.status(201).json({
      message: "Invite created successfully",
      invite: {
        code: invite.code,
        uses: invite.uses,
        maxUses: invite.maxUses,
        expiresAt: invite.expiresAt
      }
    });
  } catch (error) {
    console.error("Create invite error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Get all servers for current user
export const getUserServers = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).userId;
    
    const servers = await storage.getServersByUser(userId);
    
    return res.status(200).json({ servers });
  } catch (error) {
    console.error("Get user servers error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};
