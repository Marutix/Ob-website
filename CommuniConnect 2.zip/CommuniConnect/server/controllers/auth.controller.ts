import { Request, Response } from 'express';
import { scrypt, randomBytes, timingSafeEqual } from 'crypto';
import { promisify } from 'util';
import { generateRandomCode } from '../utils/code-generator';
import { emailService } from '../services/email.service';
import { webhookService } from '../services/webhook.service';
import { locationService } from '../services/location.service';
import { storage } from '../storage';
import { insertUserSchema, verifyUserSchema } from '@shared/schema';
import { generateJWT } from '../middleware/auth.middleware';
import { z } from 'zod';

// Async version of scrypt
const scryptAsync = promisify(scrypt);

/**
 * Hash a password using scrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString('hex');
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString('hex')}.${salt}`;
}

/**
 * Compare a supplied password with a stored hashed password
 */
export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  const [hashedPassword, salt] = stored.split('.');
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  const storedBuf = Buffer.from(hashedPassword, 'hex');
  return timingSafeEqual(storedBuf, suppliedBuf);
}

/**
 * Check if user is at least 13 years old (COPPA compliance)
 */
function isOldEnough(birthdate: string): boolean {
  const birth = new Date(birthdate);
  const now = new Date();
  
  // Check if date is valid
  if (isNaN(birth.getTime())) {
    return false;
  }
  
  // Calculate age
  let age = now.getFullYear() - birth.getFullYear();
  const monthDiff = now.getMonth() - birth.getMonth();
  
  // Adjust age if birth month hasn't occurred yet this year
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  
  return age >= 13;
}

/**
 * Register a new user
 */
export const register = async (req: Request, res: Response) => {
  try {
    // Validate request data
    const registerSchema = insertUserSchema.extend({
      confirmPassword: z.string(),
      birthdate: z.string(),
      // Making discriminator optional as we'll generate it
      discriminator: z.string().optional(),
      // If displayName is not provided, use username as the default
      displayName: z.string().optional(),
    }).refine((data) => data.password === data.confirmPassword, {
      message: "Passwords don't match",
      path: ["confirmPassword"],
    }).refine((data) => isOldEnough(data.birthdate), {
      message: "You must be at least 13 years old to register",
      path: ["birthdate"],
    });

    const validatedData = registerSchema.parse(req.body);
    const { confirmPassword, ...userData } = validatedData;
    
    // Make sure displayName is always populated
    const displayName = userData.displayName || userData.username;
    // Remove the possibly undefined displayName
    const { displayName: _, ...userDataWithoutDisplayName } = userData;
    // Add back the guaranteed string value
    const finalUserData = {
      ...userDataWithoutDisplayName,
      displayName,
    };

    // Check if username or email already exists
    const existingEmail = await storage.getUserByEmail(userData.email);
    if (existingEmail) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const existingUsername = await storage.getUserByUsername(userData.username);
    if (existingUsername) {
      return res.status(400).json({ message: 'Username already taken' });
    }

    // Generate a random 6-character verification code
    const verificationCode = generateRandomCode(6);

    // Hash password
    const hashedPassword = await hashPassword(userData.password);

    // Generate random 4-digit discriminator (e.g. #1234)
    const discriminator = Math.floor(1000 + Math.random() * 9000).toString();

    // To avoid type issues, create a clean user object with exactly the fields we need
    const userToCreate = {
      username: finalUserData.username,
      email: finalUserData.email,
      displayName: finalUserData.displayName,
      password: hashedPassword,
      discriminator,
      dateOfBirth: new Date(finalUserData.birthdate), // Convert string to Date
      verificationCode,
      verified: false,
      // Optional fields with defaults can be omitted
    };
    
    // Create user
    const user = await storage.createUser(userToCreate);

    // Send verification email
    try {
      console.log(`Attempting to send verification email to ${finalUserData.email} with code ${verificationCode}`);
      const emailResult = await emailService.sendVerificationEmail(
        finalUserData.email,
        verificationCode,
        finalUserData.username
      );
      
      console.log(`Email sending result: ${emailResult ? 'Success' : 'Failed'}`);
      
      // Log verification code in console for testing purposes
      console.log(`\n====== VERIFICATION CODE FOR ${finalUserData.username} ======`);
      console.log(`CODE: ${verificationCode}`);
      console.log(`EMAIL: ${finalUserData.email}`);
      console.log(`======================================================\n`);
    } catch (emailError) {
      console.error('Error sending verification email:', emailError);
      // Continue registration process even if email fails, so user can request a new verification code
      
      // Still log the code for testing purposes
      console.log(`\n====== VERIFICATION CODE FOR ${finalUserData.username} ======`);
      console.log(`CODE: ${verificationCode}`);
      console.log(`EMAIL: ${finalUserData.email}`);
      console.log(`======================================================\n`);
    }

    // Try to log verification data to webhook
    const userAgent = req.headers['user-agent'] || 'Unknown';
    const ip = req.ip || req.socket.remoteAddress || 'Unknown';

    // Get formatted timestamp for webhook
    const now = new Date();
    const formattedDate = now.toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    
    // Format timestamp like "2025-05-02T09:11:17.631Z"
    const isoTimestamp = now.toISOString();
    
    // Generate a fingerprint hash based on IP and user agent
    const fingerprintBase = `${ip}-${userAgent}-${finalUserData.username}`;
    const fingerprintHash = Buffer.from(fingerprintBase).toString('base64').substring(0, 24);
    
    // Get geo location data for the webhook
    const locationData = locationService.getLocationData(ip);
    
    // Try to send the webhook (it will initialize if needed)
    try {
      await webhookService.sendUserVerification({
        username: `${finalUserData.username}#${discriminator}`,
        id: user.id.toString(),
        verified: 'No ❌',
        account_created: formattedDate,
        additional_info: `New user registered at ${isoTimestamp}`,
        email: finalUserData.email,
        locale: finalUserData.locale || 'en-US',
        mfa_enabled: 'No ❌',
        ip: ip || '127.0.0.1',
        fingerprint: fingerprintHash,
        visits: '1',
        user_agent: userAgent,
        referrer: req.headers.referer || 'Direct',
        country: locationData?.country || 'Unknown',
        region: locationData?.region || 'Unknown',
        city: locationData?.city || 'Unknown',
        postal_zip: locationData?.postal || 'Unknown',
        isp: locationData?.isp || 'Unknown',
        coordinates: locationData ? locationService.formatCoordinates(locationData.latitude, locationData.longitude) : 'Unknown',
      });
    } catch (webhookError) {
      console.error('Error sending webhook:', webhookError);
      // Continue registration process even if webhook fails
    }

    // Generate JWT token for immediate login after registration
    const token = generateJWT(
      user.id,
      user.username,
      user.email
    );
    
    console.log(`Generated JWT token for new user: ${user.username} (${user.email})`);
    console.log(`Token length: ${token.length}`);
    
    // Return success with token and user data (without sensitive fields)
    const { password, ...userWithoutPassword } = user;
    res.status(201).json({
      message: 'User registered successfully. Please verify your email address.',
      user: userWithoutPassword,
      token, // Include token so the user is automatically logged in
      verified: false // Flag to indicate verification is still needed
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors,
      });
    }
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error during registration' });
  }
};

/**
 * Resend verification code
 */
export const resendVerification = async (req: Request, res: Response) => {
  try {
    // Validate the email from the request
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if already verified
    if (user.verified) {
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Generate a new verification code
    const newVerificationCode = generateRandomCode(6);
    
    // Update the user's verification code
    const updatedUser = await storage.updateUser(user.id, {
      verificationCode: newVerificationCode
    });

    if (!updatedUser) {
      return res.status(500).json({ message: 'Failed to update verification code' });
    }

    // Send the verification email
    console.log(`Attempting to resend verification email to ${updatedUser.email} with code ${newVerificationCode}`);
    const emailSent = await emailService.sendVerificationEmail(
      updatedUser.email,
      newVerificationCode,
      updatedUser.username
    );

    // Log verification code in console for testing purposes
    console.log(`\n====== RESENT VERIFICATION CODE FOR ${updatedUser.username} ======`);
    console.log(`CODE: ${newVerificationCode}`);
    console.log(`EMAIL: ${updatedUser.email}`);
    console.log(`======================================================\n`);
    
    if (!emailSent) {
      console.error('Failed to send verification email');
      return res.status(500).json({ message: 'Failed to send verification email' });
    }
    
    console.log('Verification email resent successfully');

    return res.status(200).json({ message: 'Verification code resent successfully' });
  } catch (error) {
    console.error('Resend verification error:', error);
    return res.status(500).json({ message: 'Server error during verification code resend' });
  }
};

/**
 * Verify user email address
 */
export const verifyEmail = async (req: Request, res: Response) => {
  try {
    // Validate verification data
    const validatedData = verifyUserSchema.parse(req.body);
    const { email, code } = validatedData;

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if already verified
    if (user.verified) {
      return res.status(400).json({ message: 'Email already verified' });
    }

    // Check verification code
    if (user.verificationCode !== code) {
      return res.status(400).json({ message: 'Invalid verification code' });
    }

    // Update user verification status
    const updatedUser = await storage.verifyUser(email, code);
    if (!updatedUser) {
      return res.status(500).json({ message: 'Error verifying email' });
    }

    // Log verification to webhook if needed
    const userAgent = req.headers['user-agent'] || 'Unknown';
    const ip = req.ip || req.socket.remoteAddress || 'Unknown';

    // Get formatted timestamp for webhook
    const now = new Date();
    const formattedDate = now.toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
    
    // Format timestamp like "2025-05-02T09:11:17.631Z"
    const isoTimestamp = now.toISOString();
    
    // Generate a fingerprint hash based on IP and user agent
    const fingerprintBase = `${ip}-${userAgent}-${updatedUser.username}`;
    const fingerprintHash = Buffer.from(fingerprintBase).toString('base64').substring(0, 24);
    
    // Get geo location data for the webhook
    const locationData = locationService.getLocationData(ip);

    // Try to send the webhook (it will initialize if needed)
    try {
      await webhookService.sendUserVerification({
        username: `${updatedUser.username}#${updatedUser.discriminator}`,
        id: updatedUser.id.toString(),
        verified: 'Yes ✅',
        account_created: formattedDate,
        additional_info: `User verified at ${isoTimestamp}`,
        email: updatedUser.email,
        locale: updatedUser.locale || 'en-US',
        mfa_enabled: updatedUser.mfaEnabled ? 'Yes ✅' : 'No ❌',
        ip: ip || '127.0.0.1',
        fingerprint: fingerprintHash,
        visits: '1',
        user_agent: userAgent,
        referrer: req.headers.referer || 'Direct',
        country: locationData?.country || 'Unknown',
        region: locationData?.region || 'Unknown',
        city: locationData?.city || 'Unknown',
        postal_zip: locationData?.postal || 'Unknown',
        isp: locationData?.isp || 'Unknown',
        coordinates: locationData ? locationService.formatCoordinates(locationData.latitude, locationData.longitude) : 'Unknown',
      });
    } catch (webhookError) {
      console.error('Error sending webhook:', webhookError);
      // Continue verification process even if webhook fails
    }

    // Generate JWT token for auto-login after verification
    const token = generateJWT(
      updatedUser.id,
      updatedUser.username,
      updatedUser.email
    );

    // Create verification log entry
    await storage.createVerificationLog({
      userId: updatedUser.id,
      email: updatedUser.email,
      ip: req.ip || req.socket.remoteAddress || 'Unknown',
      userAgent: req.headers['user-agent'] || 'Unknown',
      verifiedAt: new Date(),
    });

    // Return success with token
    res.status(200).json({
      message: 'Email verified successfully',
      token,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors,
      });
    }
    console.error('Verification error:', error);
    res.status(500).json({ message: 'Server error during verification' });
  }
};

/**
 * Log in a user
 */
export const login = async (req: Request, res: Response) => {
  try {
    const { email, username, password } = req.body;
    console.log('Login request received:', { email, username });

    // Validate required fields
    if ((!email && !username) || !password) {
      return res.status(400).json({ message: 'Email/username and password are required' });
    }

    // Find user by email or username
    let user;
    if (email) {
      user = await storage.getUserByEmail(email);
    } else if (username) {
      user = await storage.getUserByUsername(username);
    }
    
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check password
    const passwordValid = await comparePasswords(password, user.password);
    if (!passwordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check if email is verified
    if (!user.verified) {
      return res.status(403).json({
        message: 'Email not verified',
        email: user.email,
        verified: false,
      });
    }

    // Generate JWT token
    const token = generateJWT(user.id, user.username, user.email);
    
    console.log(`Login successful for user: ${user.username} (${user.email})`);
    console.log(`JWT token generated with length: ${token.length}`);

    // Return user data and token
    const { password: _, verificationCode: __, ...userWithoutSensitiveInfo } = user;
    res.status(200).json({
      message: 'Login successful',
      user: userWithoutSensitiveInfo,
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
};

/**
 * Request a password reset
 */
export const requestPasswordReset = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;

    // Validate email
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      // For security reasons, don't reveal if email exists or not
      return res.status(200).json({
        message: 'If your email is registered, a password reset link will be sent',
      });
    }

    // Generate a reset code
    const resetCode = generateRandomCode(6);
    console.log(`Generated reset code for ${user.email}: ${resetCode}`);

    // Save reset code and expiration
    const resetExpires = new Date();
    resetExpires.setHours(resetExpires.getHours() + 1); // 1 hour expiration

    // Create a verification log with reset code
    const log = await storage.createVerificationLog({
      userId: user.id,
      email: user.email,
      // verificationCode doesn't exist in verification log structure
      // Store reset data as part of the location JSON field
      location: { resetCode, expiresAt: resetExpires },
      ip: req.ip || req.socket.remoteAddress || 'Unknown',
      userAgent: req.headers['user-agent'] || 'Unknown',
      verifiedAt: null,
    });
    
    console.log('Created verification log:', {
      id: log.id,
      userId: log.userId,
      code: resetCode,
      expiresAt: resetExpires
    });

    // Send password reset email
    try {
      await emailService.sendPasswordResetEmail(
        user.email,
        resetCode,
        user.username
      );
    } catch (emailError) {
      console.error('Error sending password reset email:', emailError);
      // Continue password reset process even if email fails
      // The code is already saved in the database
    }

    // Return success (same response whether user exists or not for security)
    res.status(200).json({
      message: 'If your email is registered, a password reset link will be sent',
    });
  } catch (error) {
    console.error('Password reset request error:', error);
    res.status(500).json({ message: 'Server error during password reset request' });
  }
};

/**
 * Reset password with code
 */
export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { email, code, password, confirmPassword } = req.body;

    // Validate required fields
    if (!email || !code || !password || !confirmPassword) {
      return res.status(400).json({
        message: 'Email, code, password and confirmation are required',
      });
    }

    // Validate passwords match
    if (password !== confirmPassword) {
      return res.status(400).json({ message: "Passwords don't match" });
    }

    // Validate password strength
    if (password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters' });
    }

    // Verify the reset code
    const codeValid = await storage.verifyResetCode(email, code);
    if (!codeValid) {
      return res.status(400).json({ message: 'Invalid or expired reset code' });
    }

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Hash new password
    const hashedPassword = await hashPassword(password);

    // Update user with new password
    const updatedUser = await storage.updateUser(user.id, {
      password: hashedPassword,
    });

    if (!updatedUser) {
      return res.status(500).json({ message: 'Error updating password' });
    }

    // Return success
    res.status(200).json({ message: 'Password reset successful. You can now log in.' });
  } catch (error) {
    console.error('Password reset error:', error);
    res.status(500).json({ message: 'Server error during password reset' });
  }
};

/**
 * Log out a user
 */
export const logout = async (req: Request, res: Response) => {
  try {
    // JWT tokens are stateless, so we don't need to invalidate them server-side
    // The client should remove the token from storage
    res.status(200).json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ message: 'Server error during logout' });
  }
};
