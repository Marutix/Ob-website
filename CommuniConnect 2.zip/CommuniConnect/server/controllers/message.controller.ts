import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertMessageSchema, insertDirectMessageSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { formatZodError } from 'zod-validation-error';
import { broadcastToChannel, broadcastToDm } from '../services/websocket.service';

// Send a message to a channel
export const sendMessage = async (req: Request, res: Response) => {
  try {
    const { channelId } = req.params;
    const userId = (req as any).userId;
    
    // Validate request body
    const messageData = insertMessageSchema.parse({
      ...req.body,
      senderId: userId,
      channelId: parseInt(channelId)
    });
    
    // Check if channel exists
    const channel = await storage.getChannel(parseInt(channelId));
    if (!channel) {
      return res.status(404).json({ message: "Channel not found" });
    }
    
    // Check if user has permission to send messages in this channel
    // TODO: Check user roles and permissions
    // For now, check if user is a member of the server
    if (channel.serverId) {
      const server = await storage.getServer(channel.serverId);
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }
      
      const members = await storage.getServerMembers(server.id);
      const isMember = members.some(member => member.id === userId);
      
      if (!isMember && server.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to send messages in this channel" });
      }
    }
    
    // Create message
    const message = await storage.createMessage(messageData);
    
    // Get sender info
    const sender = await storage.getUser(userId);
    
    const messageWithSender = {
      ...message,
      sender: {
        id: sender!.id,
        username: sender!.username,
        discriminator: sender!.discriminator,
        avatar: sender!.avatar
      }
    };
    
    // Broadcast message to connected clients
    if (channel.serverId) {
      broadcastToChannel(channel.id, {
        type: 'NEW_MESSAGE',
        payload: messageWithSender
      });
    }
    
    return res.status(201).json({
      message: "Message sent successfully",
      data: messageWithSender
    });
  } catch (error) {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error",
        errors: formatZodError(error).message 
      });
    }
    console.error("Send message error:", error);
    return res.status(500).json({ message: "An error occurred while sending message" });
  }
};

// Get messages from a channel
export const getMessages = async (req: Request, res: Response) => {
  try {
    const { channelId } = req.params;
    const userId = (req as any).userId;
    
    const channel = await storage.getChannel(parseInt(channelId));
    if (!channel) {
      return res.status(404).json({ message: "Channel not found" });
    }
    
    // Check if user has permission to view messages in this channel
    // TODO: Check user roles and permissions
    // For now, check if user is a member of the server
    if (channel.serverId) {
      const server = await storage.getServer(channel.serverId);
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }
      
      const members = await storage.getServerMembers(server.id);
      const isMember = members.some(member => member.id === userId);
      
      if (!isMember && server.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have permission to view messages in this channel" });
      }
    }
    
    // Get messages
    const messages = await storage.getMessagesByChannel(parseInt(channelId));
    
    // Populate sender info
    const messagesWithSender = await Promise.all(messages.map(async (message) => {
      const sender = await storage.getUser(message.senderId);
      return {
        ...message,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          discriminator: sender.discriminator,
          avatar: sender.avatar
        } : null
      };
    }));
    
    return res.status(200).json({ messages: messagesWithSender });
  } catch (error) {
    console.error("Get messages error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Update a message
export const updateMessage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const message = await storage.getMessage(parseInt(id));
    if (!message) {
      return res.status(404).json({ message: "Message not found" });
    }
    
    // Check if user is the sender of the message
    if (message.senderId !== userId) {
      return res.status(403).json({ message: "You can only edit your own messages" });
    }
    
    const { content } = req.body;
    if (!content) {
      return res.status(400).json({ message: "Content is required" });
    }
    
    // Update message
    const updatedMessage = await storage.updateMessage(message.id, { content });
    
    // Get channel
    const channel = await storage.getChannel(message.channelId);
    
    // Broadcast update to connected clients
    if (channel && channel.serverId) {
      broadcastToChannel(channel.id, {
        type: 'UPDATE_MESSAGE',
        payload: updatedMessage
      });
    }
    
    return res.status(200).json({
      message: "Message updated successfully",
      data: updatedMessage
    });
  } catch (error) {
    console.error("Update message error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Delete a message
export const deleteMessage = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).userId;
    
    const message = await storage.getMessage(parseInt(id));
    if (!message) {
      return res.status(404).json({ message: "Message not found" });
    }
    
    // Check if user is the sender of the message
    // TODO: Allow server administrators to delete messages
    if (message.senderId !== userId) {
      return res.status(403).json({ message: "You can only delete your own messages" });
    }
    
    // Get channel info before deleting message
    const channelId = message.channelId;
    const channel = await storage.getChannel(channelId);
    
    // Delete message
    await storage.deleteMessage(message.id);
    
    // Broadcast deletion to connected clients
    if (channel && channel.serverId) {
      broadcastToChannel(channel.id, {
        type: 'DELETE_MESSAGE',
        payload: { id: message.id }
      });
    }
    
    return res.status(200).json({ message: "Message deleted successfully" });
  } catch (error) {
    console.error("Delete message error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};

// Send a direct message
export const sendDirectMessage = async (req: Request, res: Response) => {
  try {
    const { dmChannelId } = req.params;
    const userId = (req as any).userId;
    
    // Validate request body
    const messageData = insertDirectMessageSchema.parse({
      ...req.body,
      senderId: userId,
      dmChannelId: parseInt(dmChannelId)
    });
    
    // Check if DM channel exists
    const dmChannel = await storage.getDmChannel(parseInt(dmChannelId));
    if (!dmChannel) {
      return res.status(404).json({ message: "DM channel not found" });
    }
    
    // Check if user is a member of this DM channel
    // TODO: Implement proper check
    
    // Create direct message
    const directMessage = await storage.createDirectMessage(messageData);
    
    // Get sender info
    const sender = await storage.getUser(userId);
    
    const messageWithSender = {
      ...directMessage,
      sender: {
        id: sender!.id,
        username: sender!.username,
        discriminator: sender!.discriminator,
        avatar: sender!.avatar
      }
    };
    
    // Broadcast message to connected clients
    broadcastToDm(parseInt(dmChannelId), {
      type: 'NEW_DIRECT_MESSAGE',
      payload: messageWithSender
    });
    
    return res.status(201).json({
      message: "Direct message sent successfully",
      data: messageWithSender
    });
  } catch (error) {
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error",
        errors: formatZodError(error).message 
      });
    }
    console.error("Send direct message error:", error);
    return res.status(500).json({ message: "An error occurred while sending direct message" });
  }
};

// Get direct messages from a DM channel
export const getDirectMessages = async (req: Request, res: Response) => {
  try {
    const { dmChannelId } = req.params;
    const userId = (req as any).userId;
    
    const dmChannel = await storage.getDmChannel(parseInt(dmChannelId));
    if (!dmChannel) {
      return res.status(404).json({ message: "DM channel not found" });
    }
    
    // Check if user is a member of this DM channel
    // TODO: Implement proper check
    
    // Get direct messages
    const directMessages = await storage.getDirectMessagesByDmChannel(parseInt(dmChannelId));
    
    // Populate sender info
    const messagesWithSender = await Promise.all(directMessages.map(async (message) => {
      const sender = await storage.getUser(message.senderId);
      return {
        ...message,
        sender: sender ? {
          id: sender.id,
          username: sender.username,
          discriminator: sender.discriminator,
          avatar: sender.avatar
        } : null
      };
    }));
    
    return res.status(200).json({ messages: messagesWithSender });
  } catch (error) {
    console.error("Get direct messages error:", error);
    return res.status(500).json({ message: "An error occurred" });
  }
};
