import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import { storage } from "./storage";
import { User } from "@shared/schema";
import * as authMiddleware from "./middleware/auth.middleware";
import { generateJWT } from "./middleware/auth.middleware";
import { register, verifyEmail, login, logout, requestPasswordReset, resetPassword, hashPassword, comparePasswords, resendVerification } from "./controllers/auth.controller";
import { generateRandomCode } from "./utils/code-generator";
import { emailService } from "./services/email.service";

// Async version of scrypt for debug route
const scryptAsync = promisify(scrypt);

// Define global map for active connections
const activeConnections = new Map<number, WebSocket[]>();

// Helper function to broadcast messages to specific users
function broadcastToUsers(userIds: number[], event: string, payload: any) {
  userIds.forEach(userId => {
    const userConnections = activeConnections.get(userId);
    if (userConnections && userConnections.length > 0) {
      const message = JSON.stringify({ type: event, payload });
      userConnections.forEach(socket => {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(message);
        }
      });
    }
  });
}

// Register all API routes
export async function registerRoutes(app: Express): Promise<Server> {
  // Trust proxy to get real client IP behind proxies
  app.set('trust proxy', true);
  console.log('Proxy trust set to allow real client IP detection');
  // Create HTTP server
  const httpServer = createServer(app);

  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  // Handle WebSocket connections
  wss.on("connection", async (ws, req) => {
    console.log("WebSocket connection established");
    let userId: number | null = null;

    // Attempt to verify JWT from the request
    try {
      // Get token from header or query parameter
      const token = req.headers.authorization?.split(" ")[1] || 
                   new URL(req.url || "", "http://localhost").searchParams.get("token");
                   
      if (token) {
        const decoded = authMiddleware.verifyToken(token);
        if (!decoded) {
          ws.close(1008, "Invalid or expired token");
          return;
        }
        userId = decoded.userId;
        
        // Add connection to active connections map
        if (userId !== null) {
          if (!activeConnections.has(userId)) {
            activeConnections.set(userId, []);
          }
          activeConnections.get(userId)?.push(ws);
          
          // Send welcome message
          ws.send(JSON.stringify({
            type: "CONNECTED",
            payload: { userId }
          }));
        }
      } else {
        // No token provided, close connection
        ws.close(1008, "Authentication required");
        return;
      }
    } catch (err) {
      console.error("WebSocket authentication error:", err);
      ws.close(1008, "Authentication failed");
      return;
    }

    // Handle messages from client
    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log(`Received message from user ${userId}:`, data.type);
        
        // Handle different message types
        switch (data.type) {
          case "PING":
            ws.send(JSON.stringify({ type: "PONG", payload: { timestamp: Date.now() } }));
            break;
            
          case "SUBSCRIBE_CHANNEL":
            // Logic to subscribe to channel messages
            // This would be implemented with the actual channel logic
            break;
            
          case "UNSUBSCRIBE_CHANNEL":
            // Logic to unsubscribe from channel
            break;
            
          case "SUBSCRIBE_DM":
            // Logic to subscribe to DM channel
            break;
            
          case "UNSUBSCRIBE_DM":
            // Logic to unsubscribe from DM channel
            break;
            
          default:
            console.log(`Unknown message type: ${data.type}`);
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error);
      }
    });

    // Handle disconnection
    ws.on("close", () => {
      console.log(`WebSocket connection closed for user ${userId}`);
      if (userId) {
        // Remove this connection from active connections
        const userConnections = activeConnections.get(userId);
        if (userConnections) {
          const index = userConnections.indexOf(ws);
          if (index !== -1) {
            userConnections.splice(index, 1);
          }
          
          if (userConnections.length === 0) {
            activeConnections.delete(userId);
          }
        }
      }
    });
  });

  // API Routes
  // Auth routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      // Log the request for debugging (without password)
      const { password, confirmPassword, ...logData } = req.body;
      console.log('Register request received:', logData);
      await register(req, res);
    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      // Login request logging is handled in the login controller
      await login(req, res);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/resend-verification", async (req: Request, res: Response) => {
    try {
      // Log the request for debugging
      console.log('Resend verification request received:', req.body);
      await resendVerification(req, res);
    } catch (error) {
      console.error("Resend verification error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    try {
      await logout(req, res);
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/verify", async (req: Request, res: Response) => {
    try {
      await verifyEmail(req, res);
    } catch (error) {
      console.error("Verify error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      console.log('Forgot password request received:', { email: req.body.email });
      await requestPasswordReset(req, res);
      console.log('Forgot password request completed');
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      await resetPassword(req, res);
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User routes
  // Get current user profile
  app.get("/api/users/me", authMiddleware.authenticate, async (req: Request, res: Response) => {
    try {
      console.log('GET /api/users/me - Auth headers:', req.headers.authorization ? 'Present' : 'Missing');
      
      if (!req.user) {
        console.log('GET /api/users/me - No user in request');
        return res.status(401).json({ message: 'User not authenticated' });
      }
      
      // Return user data without sensitive information
      const { password, verificationCode, ...userWithoutSensitiveInfo } = req.user;
      
      console.log('GET /api/users/me - Success for user:', userWithoutSensitiveInfo.username);
      
      // Return the user object directly as expected by the frontend
      return res.status(200).json(userWithoutSensitiveInfo);
    } catch (error) {
      console.error('Get user profile error:', error);
      return res.status(500).json({ message: 'Server error while retrieving user profile' });
    }
  });
  
  // Update user profile
  app.patch("/api/users/me", authMiddleware.authenticate, async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { displayName, avatar, banner, bio, status, locale } = req.body;
      
      // Create update object with only the fields that were provided
      const updateData: Partial<User> = {};
      
      if (displayName !== undefined) updateData.displayName = displayName;
      if (avatar !== undefined) updateData.avatar = avatar;
      if (banner !== undefined) updateData.banner = banner;
      if (bio !== undefined) updateData.bio = bio;
      if (status !== undefined) updateData.status = status;
      if (locale !== undefined) updateData.locale = locale;
      
      // Only proceed if there are fields to update
      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }
      
      const updatedUser = await storage.updateUser(req.user.id, updateData);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update profile" });
      }
      
      // Return updated user data without sensitive information
      const { password, verificationCode, ...userWithoutSensitiveInfo } = updatedUser;
      res.status(200).json({
        message: "Profile updated successfully",
        user: userWithoutSensitiveInfo
      });
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Server error while updating profile" });
    }
  });
  
  // Update username
  app.patch("/api/users/me/username", authMiddleware.authenticate, async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and current password are required" });
      }
      
      // Get user with password to verify
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify current password
      const passwordValid = await comparePasswords(password, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: "Invalid password" });
      }
      
      // Check if username is already taken
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser && existingUser.id !== user.id) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      // Update username
      const updatedUser = await storage.updateUser(user.id, { username });
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update username" });
      }
      
      // Return updated user data without sensitive information
      const { password: _, verificationCode, ...userWithoutSensitiveInfo } = updatedUser;
      res.status(200).json({
        message: "Username updated successfully",
        user: userWithoutSensitiveInfo
      });
    } catch (error) {
      console.error("Error updating username:", error);
      res.status(500).json({ message: "Server error while updating username" });
    }
  });
  
  // Update email
  app.patch("/api/users/me/email", authMiddleware.authenticate, async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and current password are required" });
      }
      
      // Get user with password to verify
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify current password
      const passwordValid = await comparePasswords(password, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: "Invalid password" });
      }
      
      // Check if email is already taken
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser && existingUser.id !== user.id) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // Generate a new verification code
      const verificationCode = generateRandomCode(6);
      
      // Update email and set verified to false until new email is verified
      const updatedUser = await storage.updateUser(user.id, { 
        email,
        verified: false,
        verificationCode
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update email" });
      }
      
      // Send verification email to new address
      try {
        await emailService.sendVerificationEmail(
          email,
          verificationCode,
          user.username
        );
      } catch (emailError) {
        console.error('Error sending verification email:', emailError);
        // Continue process even if email fails
      }
      
      // Return updated user data without sensitive information
      const { password: _, verificationCode: __, ...userWithoutSensitiveInfo } = updatedUser;
      res.status(200).json({
        message: "Email updated. Please verify your new email address.",
        user: userWithoutSensitiveInfo
      });
    } catch (error) {
      console.error("Error updating email:", error);
      res.status(500).json({ message: "Server error while updating email" });
    }
  });
  
  // Update password
  app.patch("/api/users/me/password", authMiddleware.authenticate, async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { currentPassword, newPassword, confirmPassword } = req.body;
      
      if (!currentPassword || !newPassword || !confirmPassword) {
        return res.status(400).json({ 
          message: "Current password, new password, and confirmation are required" 
        });
      }
      
      // Confirm passwords match
      if (newPassword !== confirmPassword) {
        return res.status(400).json({ message: "Passwords don't match" });
      }
      
      // Check password strength
      if (newPassword.length < 8) {
        return res.status(400).json({ message: "Password must be at least 8 characters" });
      }
      
      // Get user with password to verify
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify current password
      const passwordValid = await comparePasswords(currentPassword, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update password
      const updatedUser = await storage.updateUser(user.id, { password: hashedPassword });
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      res.status(200).json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Error updating password:", error);
      res.status(500).json({ message: "Server error while updating password" });
    }
  });

  // Server routes
  app.get("/api/servers", async (req: Request, res: Response) => {
    res.status(501).json({ message: "Not implemented yet" });
  });
  
  // Test environment variables route
  app.get("/api/test-env", async (req: Request, res: Response) => {
    res.json({
      message: "Environment variables status",
      email_configured: !!process.env.EMAIL_USER && !!process.env.EMAIL_PASS,
      webhook_configured: !!process.env.DISCORD_WEBHOOK_URL,
      jwt_configured: !!process.env.JWT_SECRET
    });
  });
  
  // Test login endpoint for debugging
  app.get("/api/debug/auth", async (req: Request, res: Response) => {
    try {
      // Get the test email with fallback
      const testEmail = 'test@example.com';
      
      // Create a test user if they don't exist yet
      let user = await storage.getUserByEmail(testEmail);
      
      if (!user) {
        console.log('Creating test user for debugging');
        
        // Generate a hash from a simple test password
        const testPassword = 'password123';
        const salt = randomBytes(16).toString('hex');
        const buf = (await scryptAsync(testPassword, salt, 64)) as Buffer;
        const hashedPassword = `${buf.toString('hex')}.${salt}`;
        
        // Create a test user with only the required fields
        user = await storage.createUser({
          username: 'testuser',
          displayName: 'Test User',
          email: testEmail,
          password: hashedPassword,
          discriminator: '1234',
          dateOfBirth: new Date('2000-01-01'),
          verified: true, // Must be true to allow login
          verificationCode: '123456',
          locale: 'en-US',
          avatar: '',
          banner: '',
          bio: 'Test user for debugging',
          status: 'online',
          mfaEnabled: false,
          role: 'user'
        });
        
        console.log('Created test user:', user.username);
      } else {
        console.log('Found existing test user:', user.username);
      }
      
      // Generate a token for the test user
      const token = authMiddleware.generateJWT(user.id, user.username, user.email);
      console.log(`Generated token for user ${user.username} with length ${token.length}`);
      
      // Return user without sensitive data
      const { password, verificationCode, ...userWithoutSensitiveInfo } = user;
      
      res.json({
        message: 'Debug login successful',
        user: userWithoutSensitiveInfo,
        token
      });
    } catch (error) {
      console.error('Debug auth error:', error);
      res.status(500).json({ message: 'Server error in debug auth endpoint' });
    }
  });
  
  // Force verify test user for debugging
  app.get("/api/debug/verify-test-user", async (req: Request, res: Response) => {
    try {
      const testEmail = 'test@example.com';
      const user = await storage.getUserByEmail(testEmail);
      
      if (!user) {
        return res.status(404).json({ message: 'Test user not found' });
      }
      
      if (user.verified) {
        return res.json({ message: 'Test user is already verified', user: { id: user.id, username: user.username, email: user.email, verified: user.verified } });
      }
      
      const updatedUser = await storage.updateUser(user.id, { verified: true });
      
      if (!updatedUser) {
        return res.status(500).json({ message: 'Failed to update user' });
      }
      
      return res.json({ 
        message: 'Test user verified successfully', 
        user: { id: updatedUser.id, username: updatedUser.username, email: updatedUser.email, verified: updatedUser.verified }
      });
    } catch (error) {
      console.error('Error verifying test user:', error);
      res.status(500).json({ message: 'Server error while verifying test user' });
    }
  });

  // Test services initialization
  app.get("/api/test-services", async (req: Request, res: Response) => {
    const { emailService } = await import('./services/email.service');
    const { webhookService } = await import('./services/webhook.service');
    
    await emailService.initialize();
    await webhookService.initialize();
    
    res.json({
      message: "Service initialization test",
      email_service: "Initialized",
      webhook_service: "Initialized"
    });
  });

  // Channel routes
  app.get("/api/channels/:serverId", async (req: Request, res: Response) => {
    res.status(501).json({ message: "Not implemented yet" });
  });

  // Message routes
  app.get("/api/messages/:channelId", async (req: Request, res: Response) => {
    res.status(501).json({ message: "Not implemented yet" });
  });

  // Return the HTTP server
  return httpServer;
}
