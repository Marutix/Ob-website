import geoip from 'geoip-lite';

class LocationService {
  /**
   * Get location data based on an IP address
   */
  getLocationData(ip: string) {
    console.log(`Getting location data for IP: ${ip}`);
    
    // Clean the IP address for proper lookup
    // If IPv6 localhost or with prefix, clean it up
    let cleanIp = ip;
    
    if (ip.includes('::ffff:')) {
      cleanIp = ip.replace('::ffff:', '');
      console.log(`Cleaned IPv6-mapped IPv4 address to: ${cleanIp}`);
    }
    
    if (ip.includes('::1') || ip === '127.0.0.1' || ip === 'localhost' || 
        cleanIp.startsWith('192.168.') || cleanIp.startsWith('10.') || 
        cleanIp.startsWith('172.')) {
      // For local development, use a real-world IP to get actual location data
      // Using Google's IP for demonstration purposes (8.8.8.8)
      console.log('Local IP detected, using a public IP for geolocation demo');
      cleanIp = '8.8.8.8';
    }
    
    try {
      const geo = geoip.lookup(cleanIp);
      console.log('Geolocation lookup result:', geo);
      
      if (!geo) {
        console.log('No geolocation data found, using fallback data');
        // Use a fallback for testing in development
        return {
          country: 'United States',
          region: 'California',
          city: 'Mountain View',
          postal: '94043',
          latitude: 37.386,
          longitude: -122.0838,
          timezone: 'America/Los_Angeles',
          isp: 'Google LLC',
        };
      }
      
      // We have geo data, but ensure all fields are present
      const result = {
        country: geo.country || 'United States',
        region: geo.region?.[0] || 'California',
        city: geo.city || 'Mountain View',
        postal: geo.zip || '94043',
        latitude: geo.ll ? geo.ll[0] : 37.386,
        longitude: geo.ll ? geo.ll[1] : -122.0838,
        timezone: geo.timezone || 'America/Los_Angeles',
        isp: 'Internet Service Provider', // geoip-lite doesn't provide ISP info
      };
      
      console.log('Formatted location data:', result);
      return result;
    } catch (error) {
      console.error('Error getting location data:', error);
      // Use a fallback for testing in development
      return {
        country: 'United States',
        region: 'California',
        city: 'Mountain View',
        postal: '94043',
        latitude: 37.386,
        longitude: -122.0838,
        timezone: 'America/Los_Angeles',
        isp: 'Google LLC',
      };
    }
  }
  
  /**
   * Format coordinates as a string
   */
  formatCoordinates(latitude: number, longitude: number): string {
    return `${latitude.toFixed(4)},${longitude.toFixed(4)}`;
  }
}

export const locationService = new LocationService();
