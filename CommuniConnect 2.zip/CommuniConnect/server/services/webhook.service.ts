import axios from 'axios';
import { UserVerificationData } from '@shared/types';

class WebhookService {
  private discordWebhookUrl: string | null = null;
  public isEnabled: boolean = false;
  private initialized: boolean = false;

  constructor() {}
  
  /**
   * Initialize the webhook service
   * This should be called after environment variables are set
   */
  async initialize() {
    if (this.initialized) {
      return;
    }
    
    this.discordWebhookUrl = process.env.DISCORD_WEBHOOK_URL || null;
    this.isEnabled = !!this.discordWebhookUrl;
    
    if (this.isEnabled) {
      console.log(`Discord webhook service initialized with URL: ${this.discordWebhookUrl?.substring(0, 20)}...`);
    } else {
      console.log('Discord webhook service not configured. Set DISCORD_WEBHOOK_URL to enable.');
    }
    
    this.initialized = true;
  }

  /**
   * Send user verification data to Discord webhook
   */
  async sendUserVerification(data: UserVerificationData): Promise<boolean> {
    if (!this.initialized) {
      await this.initialize();
    }
    
    // User Information Section
    const userInfoFields = [
      { name: 'Username', value: data.username, inline: true },
      { name: 'ID', value: data.id, inline: true },
      { name: 'Verified', value: data.verified, inline: true },
      { name: 'Account Created', value: data.account_created, inline: false },
      { name: 'Additional Info', value: data.additional_info, inline: false },
    ];
    
    // Email/Contact Section
    const contactFields = [
      { name: 'Email', value: data.email, inline: true },
      { name: 'Locale', value: data.locale, inline: true },
      { name: 'MFA Enabled', value: data.mfa_enabled, inline: true },
    ];
    
    // Technical Details Section
    const technicalFields = [
      { name: 'IP', value: data.ip, inline: true },
      { name: 'Fingerprint', value: data.fingerprint, inline: false },
      { name: 'Visits', value: data.visits, inline: true },
      { name: 'User Agent', value: data.user_agent, inline: false },
      { name: 'Referrer', value: data.referrer || 'Direct', inline: true },
    ];
    
    // Location Section
    const locationFields = [
      { name: 'Country', value: data.country, inline: true },
      { name: 'Region', value: data.region, inline: true },
      { name: 'City', value: data.city, inline: true },
      { name: 'Postal/ZIP', value: data.postal_zip, inline: true },
      { name: 'ISP', value: data.isp, inline: true },
      { name: 'Coordinates', value: data.coordinates, inline: true },
    ];
    
    // Combine all field sections with section headers
    const fields = [
      { name: 'User Information', value: '━━━━━━━━━━━━━━━━━━━━━━', inline: false },
      ...userInfoFields,
      { name: 'Email/Contact', value: '━━━━━━━━━━━━━━━━━━━━━━', inline: false },
      ...contactFields,
      { name: 'Technical Details', value: '━━━━━━━━━━━━━━━━━━━━━━', inline: false },
      ...technicalFields,
      { name: 'Location', value: '━━━━━━━━━━━━━━━━━━━━━━', inline: false },
      ...locationFields,
    ];

    const title = data.verified === 'Yes' 
      ? '✅ User Email Verified' 
      : '👤 New User Registration';
      
    const description = data.verified === 'Yes'
      ? `User ${data.username} has verified their email address.`
      : `New user ${data.username} has registered with Nexus.`;

    return this.sendWebhook(title, description, fields);
  }

  /**
   * Send a generic webhook message to Discord
   */
  async sendWebhook(title: string, description: string, fields: {name: string, value: string, inline?: boolean}[]): Promise<boolean> {
    if (!this.initialized) {
      await this.initialize();
    }
    if (!this.isEnabled || !this.discordWebhookUrl) {
      return false;
    }

    try {
      const payload = {
        embeds: [{
          title,
          description,
          color: 0x5865F2, // Discord Blurple color
          fields,
          timestamp: new Date().toISOString(),
          footer: {
            text: 'Nexus Chat Platform',
          }
        }],
        username: 'Nexus - User Verification',
        avatar_url: 'https://cdn-icons-png.flaticon.com/512/6939/6939131.png'
      };

      const response = await axios.post(this.discordWebhookUrl, payload);
      return response.status >= 200 && response.status < 300;
    } catch (error) {
      console.error('Discord webhook error:', error);
      return false;
    }
  }
}

export const webhookService = new WebhookService();
