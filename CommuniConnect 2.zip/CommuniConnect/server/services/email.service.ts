import nodemailer from 'nodemailer';

class EmailService {
  private transporter!: nodemailer.Transporter; // Using the definite assignment assertion
  private fromEmail: string = 'verification@nexus-chat.com';
  private isDevelopment: boolean = true;
  private initialized: boolean = false;

  constructor() {}
  
  /**
   * Initialize the email service
   * This should be called after environment variables are set
   */
  async initialize() {
    if (this.initialized) {
      return;
    }
    
    this.isDevelopment = process.env.NODE_ENV !== 'production';
    this.fromEmail = process.env.EMAIL_USER || 'verification@nexus-chat.com';
    
    // Check if we have credentials for production
    const user = process.env.EMAIL_USER;
    const pass = process.env.EMAIL_PASS;
    
    if (!user || !pass) {
      console.log('Email credentials not found or incomplete. Using ethereal email as fallback.');
      await this.setupDevelopmentTransport();
    } else {
      console.log(`Using email credentials for: ${user}`);
      // Set up real email transport
      this.transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user,
          pass,
        },
      });
      console.log('Email service initialized with real credentials');
    }
    
    this.initialized = true;
  }

  /**
   * Set up a test account with ethereal.email for development
   */
  private async setupDevelopmentTransport() {
    try {
      // Generate test SMTP service account from ethereal.email
      const testAccount = await nodemailer.createTestAccount();

      // Create a SMTP transporter object using ethereal.email
      this.transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass,
        },
      });
      
      console.log('\n==============================================');
      console.log('📧 DEVELOPMENT EMAIL TESTING SETUP');
      console.log('==============================================');
      console.log(`USERNAME: ${testAccount.user}`);
      console.log(`PASSWORD: ${testAccount.pass}`);
      console.log(`PREVIEW: https://ethereal.email/login`);
      console.log('==============================================');
      console.log('⚠️ ALL VERIFICATION CODES WILL APPEAR IN CONSOLE');
      console.log('⚠️ EMAILS MAY NOT BE DELIVERED TO REAL INBOXES');
      console.log('==============================================\n');
      
    } catch (error) {
      console.error('Failed to create test email account:', error);
      
      // Create a fallback noop transporter that just logs emails instead
      this.transporter = nodemailer.createTransport({
        jsonTransport: true
      });
      
      console.log('\n==============================================');
      console.log('📧 EMAIL SERVICE FALLBACK MODE ACTIVATED');
      console.log('==============================================');
      console.log('⚠️ Using JSON Transport - NO EMAILS WILL BE SENT');
      console.log('⚠️ ALL VERIFICATION CODES WILL APPEAR IN CONSOLE');
      console.log('==============================================\n');
    }
  }

  /**
   * Send a verification email with a code
   */
  async sendVerificationEmail(to: string, code: string, username: string): Promise<boolean> {
    if (!this.initialized) {
      await this.initialize();
    }
    
    // Log verification code directly for testing purposes
    console.log(`\n=====================================================`);
    console.log(`🔑 SENDING VERIFICATION CODE: ${code}`);
    console.log(`📧 TO EMAIL: ${to}`);
    console.log(`👤 USERNAME: ${username}`);
    console.log(`=====================================================\n`);
    
    const subject = 'Verify your Nexus account';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #5865F2; padding: 20px; text-align: center;">
          <h1 style="color: white;">Nexus</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #ddd; border-top: none;">
          <h2>Hello, ${username}!</h2>
          <p>Thank you for creating a Nexus account. To complete your registration, please verify your email address by entering the following code:</p>
          <div style="background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; margin: 20px 0;">
            <strong>${code}</strong>
          </div>
          <p>If you didn't request this verification, please ignore this email.</p>
          <p>The verification code will expire in 24 hours.</p>
          <p>Best regards,<br>The Nexus Team</p>
        </div>
        <div style="background-color: #f5f5f5; padding: 10px; text-align: center; font-size: 12px; color: #666;">
          <p>This is an automated message, please do not reply.</p>
        </div>
      </div>
    `;

    // Even if email fails, we'll still have access to the code in logs
    const result = await this.sendEmail(to, subject, html);
    
    if (!result) {
      console.log(`\n⚠️ EMAIL SENDING FAILED, BUT CODE IS STILL AVAILABLE ABOVE ⚠️\n`);
    }
    
    return result;
  }

  /**
   * Send a password reset email with a code
   */
  async sendPasswordResetEmail(to: string, code: string, username: string): Promise<boolean> {
    if (!this.initialized) {
      await this.initialize();
    }
    const subject = 'Reset your Nexus password';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #5865F2; padding: 20px; text-align: center;">
          <h1 style="color: white;">Nexus</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #ddd; border-top: none;">
          <h2>Hello, ${username}!</h2>
          <p>We received a request to reset your Nexus account password. To proceed with the password reset, please use the following code:</p>
          <div style="background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 24px; letter-spacing: 5px; margin: 20px 0;">
            <strong>${code}</strong>
          </div>
          <p>If you didn't request a password reset, please ignore this email or contact support if you have concerns.</p>
          <p>The reset code will expire in 1 hour.</p>
          <p>Best regards,<br>The Nexus Team</p>
        </div>
        <div style="background-color: #f5f5f5; padding: 10px; text-align: center; font-size: 12px; color: #666;">
          <p>This is an automated message, please do not reply.</p>
        </div>
      </div>
    `;

    return this.sendEmail(to, subject, html);
  }

  /**
   * Send an email with the provided content
   */
  private async sendEmail(to: string, subject: string, html: string): Promise<boolean> {
    if (!this.initialized) {
      await this.initialize();
    }

    // Extract verification code from HTML before any operations
    const codeMatch = html.match(/<strong>([^<]+)<\/strong>/);
    const code = codeMatch && codeMatch[1];
    
    // Always display the code in a very visible format - even before attempting to send
    if (code) {
      console.log(`\n==========================================================`);
      console.log(`✨ VERIFICATION CODE: ${code} ✨`);
      console.log(`📧 FOR: ${to}`);
      console.log(`⏰ SENT AT: ${new Date().toLocaleTimeString()}`);
      console.log(`==========================================================\n`);
    }
    
    try {
      const mailOptions = {
        from: `"Nexus" <${this.fromEmail}>`,
        to,
        subject,
        html,
      };

      const info = await this.transporter.sendMail(mailOptions);
      
      // Log detailed information about the email
      console.log(`📩 Email sent successfully to: ${to}`);
      console.log(`Subject: ${subject}`);
      console.log(`Message ID: ${info.messageId}`);
      
      // Log URL where email can be previewed if using ethereal.email
      if (this.isDevelopment) {
        if (info.testMessageUrl) {
          console.log(`📧 PREVIEW EMAIL: ${info.testMessageUrl}`);
        } else if (nodemailer.getTestMessageUrl) {
          const previewUrl = nodemailer.getTestMessageUrl(info);
          if (previewUrl) {
            console.log(`📧 PREVIEW EMAIL: ${previewUrl}`);
          }
        }
      }
      
      return true;
    } catch (error) {
      console.error('Failed to send email:', error);
      // If we're in development, continue anyway so we can test the flow
      if (this.isDevelopment) {
        console.log('\n⚠️ EMAIL DELIVERY FAILED IN DEVELOPMENT MODE ⚠️');
        console.log('✅ However, verification flow will continue with the code shown above');
        console.log('ℹ️ Check your email configuration if you want to receive actual emails\n');
        
        return true;
      }
      return false;
    }
  }
}

export const emailService = new EmailService();
