import {
  User, InsertUser, Server, InsertServer, Channel, InsertChannel,
  Message, InsertMessage, Role, InsertRole, ServerMember, Invite,
  InsertInvite, Bot, InsertBot, DmChannel, DirectMessage, InsertDirectMessage,
  VerificationLog
} from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';
import { randomBytes, createHash } from 'crypto';

// Modify the interface with CRUD methods
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  verifyUser(email: string, code: string): Promise<User | undefined>;
  
  // Servers
  getServer(id: number): Promise<Server | undefined>;
  getServersByUser(userId: number): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: number, data: Partial<Server>): Promise<Server | undefined>;
  deleteServer(id: number): Promise<boolean>;
  
  // Server Members
  addServerMember(serverId: number, userId: number): Promise<ServerMember>;
  getServerMembers(serverId: number): Promise<User[]>;
  removeServerMember(serverId: number, userId: number): Promise<boolean>;
  
  // Channels
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelsByServer(serverId: number): Promise<Channel[]>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, data: Partial<Channel>): Promise<Channel | undefined>;
  deleteChannel(id: number): Promise<boolean>;
  
  // Messages
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByChannel(channelId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessage(id: number, data: Partial<Message>): Promise<Message | undefined>;
  deleteMessage(id: number): Promise<boolean>;
  
  // DM Channels
  getDmChannel(id: number): Promise<DmChannel | undefined>;
  getDmChannelByUsers(userIdA: number, userIdB: number): Promise<DmChannel | undefined>;
  getDmChannelsByUser(userId: number): Promise<DmChannel[]>;
  createDmChannel(userIdA: number, userIdB: number): Promise<DmChannel>;
  
  // Direct Messages
  getDirectMessage(id: number): Promise<DirectMessage | undefined>;
  getDirectMessagesByDmChannel(dmChannelId: number): Promise<DirectMessage[]>;
  createDirectMessage(message: InsertDirectMessage): Promise<DirectMessage>;
  
  // Roles
  getRole(id: number): Promise<Role | undefined>;
  getRolesByServer(serverId: number): Promise<Role[]>;
  createRole(role: InsertRole): Promise<Role>;
  updateRole(id: number, data: Partial<Role>): Promise<Role | undefined>;
  deleteRole(id: number): Promise<boolean>;
  
  // User Roles
  assignRoleToUser(userId: number, roleId: number): Promise<boolean>;
  removeRoleFromUser(userId: number, roleId: number): Promise<boolean>;
  getUserRoles(userId: number): Promise<Role[]>;
  
  // Invites
  getInvite(code: string): Promise<Invite | undefined>;
  createInvite(invite: InsertInvite): Promise<Invite>;
  useInvite(code: string): Promise<Invite | undefined>;
  
  // Bots
  getBot(id: number): Promise<Bot | undefined>;
  getBotsByUser(userId: number): Promise<Bot[]>;
  createBot(bot: InsertBot): Promise<Bot>;
  
  // Verification Logs
  createVerificationLog(log: Partial<VerificationLog>): Promise<VerificationLog>;
  verifyResetCode(email: string, code: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private servers: Map<number, Server>;
  private channels: Map<number, Channel>;
  private messages: Map<number, Message>;
  private roles: Map<number, Role>;
  private serverMembers: Map<string, ServerMember>; // key: `${serverId}-${userId}`
  private userRoles: Map<string, number>; // key: `${userId}-${roleId}`
  private invites: Map<string, Invite>; // key: code
  private bots: Map<number, Bot>;
  private dmChannels: Map<number, DmChannel>;
  private dmChannelMembers: Map<string, number>; // key: `${dmChannelId}-${userId}`
  private directMessages: Map<number, DirectMessage>;
  private verificationLogs: Map<number, VerificationLog>;

  // IDs for auto-increment
  private userId: number;
  private serverId: number;
  private channelId: number;
  private messageId: number;
  private roleId: number;
  private botId: number;
  private dmChannelId: number;
  private directMessageId: number;
  private verificationLogId: number;

  constructor() {
    this.users = new Map();
    this.servers = new Map();
    this.channels = new Map();
    this.messages = new Map();
    this.roles = new Map();
    this.serverMembers = new Map();
    this.userRoles = new Map();
    this.invites = new Map();
    this.bots = new Map();
    this.dmChannels = new Map();
    this.dmChannelMembers = new Map();
    this.directMessages = new Map();
    this.verificationLogs = new Map();

    this.userId = 1;
    this.serverId = 1;
    this.channelId = 1;
    this.messageId = 1;
    this.roleId = 1;
    this.botId = 1;
    this.dmChannelId = 1;
    this.directMessageId = 1;
    this.verificationLogId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    
    // Generate a random 4-digit discriminator
    const discriminator = Math.floor(1000 + Math.random() * 9000).toString();
    
    // Generate a 6-digit verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    
    const user: User = {
      ...insertUser,
      id,
      discriminator,
      verified: false,
      verificationCode,
      createdAt: now,
      avatar: "",
      banner: "",
      bio: "",
      status: "offline",
      mfaEnabled: false,
      locale: "en-US"
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async verifyUser(email: string, code: string): Promise<User | undefined> {
    const user = await this.getUserByEmail(email);
    if (!user || user.verificationCode !== code) return undefined;
    
    const updatedUser = { ...user, verified: true, verificationCode: null };
    this.users.set(user.id, updatedUser);
    return updatedUser;
  }

  // Server methods
  async getServer(id: number): Promise<Server | undefined> {
    return this.servers.get(id);
  }

  async getServersByUser(userId: number): Promise<Server[]> {
    const servers: Server[] = [];
    
    // Check owner
    for (const server of this.servers.values()) {
      if (server.ownerId === userId) {
        servers.push(server);
        continue;
      }
      
      // Check membership
      const memberKey = `${server.id}-${userId}`;
      if (this.serverMembers.has(memberKey)) {
        servers.push(server);
      }
    }
    
    return servers;
  }

  async createServer(server: InsertServer): Promise<Server> {
    const id = this.serverId++;
    const now = new Date();
    
    const newServer: Server = {
      ...server,
      id,
      createdAt: now,
      description: server.description || "",
      icon: server.icon || "",
      banner: server.banner || ""
    };
    
    this.servers.set(id, newServer);
    
    // Add owner as a member
    await this.addServerMember(id, server.ownerId);
    
    // Create default general channel
    await this.createChannel({
      name: "general",
      type: "text",
      serverId: id,
      description: "General discussion"
    });
    
    return newServer;
  }

  async updateServer(id: number, data: Partial<Server>): Promise<Server | undefined> {
    const server = this.servers.get(id);
    if (!server) return undefined;
    
    const updatedServer = { ...server, ...data };
    this.servers.set(id, updatedServer);
    return updatedServer;
  }

  async deleteServer(id: number): Promise<boolean> {
    const server = this.servers.get(id);
    if (!server) return false;
    
    // Delete channels
    for (const channel of this.channels.values()) {
      if (channel.serverId === id) {
        this.channels.delete(channel.id);
      }
    }
    
    // Delete server members
    for (const key of this.serverMembers.keys()) {
      if (key.startsWith(`${id}-`)) {
        this.serverMembers.delete(key);
      }
    }
    
    // Delete roles
    for (const role of this.roles.values()) {
      if (role.serverId === id) {
        this.roles.delete(role.id);
      }
    }
    
    // Delete invites
    for (const [code, invite] of this.invites.entries()) {
      if (invite.serverId === id) {
        this.invites.delete(code);
      }
    }
    
    this.servers.delete(id);
    return true;
  }

  // Server Members methods
  async addServerMember(serverId: number, userId: number): Promise<ServerMember> {
    const server = await this.getServer(serverId);
    const user = await this.getUser(userId);
    
    if (!server || !user) {
      throw new Error("Server or user not found");
    }
    
    const key = `${serverId}-${userId}`;
    const now = new Date();
    
    const member: ServerMember = {
      serverId,
      userId,
      nickname: null,
      joinedAt: now
    };
    
    this.serverMembers.set(key, member);
    return member;
  }

  async getServerMembers(serverId: number): Promise<User[]> {
    const members: User[] = [];
    
    for (const [key, member] of this.serverMembers.entries()) {
      if (key.startsWith(`${serverId}-`)) {
        const userId = member.userId;
        const user = await this.getUser(userId);
        if (user) {
          members.push(user);
        }
      }
    }
    
    return members;
  }

  async removeServerMember(serverId: number, userId: number): Promise<boolean> {
    const key = `${serverId}-${userId}`;
    return this.serverMembers.delete(key);
  }

  // Channel methods
  async getChannel(id: number): Promise<Channel | undefined> {
    return this.channels.get(id);
  }

  async getChannelsByServer(serverId: number): Promise<Channel[]> {
    const channels: Channel[] = [];
    
    for (const channel of this.channels.values()) {
      if (channel.serverId === serverId) {
        channels.push(channel);
      }
    }
    
    return channels;
  }

  async createChannel(channel: InsertChannel): Promise<Channel> {
    const id = this.channelId++;
    const now = new Date();
    
    const newChannel: Channel = {
      ...channel,
      id,
      createdAt: now,
      description: channel.description || ""
    };
    
    this.channels.set(id, newChannel);
    return newChannel;
  }

  async updateChannel(id: number, data: Partial<Channel>): Promise<Channel | undefined> {
    const channel = this.channels.get(id);
    if (!channel) return undefined;
    
    const updatedChannel = { ...channel, ...data };
    this.channels.set(id, updatedChannel);
    return updatedChannel;
  }

  async deleteChannel(id: number): Promise<boolean> {
    const channel = this.channels.get(id);
    if (!channel) return false;
    
    // Delete messages
    for (const message of this.messages.values()) {
      if (message.channelId === id) {
        this.messages.delete(message.id);
      }
    }
    
    this.channels.delete(id);
    return true;
  }

  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesByChannel(channelId: number): Promise<Message[]> {
    const messages: Message[] = [];
    
    for (const message of this.messages.values()) {
      if (message.channelId === channelId) {
        messages.push(message);
      }
    }
    
    // Sort by createdAt
    return messages.sort((a, b) => {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    
    const newMessage: Message = {
      ...message,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async updateMessage(id: number, data: Partial<Message>): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { 
      ...message, 
      ...data,
      updatedAt: new Date()
    };
    
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }

  async deleteMessage(id: number): Promise<boolean> {
    return this.messages.delete(id);
  }

  // DM Channel methods
  async getDmChannel(id: number): Promise<DmChannel | undefined> {
    return this.dmChannels.get(id);
  }

  async getDmChannelByUsers(userIdA: number, userIdB: number): Promise<DmChannel | undefined> {
    for (const [dmChannelId, dmChannel] of this.dmChannels.entries()) {
      // Check if both users are members of this DM channel
      const keyA = `${dmChannelId}-${userIdA}`;
      const keyB = `${dmChannelId}-${userIdB}`;
      
      if (this.dmChannelMembers.has(keyA) && this.dmChannelMembers.has(keyB)) {
        return dmChannel;
      }
    }
    
    return undefined;
  }

  async getDmChannelsByUser(userId: number): Promise<DmChannel[]> {
    const dmChannels: DmChannel[] = [];
    
    for (const [key, value] of this.dmChannelMembers.entries()) {
      if (key.endsWith(`-${userId}`)) {
        const dmChannelId = parseInt(key.split('-')[0], 10);
        const dmChannel = await this.getDmChannel(dmChannelId);
        if (dmChannel) {
          dmChannels.push(dmChannel);
        }
      }
    }
    
    return dmChannels;
  }

  async createDmChannel(userIdA: number, userIdB: number): Promise<DmChannel> {
    // Check if DM channel already exists
    const existingDmChannel = await this.getDmChannelByUsers(userIdA, userIdB);
    if (existingDmChannel) {
      return existingDmChannel;
    }
    
    const id = this.dmChannelId++;
    const now = new Date();
    
    const dmChannel: DmChannel = {
      id,
      createdAt: now
    };
    
    this.dmChannels.set(id, dmChannel);
    
    // Add members
    this.dmChannelMembers.set(`${id}-${userIdA}`, userIdA);
    this.dmChannelMembers.set(`${id}-${userIdB}`, userIdB);
    
    return dmChannel;
  }

  // Direct Message methods
  async getDirectMessage(id: number): Promise<DirectMessage | undefined> {
    return this.directMessages.get(id);
  }

  async getDirectMessagesByDmChannel(dmChannelId: number): Promise<DirectMessage[]> {
    const directMessages: DirectMessage[] = [];
    
    for (const message of this.directMessages.values()) {
      if (message.dmChannelId === dmChannelId) {
        directMessages.push(message);
      }
    }
    
    // Sort by createdAt
    return directMessages.sort((a, b) => {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
  }

  async createDirectMessage(message: InsertDirectMessage): Promise<DirectMessage> {
    const id = this.directMessageId++;
    const now = new Date();
    
    const newMessage: DirectMessage = {
      ...message,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.directMessages.set(id, newMessage);
    return newMessage;
  }

  // Role methods
  async getRole(id: number): Promise<Role | undefined> {
    return this.roles.get(id);
  }

  async getRolesByServer(serverId: number): Promise<Role[]> {
    const roles: Role[] = [];
    
    for (const role of this.roles.values()) {
      if (role.serverId === serverId) {
        roles.push(role);
      }
    }
    
    return roles;
  }

  async createRole(role: InsertRole): Promise<Role> {
    const id = this.roleId++;
    const now = new Date();
    
    const newRole: Role = {
      ...role,
      id,
      createdAt: now
    };
    
    this.roles.set(id, newRole);
    return newRole;
  }

  async updateRole(id: number, data: Partial<Role>): Promise<Role | undefined> {
    const role = this.roles.get(id);
    if (!role) return undefined;
    
    const updatedRole = { ...role, ...data };
    this.roles.set(id, updatedRole);
    return updatedRole;
  }

  async deleteRole(id: number): Promise<boolean> {
    // Remove role from users
    for (const key of this.userRoles.keys()) {
      if (key.endsWith(`-${id}`)) {
        this.userRoles.delete(key);
      }
    }
    
    return this.roles.delete(id);
  }

  // User Roles methods
  async assignRoleToUser(userId: number, roleId: number): Promise<boolean> {
    const user = await this.getUser(userId);
    const role = await this.getRole(roleId);
    
    if (!user || !role) return false;
    
    const key = `${userId}-${roleId}`;
    this.userRoles.set(key, roleId);
    return true;
  }

  async removeRoleFromUser(userId: number, roleId: number): Promise<boolean> {
    const key = `${userId}-${roleId}`;
    return this.userRoles.delete(key);
  }

  async getUserRoles(userId: number): Promise<Role[]> {
    const roles: Role[] = [];
    
    for (const [key, roleId] of this.userRoles.entries()) {
      if (key.startsWith(`${userId}-`)) {
        const role = await this.getRole(roleId);
        if (role) {
          roles.push(role);
        }
      }
    }
    
    return roles;
  }

  // Invite methods
  async getInvite(code: string): Promise<Invite | undefined> {
    return this.invites.get(code);
  }

  async createInvite(invite: InsertInvite): Promise<Invite> {
    const id = Math.floor(1000000 + Math.random() * 9000000);
    const now = new Date();
    
    // Generate a random 8-character code
    const code = randomBytes(4).toString('hex');
    
    const newInvite: Invite = {
      ...invite,
      id,
      code,
      uses: 0,
      createdAt: now
    };
    
    this.invites.set(code, newInvite);
    return newInvite;
  }

  async useInvite(code: string): Promise<Invite | undefined> {
    const invite = this.invites.get(code);
    if (!invite) return undefined;
    
    // Check if invite has reached max uses
    if (invite.maxUses && invite.uses >= invite.maxUses) {
      return undefined;
    }
    
    // Check if invite has expired
    if (invite.expiresAt && new Date(invite.expiresAt) < new Date()) {
      return undefined;
    }
    
    const updatedInvite = {
      ...invite,
      uses: invite.uses + 1
    };
    
    this.invites.set(code, updatedInvite);
    return updatedInvite;
  }

  // Bot methods
  async getBot(id: number): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async getBotsByUser(userId: number): Promise<Bot[]> {
    const bots: Bot[] = [];
    
    for (const bot of this.bots.values()) {
      if (bot.ownerId === userId) {
        bots.push(bot);
      }
    }
    
    return bots;
  }

  async createBot(bot: InsertBot): Promise<Bot> {
    const id = this.botId++;
    const now = new Date();
    
    // Generate a random token
    const token = createHash('sha256').update(uuidv4()).digest('hex');
    
    const newBot: Bot = {
      ...bot,
      id,
      token,
      createdAt: now,
      description: bot.description || ""
    };
    
    this.bots.set(id, newBot);
    return newBot;
  }

  // Verification Log methods
  async createVerificationLog(log: Partial<VerificationLog>): Promise<VerificationLog> {
    const id = this.verificationLogId++;
    const now = new Date();
    
    const newLog: VerificationLog = {
      id,
      userId: log.userId!,
      ip: log.ip,
      userAgent: log.userAgent,
      fingerprintId: log.fingerprintId,
      location: log.location,
      createdAt: now, // Always set created time
      verifiedAt: log.verifiedAt
    };
    
    this.verificationLogs.set(id, newLog);
    return newLog;
  }

  async verifyResetCode(email: string, code: string): Promise<boolean> {
    const user = await this.getUserByEmail(email);
    if (!user) {
      return false;
    }
    
    // Find the most recent verification log for this user with a reset code
    const now = new Date();
    let mostRecentLog: VerificationLog | undefined;
    
    // Iterate through all logs to find the most recent one for this user
    for (const log of this.verificationLogs.values()) {
      if (log.userId === user.id && log.location && typeof log.location === 'object' && 'resetCode' in log.location) {
        // Check if this log is more recent than the current most recent log
        if (!mostRecentLog || (log.createdAt && mostRecentLog.createdAt && log.createdAt > mostRecentLog.createdAt)) {
          mostRecentLog = log;
        }
      }
    }
    
    if (!mostRecentLog || !mostRecentLog.location) {
      console.log('No reset code found for user');
      return false;
    }
    
    const resetData = mostRecentLog.location as { resetCode: string; expiresAt: Date };
    
    // Check if the code matches and hasn't expired
    if (resetData.resetCode !== code) {
      console.log('Reset code does not match');
      return false;
    }
    
    // Check if the code has expired
    if (resetData.expiresAt && new Date(resetData.expiresAt) < now) {
      console.log('Reset code has expired');
      return false;
    }
    
    // Mark this log as verified
    mostRecentLog.verifiedAt = now;
    
    return true;
  }
}

export const storage = new MemStorage();
