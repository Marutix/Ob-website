import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { storage } from '../storage';

// Use the JWT_SECRET from environment variables
const JWT_SECRET = process.env.JWT_SECRET || 'nexus_secret_key_for_jwt_token_generation_and_verification';

console.log('JWT_SECRET is:', JWT_SECRET === process.env.JWT_SECRET ? 'using environment variable' : 'using fallback');
const JWT_EXPIRATION = '7d'; // Token expires in 7 days

interface JwtPayload {
  userId: number;
  username: string;
  email: string;
  iat?: number;
  exp?: number;
}

/**
 * Generate a JWT token for authentication
 * 
 * @param userId The user's ID
 * @param username The user's username
 * @param email The user's email
 * @returns A signed JWT token
 */
export function generateJWT(userId: number, username: string, email: string): string {
  const payload: JwtPayload = {
    userId,
    username,
    email
  };
  
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRATION });
}

/**
 * Verify JWT token in Authorization header
 */
export function verifyToken(token: string): JwtPayload | null {
  try {
    console.log('Verifying token...');
    const payload = jwt.verify(token, JWT_SECRET) as JwtPayload;
    console.log('Token verified successfully for user:', payload.username);
    return payload;
  } catch (err) {
    console.error('Token verification failed:', err instanceof Error ? err.message : 'Unknown error');
    return null;
  }
}

/**
 * Authentication middleware to protect routes
 * 
 * Requires a valid JWT token in the Authorization header
 */
export function authenticate(req: Request, res: Response, next: NextFunction) {
  console.log('Authentication middleware called for:', req.url);
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    console.log('No Authorization header present');
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  if (!authHeader.startsWith('Bearer ')) {
    console.log('Authorization header does not start with Bearer');
    return res.status(401).json({ message: 'Invalid authorization format. Expected Bearer token' });
  }
  
  const token = authHeader.split(' ')[1];
  console.log(`Token received with length: ${token.length}`);
  
  const payload = verifyToken(token);
  
  if (!payload) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
  
  console.log(`Token verified for user: ${payload.username}`);
  
  // Fetch the user's full data from storage
  storage.getUser(payload.userId).then(user => {
    if (!user) {
      console.log(`User not found for ID: ${payload.userId}`);
      return res.status(401).json({ message: 'User not found' });
    }
    
    console.log(`User authenticated: ${user.username} (${user.email})`);
    
    // Set user data in request for use in subsequent middleware/routes
    req.user = user;
    next();
  }).catch(err => {
    console.error('Error fetching user data:', err);
    return res.status(500).json({ message: 'Server error during authentication' });
  });
}

/**
 * Authorization middleware to restrict access to admin users
 * 
 * Requires the authenticate middleware to be called first
 */
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  try {
    const user = await storage.getUser(req.user.id);
    
    if (!user) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    if (user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }
    
    next();
  } catch (error) {
    console.error('Admin authorization error:', error);
    res.status(500).json({ message: 'Server error during authorization' });
  }
}

// Export middleware as an object for easier imports in routes
export const authMiddleware = {
  authenticate,
  requireAdmin
};
