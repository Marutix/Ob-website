import { Request, Response, NextFunction } from 'express';

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

// In-memory storage for rate limit data
const rateLimitStore = new Map<string, RateLimitEntry>();

export const rateLimiter = (windowMs: number = 60000, maxRequests: number = 60) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Get client identifier (IP address or user ID if available)
    const clientId = (req as any).userId 
      ? `user:${(req as any).userId}` 
      : `ip:${req.ip || req.socket.remoteAddress}`;
    
    const now = Date.now();
    
    // Get or create rate limit entry
    let entry = rateLimitStore.get(clientId);
    if (!entry || entry.resetTime < now) {
      // Reset or initialize entry
      entry = {
        count: 0,
        resetTime: now + windowMs
      };
    }
    
    // Increment request count
    entry.count++;
    
    // Update entry in store
    rateLimitStore.set(clientId, entry);
    
    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit', maxRequests.toString());
    res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - entry.count).toString());
    res.setHeader('X-RateLimit-Reset', Math.ceil(entry.resetTime / 1000).toString());
    
    // Check if rate limit exceeded
    if (entry.count > maxRequests) {
      return res.status(429).json({
        message: "Too many requests, please try again later.",
        retryAfter: Math.ceil((entry.resetTime - now) / 1000)
      });
    }
    
    next();
  };
};

// Specific rate limiters for different endpoints
export const authRateLimiter = rateLimiter(60000, 10); // 10 requests per minute for auth endpoints
export const messageRateLimiter = rateLimiter(10000, 20); // 20 requests per 10 seconds for message endpoints
export const userRateLimiter = rateLimiter(60000, 30); // 30 requests per minute for user endpoints
export const serverRateLimiter = rateLimiter(60000, 20); // 20 requests per minute for server endpoints
export const channelRateLimiter = rateLimiter(60000, 30); // 30 requests per minute for channel endpoints
export const developerRateLimiter = rateLimiter(60000, 15); // 15 requests per minute for developer endpoints

// Clean up expired entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [clientId, entry] of rateLimitStore.entries()) {
    if (entry.resetTime < now) {
      rateLimitStore.delete(clientId);
    }
  }
}, 60000); // Run every minute
