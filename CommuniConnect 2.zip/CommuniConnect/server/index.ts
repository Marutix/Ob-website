import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

// Set up environment variables for services
process.env.DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || 'https://discord.com/api/webhooks/1367622246457278664/OT96tw9DPeh8YUcKbxRkjYr1y8Py-ldD9DSTyv5RxJ2g-WPOyClA-NYmPsxy1SHOy6gb';

// Email credentials
process.env.EMAIL_USER = process.env.EMAIL_USER || 'EUPNSeth@gmail.com';
process.env.EMAIL_PASS = process.env.EMAIL_PASS || 'cujqos-zyfniW-benke6';

// JWT secret for authentication tokens
process.env.JWT_SECRET = process.env.JWT_SECRET || 'nexus_secret_key_for_jwt_token_generation_and_verification';

console.log('Environment variables set:');
console.log('- EMAIL_USER:', process.env.EMAIL_USER ? 'Set' : 'Not set');
console.log('- EMAIL_PASS:', process.env.EMAIL_PASS ? 'Set' : 'Not set');
console.log('- DISCORD_WEBHOOK_URL:', process.env.DISCORD_WEBHOOK_URL ? 'Set' : 'Not set');
console.log('- JWT_SECRET:', process.env.JWT_SECRET ? 'Set' : 'Not set');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Import services here after environment variables are set
  const { emailService } = await import('./services/email.service');
  const { webhookService } = await import('./services/webhook.service');
  
  // Initialize services
  console.log("=== Initializing services ===");
  try {
    await emailService.initialize();
    console.log("Email service initialized successfully");
  } catch (error) {
    console.error("Failed to initialize email service:", error);
  }
  
  try {
    await webhookService.initialize();
    console.log("Webhook service initialized successfully");
  } catch (error) {
    console.error("Failed to initialize webhook service:", error);
  }
  console.log("=== Service initialization complete ===");
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
