/**
 * Generates a random numeric or alphanumeric code of specified length.
 * 
 * @param length The length of the code to generate
 * @param type The type of code to generate: 'numeric' or 'alphanumeric'
 * @returns A random code of the specified length and type
 */
export function generateRandomCode(
  length: number,
  type: 'numeric' | 'alphanumeric' = 'alphanumeric'
): string {
  const chars = type === 'numeric'
    ? '0123456789'
    : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

  let result = '';
  const charsLength = chars.length;

  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * charsLength));
  }

  return result;
}
