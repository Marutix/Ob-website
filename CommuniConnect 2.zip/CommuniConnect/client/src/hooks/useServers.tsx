import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Server, InsertServer } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export function useServers() {
  const { toast } = useToast();
  
  // Fetch all servers for the current user
  const { 
    data: servers, 
    isLoading, 
    isError,
    error
  } = useQuery({
    queryKey: ['/api/servers'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Create server mutation
  const createServerMutation = useMutation({
    mutationFn: async (serverData: InsertServer) => {
      const response = await apiRequest("POST", "/api/servers", serverData);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create server");
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate servers query to refetch the list
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to create server",
        description: error.message,
      });
    }
  });
  
  // Update server mutation
  const updateServerMutation = useMutation({
    mutationFn: async ({ serverId, data }: { serverId: number, data: Partial<Server> }) => {
      const response = await apiRequest("PATCH", `/api/servers/${serverId}`, data);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update server");
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Update the server in the cache
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${variables.serverId}`] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to update server",
        description: error.message,
      });
    }
  });
  
  // Delete server mutation
  const deleteServerMutation = useMutation({
    mutationFn: async (serverId: number) => {
      const response = await apiRequest("DELETE", `/api/servers/${serverId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete server");
      }
      
      return true;
    },
    onSuccess: () => {
      // Invalidate servers query
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      
      toast({
        title: "Server deleted",
        description: "The server has been deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete server",
        description: error.message,
      });
    }
  });
  
  // Create server invite mutation
  const createInviteMutation = useMutation({
    mutationFn: async ({ 
      serverId, 
      maxUses, 
      expiresAt 
    }: { 
      serverId: number, 
      maxUses?: number, 
      expiresAt?: string 
    }) => {
      const response = await apiRequest("POST", `/api/servers/${serverId}/invites`, {
        maxUses,
        expiresAt
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create invite");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Invite created",
        description: "The server invite has been created successfully",
      });
      return data;
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to create invite",
        description: error.message,
      });
    }
  });
  
  const createServer = async (serverData: InsertServer) => {
    return createServerMutation.mutateAsync(serverData);
  };
  
  const updateServer = async (serverId: number, data: Partial<Server>) => {
    return updateServerMutation.mutateAsync({ serverId, data });
  };
  
  const deleteServer = async (serverId: number) => {
    return deleteServerMutation.mutateAsync(serverId);
  };
  
  const createInvite = async (serverId: number, maxUses?: number, expiresAt?: string) => {
    return createInviteMutation.mutateAsync({ serverId, maxUses, expiresAt });
  };
  
  return {
    servers,
    isLoading,
    isError,
    error,
    createServer,
    updateServer,
    deleteServer,
    createInvite,
  };
}
