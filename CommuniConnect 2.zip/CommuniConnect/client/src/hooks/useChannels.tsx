import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Channel, InsertChannel, Server, User } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "./useWebSocket";
import { useEffect } from "react";

export function useChannels(serverId?: number | null, channelId?: number | null) {
  const { toast } = useToast();
  const { subscribeToChannel, unsubscribeFromChannel } = useWebSocket();
  
  // Fetch server data
  const { 
    data: serverData, 
    isLoading: isLoadingServer 
  } = useQuery({
    queryKey: [`/api/servers/${serverId}`],
    enabled: !!serverId,
  });
  
  // Extract server, channels, and members from server data
  const server = serverData?.server as Server | undefined;
  const channels = serverData?.channels as Channel[] | undefined;
  const members = serverData?.members as User[] | undefined;
  const roles = serverData?.roles;
  
  // Fetch current channel data if channelId is provided
  const {
    data: channelData,
    isLoading: isLoadingChannel
  } = useQuery({
    queryKey: [`/api/channels/${channelId}`],
    enabled: !!channelId,
  });
  
  const currentChannel = channelData?.channel as Channel | undefined;
  
  // Subscribe to channel for real-time updates when channelId changes
  useEffect(() => {
    if (channelId) {
      subscribeToChannel(channelId);
      
      return () => {
        unsubscribeFromChannel(channelId);
      };
    }
  }, [channelId, subscribeToChannel, unsubscribeFromChannel]);
  
  // Create channel mutation
  const createChannelMutation = useMutation({
    mutationFn: async (channelData: InsertChannel) => {
      const response = await apiRequest(
        "POST", 
        `/api/servers/${channelData.serverId}/channels`, 
        channelData
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create channel");
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate server data to refetch channels
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${variables.serverId}`] });
      
      toast({
        title: "Channel created",
        description: `Channel #${variables.name} has been created successfully`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to create channel",
        description: error.message,
      });
    }
  });
  
  // Update channel mutation
  const updateChannelMutation = useMutation({
    mutationFn: async ({ 
      channelId, 
      data 
    }: { 
      channelId: number, 
      data: Partial<Channel> 
    }) => {
      const response = await apiRequest("PATCH", `/api/channels/${channelId}`, data);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update channel");
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate channel data
      queryClient.invalidateQueries({ queryKey: [`/api/channels/${variables.channelId}`] });
      
      // Get the server ID from the channel and invalidate server data too
      const channel = queryClient.getQueryData([`/api/channels/${variables.channelId}`]) as { channel: Channel } | undefined;
      if (channel?.channel.serverId) {
        queryClient.invalidateQueries({ queryKey: [`/api/servers/${channel.channel.serverId}`] });
      }
      
      toast({
        title: "Channel updated",
        description: "The channel has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to update channel",
        description: error.message,
      });
    }
  });
  
  // Delete channel mutation
  const deleteChannelMutation = useMutation({
    mutationFn: async (channelId: number) => {
      const response = await apiRequest("DELETE", `/api/channels/${channelId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete channel");
      }
      
      return response.json();
    },
    onSuccess: (data, channelId) => {
      // Get the server ID from the channel and invalidate server data
      const channel = queryClient.getQueryData([`/api/channels/${channelId}`]) as { channel: Channel } | undefined;
      if (channel?.channel.serverId) {
        queryClient.invalidateQueries({ queryKey: [`/api/servers/${channel.channel.serverId}`] });
      }
      
      // Remove channel data from cache
      queryClient.removeQueries({ queryKey: [`/api/channels/${channelId}`] });
      
      toast({
        title: "Channel deleted",
        description: "The channel has been deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete channel",
        description: error.message,
      });
    }
  });
  
  // Function to create a new channel
  const createChannel = async (channelData: InsertChannel) => {
    return createChannelMutation.mutateAsync(channelData);
  };
  
  // Function to update a channel
  const updateChannel = async (channelId: number, data: Partial<Channel>) => {
    return updateChannelMutation.mutateAsync({ channelId, data });
  };
  
  // Function to delete a channel
  const deleteChannel = async (channelId: number) => {
    return deleteChannelMutation.mutateAsync(channelId);
  };
  
  return {
    server,
    channels,
    members,
    roles,
    currentChannel,
    isLoading: isLoadingServer || isLoadingChannel,
    createChannel,
    updateChannel,
    deleteChannel,
  };
}

// Hook for DM channels
export function useDmChannel(dmChannelId?: number | null) {
  const { toast } = useToast();
  const { subscribeToDmChannel, unsubscribeFromDmChannel } = useWebSocket();
  
  // Fetch DM channel data
  const {
    data: dmChannelData,
    isLoading
  } = useQuery({
    queryKey: [`/api/dm/${dmChannelId}`],
    enabled: !!dmChannelId,
  });
  
  // Extract DM channel and other user
  const dmChannel = dmChannelData?.dmChannel;
  const otherUser = dmChannelData?.otherUser as User | undefined;
  
  // Subscribe to DM channel for real-time updates
  useEffect(() => {
    if (dmChannelId) {
      subscribeToDmChannel(dmChannelId);
      
      return () => {
        unsubscribeFromDmChannel(dmChannelId);
      };
    }
  }, [dmChannelId, subscribeToDmChannel, unsubscribeFromDmChannel]);
  
  // Create DM channel mutation
  const createDmChannelMutation = useMutation({
    mutationFn: async (otherUserId: number) => {
      const response = await apiRequest("POST", "/api/users/dm", { otherUserId });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create DM channel");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
      
      // Return the dmChannel data for navigation
      return data.dmChannel;
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to create DM channel",
        description: error.message,
      });
    }
  });
  
  // Function to create or open a DM channel
  const createDmChannel = async (otherUserId: number) => {
    return createDmChannelMutation.mutateAsync(otherUserId);
  };
  
  return {
    dmChannel,
    otherUser,
    isLoading,
    createDmChannel,
  };
}
