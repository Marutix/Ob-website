import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "./useWebSocket";
import { useEffect } from "react";
import { MessageWithUser } from "@/lib/types";

export function useMessages(channelId?: number | null, dmChannelId?: number | null) {
  const { toast } = useToast();
  const { events } = useWebSocket();
  
  // Fetch messages for a channel
  const {
    data: messagesData,
    isLoading: isLoadingMessages,
    isError: isMessagesError,
    error: messagesError
  } = useQuery({
    queryKey: [`/api/channels/${channelId}/messages`],
    enabled: !!channelId,
  });
  
  // Fetch direct messages
  const {
    data: dmMessagesData,
    isLoading: isLoadingDmMessages,
    isError: isDmMessagesError,
    error: dmMessagesError
  } = useQuery({
    queryKey: [`/api/dm/${dmChannelId}/messages`],
    enabled: !!dmChannelId,
  });
  
  const messages = messagesData?.messages || [];
  const directMessages = dmMessagesData?.messages || [];
  
  // Listen for message events
  useEffect(() => {
    if (!events) return;

    const handleNewMessage = (payload: MessageWithUser) => {
      // Update messages cache when a new message is received
      if (channelId && payload.channelId === channelId) {
        queryClient.setQueryData(
          [`/api/channels/${channelId}/messages`],
          (old: any) => ({
            messages: [...(old?.messages || []), payload]
          })
        );
      }
    };
    
    const handleUpdateMessage = (payload: MessageWithUser) => {
      // Update message in cache when a message is updated
      if (channelId && payload.channelId === channelId) {
        queryClient.setQueryData(
          [`/api/channels/${channelId}/messages`],
          (old: any) => ({
            messages: (old?.messages || []).map((msg: MessageWithUser) =>
              msg.id === payload.id ? payload : msg
            )
          })
        );
      }
    };
    
    const handleDeleteMessage = (payload: { id: number }) => {
      // Remove message from cache when a message is deleted
      if (channelId) {
        queryClient.setQueryData(
          [`/api/channels/${channelId}/messages`],
          (old: any) => ({
            messages: (old?.messages || []).filter((msg: MessageWithUser) => msg.id !== payload.id)
          })
        );
      }
    };
    
    const handleNewDirectMessage = (payload: MessageWithUser) => {
      // Update direct messages cache when a new DM is received
      if (dmChannelId && payload.dmChannelId === dmChannelId) {
        queryClient.setQueryData(
          [`/api/dm/${dmChannelId}/messages`],
          (old: any) => ({
            messages: [...(old?.messages || []), payload]
          })
        );
      }
    };
    
    // Subscribe to events
    const unsubscribeNewMessage = events.on("NEW_MESSAGE", handleNewMessage);
    const unsubscribeUpdateMessage = events.on("UPDATE_MESSAGE", handleUpdateMessage);
    const unsubscribeDeleteMessage = events.on("DELETE_MESSAGE", handleDeleteMessage);
    const unsubscribeNewDirectMessage = events.on("NEW_DIRECT_MESSAGE", handleNewDirectMessage);
    
    return () => {
      // Unsubscribe from events
      unsubscribeNewMessage();
      unsubscribeUpdateMessage();
      unsubscribeDeleteMessage();
      unsubscribeNewDirectMessage();
    };
  }, [events, channelId, dmChannelId]);
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ channelId, content }: { channelId: number, content: string }) => {
      const response = await apiRequest("POST", `/api/channels/${channelId}/messages`, { content });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to send message");
      }
      
      return response.json();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to send message",
        description: error.message,
      });
    }
  });
  
  // Update message mutation
  const updateMessageMutation = useMutation({
    mutationFn: async ({ messageId, content }: { messageId: number, content: string }) => {
      const response = await apiRequest("PATCH", `/api/messages/${messageId}`, { content });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update message");
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // No need to update cache manually as it's handled by WebSocket
      toast({
        title: "Message updated",
        description: "Your message has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to update message",
        description: error.message,
      });
    }
  });
  
  // Delete message mutation
  const deleteMessageMutation = useMutation({
    mutationFn: async (messageId: number) => {
      const response = await apiRequest("DELETE", `/api/messages/${messageId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete message");
      }
      
      return true;
    },
    onSuccess: () => {
      // No need to update cache manually as it's handled by WebSocket
      toast({
        title: "Message deleted",
        description: "Your message has been deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete message",
        description: error.message,
      });
    }
  });
  
  // Send direct message mutation
  const sendDirectMessageMutation = useMutation({
    mutationFn: async ({ dmChannelId, content }: { dmChannelId: number, content: string }) => {
      const response = await apiRequest("POST", `/api/dm/${dmChannelId}/messages`, { content });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to send direct message");
      }
      
      return response.json();
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to send message",
        description: error.message,
      });
    }
  });
  
  // Function to send a message to a channel
  const sendMessage = async (channelId: number, content: string) => {
    return sendMessageMutation.mutateAsync({ channelId, content });
  };
  
  // Function to update a message
  const updateMessage = async (messageId: number, content: string) => {
    return updateMessageMutation.mutateAsync({ messageId, content });
  };
  
  // Function to delete a message
  const deleteMessage = async (messageId: number) => {
    return deleteMessageMutation.mutateAsync(messageId);
  };
  
  // Function to send a direct message
  const sendDirectMessage = async (dmChannelId: number, content: string) => {
    return sendDirectMessageMutation.mutateAsync({ dmChannelId, content });
  };
  
  return {
    messages,
    directMessages,
    isLoading: isLoadingMessages || isLoadingDmMessages,
    isError: isMessagesError || isDmMessagesError,
    error: messagesError || dmMessagesError,
    sendMessage,
    updateMessage,
    deleteMessage,
    sendDirectMessage,
  };
}
