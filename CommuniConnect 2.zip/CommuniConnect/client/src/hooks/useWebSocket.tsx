import { useEffect, useCallback } from "react";
import { useWebSocketContext } from "@/contexts/WebSocketContext";
import { useAuth } from "./useAuth";

export function useWebSocket() {
  const context = useWebSocketContext();
  const { socket, isConnected, events, connect, disconnect } = context;
  const { isAuthenticated } = useAuth();
  
  // Auto-connect when authenticated
  useEffect(() => {
    if (isAuthenticated && !isConnected) {
      connect();
    }
  }, [isAuthenticated, isConnected, connect]);
  
  // Handle connection errors and reconnect
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible" && isAuthenticated && !isConnected) {
        connect();
      }
    };
    
    document.addEventListener("visibilitychange", handleVisibilityChange);
    
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [isAuthenticated, isConnected, connect]);
  
  const sendMessage = useCallback((type: string, payload: any) => {
    if (!isConnected || !socket) {
      console.error("Cannot send message: WebSocket not connected");
      return false;
    }
    
    try {
      socket.send(JSON.stringify({ type, payload }));
      return true;
    } catch (error) {
      console.error("Error sending WebSocket message:", error);
      return false;
    }
  }, [isConnected, socket]);
  
  const subscribeToChannel = useCallback((channelId: number) => {
    return sendMessage("SUBSCRIBE_CHANNEL", { channelId });
  }, [sendMessage]);
  
  const unsubscribeFromChannel = useCallback((channelId: number) => {
    return sendMessage("UNSUBSCRIBE_CHANNEL", { channelId });
  }, [sendMessage]);
  
  const subscribeToDmChannel = useCallback((dmChannelId: number) => {
    return sendMessage("SUBSCRIBE_DM", { dmChannelId });
  }, [sendMessage]);
  
  const unsubscribeFromDmChannel = useCallback((dmChannelId: number) => {
    return sendMessage("UNSUBSCRIBE_DM", { dmChannelId });
  }, [sendMessage]);
  
  return {
    socket,
    isConnected,
    events,
    connect,
    disconnect,
    sendMessage,
    subscribeToChannel,
    unsubscribeFromChannel,
    subscribeToDmChannel,
    unsubscribeFromDmChannel
  };
}
