import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Server } from "@/lib/types";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

const serverFormSchema = z.object({
  name: z.string().min(3, "Server name must be at least 3 characters."),
  description: z.string().max(200, "Description must not be longer than 200 characters.").optional(),
  icon: z.string().url("Please enter a valid URL.").optional().or(z.literal("")),
  banner: z.string().url("Please enter a valid URL.").optional().or(z.literal("")),
});

const inviteFormSchema = z.object({
  maxUses: z.string().optional(),
  expiresIn: z.string().optional(),
});

interface ServerSettingsProps {
  server: Server | null;
  isOwner: boolean;
}

export default function ServerSettings({ server, isOwner }: ServerSettingsProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [isUpdatingServer, setIsUpdatingServer] = useState(false);
  const [isCreatingInvite, setIsCreatingInvite] = useState(false);
  const [isShowingConfirmDelete, setIsShowingConfirmDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  
  const serverForm = useForm<z.infer<typeof serverFormSchema>>({
    resolver: zodResolver(serverFormSchema),
    defaultValues: {
      name: server?.name || "",
      description: server?.description || "",
      icon: server?.icon || "",
      banner: server?.banner || "",
    },
  });
  
  const inviteForm = useForm<z.infer<typeof inviteFormSchema>>({
    resolver: zodResolver(inviteFormSchema),
    defaultValues: {
      maxUses: "",
      expiresIn: "never",
    },
  });

  const onUpdateServer = async (data: z.infer<typeof serverFormSchema>) => {
    if (!server) return;
    
    try {
      setIsUpdatingServer(true);
      
      const response = await apiRequest("PATCH", `/api/servers/${server.id}`, {
        name: data.name,
        description: data.description || "",
        icon: data.icon || "",
        banner: data.banner || "",
      });
      
      if (response.ok) {
        const updatedServer = await response.json();
        
        // Invalidate server data queries
        queryClient.invalidateQueries({ queryKey: [`/api/servers/${server.id}`] });
        queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
        
        toast({
          title: "Server updated",
          description: "Your server has been updated successfully",
        });
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Server update failed",
          description: error.message || "An error occurred while updating your server",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Server update failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsUpdatingServer(false);
    }
  };
  
  const onCreateInvite = async (data: z.infer<typeof inviteFormSchema>) => {
    if (!server) return;
    
    try {
      setIsCreatingInvite(true);
      
      // Convert maxUses to a number
      const maxUses = data.maxUses ? parseInt(data.maxUses) : undefined;
      
      // Calculate expiration date based on expiresIn
      let expiresAt: Date | undefined = undefined;
      if (data.expiresIn === "30min") {
        expiresAt = new Date(Date.now() + 30 * 60 * 1000);
      } else if (data.expiresIn === "1hour") {
        expiresAt = new Date(Date.now() + 60 * 60 * 1000);
      } else if (data.expiresIn === "6hours") {
        expiresAt = new Date(Date.now() + 6 * 60 * 60 * 1000);
      } else if (data.expiresIn === "12hours") {
        expiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000);
      } else if (data.expiresIn === "1day") {
        expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
      } else if (data.expiresIn === "7days") {
        expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      }
      
      const response = await apiRequest("POST", `/api/servers/${server.id}/invites`, {
        maxUses,
        expiresAt: expiresAt?.toISOString(),
      });
      
      if (response.ok) {
        const data = await response.json();
        
        setInviteCode(data.invite.code);
        
        toast({
          title: "Invite created",
          description: "Your invite link has been created successfully",
        });
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Invite creation failed",
          description: error.message || "An error occurred while creating the invite",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Invite creation failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsCreatingInvite(false);
    }
  };
  
  const handleCopyInvite = () => {
    if (!inviteCode) return;
    
    const inviteLink = `${window.location.origin}/invite/${inviteCode}`;
    navigator.clipboard.writeText(inviteLink);
    
    toast({
      title: "Invite link copied",
      description: "The invite link has been copied to your clipboard",
    });
  };
  
  const handleDeleteServer = async () => {
    if (!server || !isOwner) return;
    
    try {
      setIsDeleting(true);
      
      const response = await apiRequest("DELETE", `/api/servers/${server.id}`, {});
      
      if (response.ok) {
        // Invalidate server data queries
        queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
        
        toast({
          title: "Server deleted",
          description: "Your server has been deleted successfully",
        });
        
        // Redirect to home
        window.location.href = "/channels";
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Server deletion failed",
          description: error.message || "An error occurred while deleting your server",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Server deletion failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsDeleting(false);
      setIsShowingConfirmDelete(false);
    }
  };

  if (!server) {
    return (
      <div className="w-full max-w-4xl mx-auto py-8">
        <Card>
          <CardContent className="py-8">
            <div className="text-center">
              <p>Server not found or loading...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <Tabs 
      defaultValue="overview" 
      className="w-full max-w-4xl mx-auto"
      value={activeTab}
      onValueChange={setActiveTab}
    >
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">{server.name} Settings</h1>
      </div>
      
      <div className="flex">
        <TabsList className="flex-col h-auto p-0 bg-transparent space-y-1 mr-8 w-48">
          <TabsTrigger 
            value="overview" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger 
            value="roles" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
            disabled={!isOwner}
          >
            Roles
          </TabsTrigger>
          <TabsTrigger 
            value="members" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Members
          </TabsTrigger>
          <TabsTrigger 
            value="invites" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Invites
          </TabsTrigger>
          <TabsTrigger 
            value="integrations" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
            disabled={!isOwner}
          >
            Integrations
          </TabsTrigger>
          {isOwner && (
            <TabsTrigger 
              value="delete" 
              className="justify-start w-full px-4 py-2 text-left text-destructive data-[state=active]:bg-destructive/10"
            >
              Delete Server
            </TabsTrigger>
          )}
        </TabsList>
        
        <div className="flex-1">
          <TabsContent value="overview" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Server Overview</CardTitle>
                <CardDescription>
                  Manage your server information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...serverForm}>
                  <form onSubmit={serverForm.handleSubmit(onUpdateServer)} className="space-y-4">
                    <FormField
                      control={serverForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Server Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="My Awesome Server" 
                              {...field} 
                              disabled={!isOwner}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={serverForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your server" 
                              className="resize-none" 
                              {...field} 
                              disabled={!isOwner}
                            />
                          </FormControl>
                          <FormDescription>
                            The description will be displayed on the server discovery page. Max 200 characters.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={serverForm.control}
                        name="icon"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Server Icon URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://example.com/icon.png" 
                                {...field} 
                                disabled={!isOwner}
                              />
                            </FormControl>
                            <FormDescription>
                              Enter a URL for your server icon
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={serverForm.control}
                        name="banner"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Server Banner URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://example.com/banner.png" 
                                {...field} 
                                disabled={!isOwner}
                              />
                            </FormControl>
                            <FormDescription>
                              Enter a URL for your server banner
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {isOwner && (
                      <Button 
                        type="submit" 
                        disabled={isUpdatingServer || !serverForm.formState.isDirty}
                      >
                        {isUpdatingServer ? "Updating..." : "Update Server"}
                      </Button>
                    )}
                  </form>
                </Form>
                
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Server Information</h3>
                  
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium">Server ID</h4>
                        <p className="text-sm text-muted-foreground">{server.id}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Created At</h4>
                        <p className="text-sm text-muted-foreground">
                          {new Date(server.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Owner</h4>
                        <p className="text-sm text-muted-foreground">{isOwner ? "You" : "Someone else"}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Server Region</h4>
                        <p className="text-sm text-muted-foreground">Automatic</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="roles" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Server Roles</CardTitle>
                <CardDescription>
                  Manage roles and permissions for your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between mb-4">
                  <h3 className="text-lg font-medium">Roles</h3>
                  <Button variant="outline" size="sm">
                    Create Role
                  </Button>
                </div>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role Name</TableHead>
                      <TableHead>Members</TableHead>
                      <TableHead>Permissions</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                          Admin
                        </div>
                      </TableCell>
                      <TableCell>1</TableCell>
                      <TableCell>Administrator</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                          Moderator
                        </div>
                      </TableCell>
                      <TableCell>2</TableCell>
                      <TableCell>Kick Members, Manage Messages</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-3 h-3 rounded-full bg-gray-500 mr-2"></div>
                          @everyone
                        </div>
                      </TableCell>
                      <TableCell>All</TableCell>
                      <TableCell>Read Messages, Send Messages</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="members" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Server Members</CardTitle>
                <CardDescription>
                  Manage members of your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between mb-4">
                  <h3 className="text-lg font-medium">Members</h3>
                  <Input 
                    placeholder="Search members..." 
                    className="w-64"
                  />
                </div>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Username</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-primary/20 mr-2"></div>
                          TestUser#0001
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-green-500">Admin</Badge>
                      </TableCell>
                      <TableCell>3 days ago</TableCell>
                      <TableCell className="text-right">
                        {isOwner && <Button variant="ghost" size="sm">Manage</Button>}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-primary/20 mr-2"></div>
                          User2#1234
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-blue-500">Moderator</Badge>
                      </TableCell>
                      <TableCell>5 days ago</TableCell>
                      <TableCell className="text-right">
                        {isOwner && <Button variant="ghost" size="sm">Manage</Button>}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-primary/20 mr-2"></div>
                          User3#5678
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">@everyone</Badge>
                      </TableCell>
                      <TableCell>1 week ago</TableCell>
                      <TableCell className="text-right">
                        {isOwner && <Button variant="ghost" size="sm">Manage</Button>}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="invites" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Server Invites</CardTitle>
                <CardDescription>
                  Manage invites to your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between mb-4">
                  <h3 className="text-lg font-medium">Create Invite</h3>
                </div>
                
                <Form {...inviteForm}>
                  <form onSubmit={inviteForm.handleSubmit(onCreateInvite)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={inviteForm.control}
                        name="maxUses"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Max Uses</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="Unlimited" 
                                {...field} 
                                min="0"
                              />
                            </FormControl>
                            <FormDescription>
                              Number of times this invite can be used (blank for unlimited)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={inviteForm.control}
                        name="expiresIn"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Expires After</FormLabel>
                            <select
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              {...field}
                            >
                              <option value="never">Never</option>
                              <option value="30min">30 minutes</option>
                              <option value="1hour">1 hour</option>
                              <option value="6hours">6 hours</option>
                              <option value="12hours">12 hours</option>
                              <option value="1day">1 day</option>
                              <option value="7days">7 days</option>
                            </select>
                            <FormDescription>
                              How long the invite will be valid
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      disabled={isCreatingInvite}
                    >
                      {isCreatingInvite ? "Creating..." : "Create Invite"}
                    </Button>
                  </form>
                </Form>
                
                {inviteCode && (
                  <div className="mt-4 p-4 bg-secondary/50 rounded-md">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium">Invite Link</h4>
                        <p className="text-sm text-muted-foreground mb-2">Share this link to invite people to your server</p>
                        <code className="bg-secondary p-2 rounded">{`${window.location.origin}/invite/${inviteCode}`}</code>
                      </div>
                      <Button onClick={handleCopyInvite}>Copy</Button>
                    </div>
                  </div>
                )}
                
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Active Invites</h3>
                  
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Created By</TableHead>
                        <TableHead>Uses</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inviteCode ? (
                        <TableRow>
                          <TableCell className="font-medium">{inviteCode}</TableCell>
                          <TableCell>You</TableCell>
                          <TableCell>0 / ∞</TableCell>
                          <TableCell>Never</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">Revoke</Button>
                          </TableCell>
                        </TableRow>
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground py-6">
                            No active invites found. Create one above.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="integrations" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Server Integrations</CardTitle>
                <CardDescription>
                  Manage third-party integrations for your server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Webhooks</h3>
                  
                  <div className="flex justify-between items-center p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">Incoming Webhooks</h4>
                      <p className="text-sm text-muted-foreground">
                        Create webhooks to allow external services to send messages to this server
                      </p>
                    </div>
                    <Button variant="outline">Create Webhook</Button>
                  </div>
                  
                  <div className="flex justify-between items-center p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">Outgoing Webhooks</h4>
                      <p className="text-sm text-muted-foreground">
                        Create webhooks to send server events to external services
                      </p>
                    </div>
                    <Button variant="outline">Create Webhook</Button>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Bot Integrations</h3>
                  
                  <div className="flex justify-between items-center p-4 border rounded-md">
                    <div>
                      <h4 className="font-medium">Manage Bots</h4>
                      <p className="text-sm text-muted-foreground">
                        Add, remove, and configure bots in your server
                      </p>
                    </div>
                    <Button variant="outline">Add Bot</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="delete" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle className="text-destructive">Delete Server</CardTitle>
                <CardDescription>
                  Permanently delete your server and all of its data
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Alert variant="destructive" className="mb-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Warning</AlertTitle>
                  <AlertDescription>
                    This action is irreversible. Once you delete your server, there is no going back.
                    All channels, messages, and data will be permanently deleted.
                  </AlertDescription>
                </Alert>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Danger Zone</h3>
                  
                  <p>
                    Before proceeding, make sure you've backed up any important information.
                    All members will lose access to this server and all its content.
                  </p>
                  
                  <Dialog open={isShowingConfirmDelete} onOpenChange={setIsShowingConfirmDelete}>
                    <DialogTrigger asChild>
                      <Button variant="destructive">Delete Server</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Confirm Server Deletion</DialogTitle>
                      </DialogHeader>
                      <div className="py-4">
                        <p className="mb-4">
                          Please type <strong>{server.name}</strong> to confirm deletion:
                        </p>
                        <Input 
                          placeholder="Type server name here"
                          className="mb-4"
                        />
                        <div className="flex justify-end space-x-2">
                          <Button 
                            variant="outline" 
                            onClick={() => setIsShowingConfirmDelete(false)}
                          >
                            Cancel
                          </Button>
                          <Button 
                            variant="destructive" 
                            onClick={handleDeleteServer}
                            disabled={isDeleting}
                          >
                            {isDeleting ? "Deleting..." : "Delete Server"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </div>
    </Tabs>
  );
}
