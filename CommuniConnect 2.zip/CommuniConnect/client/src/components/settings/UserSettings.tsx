import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";

const profileFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters."),
  bio: z.string().max(160, "Bio must not be longer than 160 characters.").optional(),
  avatar: z.string().url("Please enter a valid URL.").optional().or(z.literal("")),
  banner: z.string().url("Please enter a valid URL.").optional().or(z.literal("")),
});

const passwordFormSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string().min(8, "Password confirmation is required"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

const localeOptions = [
  { value: "en-US", label: "English (US)" },
  { value: "en-GB", label: "English (UK)" },
  { value: "es-ES", label: "Spanish (Spain)" },
  { value: "fr-FR", label: "French (France)" },
  { value: "de-DE", label: "German (Germany)" },
  { value: "ja-JP", label: "Japanese (Japan)" },
  { value: "pt-BR", label: "Portuguese (Brazil)" },
  { value: "ru-RU", label: "Russian (Russia)" },
];

export default function UserSettings() {
  const { user, updateUserProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("account");
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [isUpdatingMfa, setIsUpdatingMfa] = useState(false);
  
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      username: user?.username || "",
      bio: user?.bio || "",
      avatar: user?.avatar || "",
      banner: user?.banner || "",
    },
  });
  
  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const onUpdateProfile = async (data: z.infer<typeof profileFormSchema>) => {
    if (!user) return;
    
    try {
      setIsUpdatingProfile(true);
      
      const response = await apiRequest("PATCH", "/api/users/profile", {
        username: data.username,
        bio: data.bio || "",
        avatar: data.avatar || "",
        banner: data.banner || "",
      });
      
      if (response.ok) {
        const responseData = await response.json();
        
        // Update user in auth context
        updateUserProfile(responseData.user);
        
        // Invalidate user data queries
        queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
        
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully",
        });
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Profile update failed",
          description: error.message || "An error occurred while updating your profile",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Profile update failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsUpdatingProfile(false);
    }
  };
  
  const onChangePassword = async (data: z.infer<typeof passwordFormSchema>) => {
    try {
      setIsChangingPassword(true);
      
      const response = await apiRequest("POST", "/api/users/password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      
      if (response.ok) {
        toast({
          title: "Password changed",
          description: "Your password has been changed successfully",
        });
        
        passwordForm.reset();
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Password change failed",
          description: error.message || "An error occurred while changing your password",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Password change failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsChangingPassword(false);
    }
  };
  
  const handleStatusChange = async (status: string) => {
    try {
      setIsUpdatingStatus(true);
      
      const response = await apiRequest("PATCH", "/api/users/status", {
        status,
      });
      
      if (response.ok) {
        // Update local state
        updateUserProfile({ ...user!, status });
        
        toast({
          title: "Status updated",
          description: `Your status is now set to ${status}`,
        });
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Status update failed",
          description: error.message || "Failed to update status",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Status update failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsUpdatingStatus(false);
    }
  };
  
  const handleMfaToggle = async (enabled: boolean) => {
    try {
      setIsUpdatingMfa(true);
      
      const response = await apiRequest("POST", "/api/users/mfa", {
        enable: enabled,
      });
      
      if (response.ok) {
        // Update local state
        updateUserProfile({ ...user!, mfaEnabled: enabled });
        
        toast({
          title: enabled ? "MFA Enabled" : "MFA Disabled",
          description: enabled 
            ? "Multi-factor authentication has been enabled for your account"
            : "Multi-factor authentication has been disabled for your account",
        });
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "MFA update failed",
          description: error.message || "Failed to update MFA settings",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "MFA update failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsUpdatingMfa(false);
    }
  };

  return (
    <Tabs 
      defaultValue="account" 
      className="w-full max-w-4xl mx-auto"
      value={activeTab}
      onValueChange={setActiveTab}
    >
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">User Settings</h1>
      </div>
      
      <div className="flex">
        <TabsList className="flex-col h-auto p-0 bg-transparent space-y-1 mr-8 w-48">
          <TabsTrigger 
            value="account" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            My Account
          </TabsTrigger>
          <TabsTrigger 
            value="profile" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            User Profile
          </TabsTrigger>
          <TabsTrigger 
            value="privacy" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Privacy & Safety
          </TabsTrigger>
          <TabsTrigger 
            value="appearance" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Appearance
          </TabsTrigger>
          <TabsTrigger 
            value="accessibility" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Accessibility
          </TabsTrigger>
          <TabsTrigger 
            value="notifications" 
            className="justify-start w-full px-4 py-2 text-left data-[state=active]:bg-secondary"
          >
            Notifications
          </TabsTrigger>
        </TabsList>
        
        <div className="flex-1">
          <TabsContent value="account" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>
                  Manage your account information and password
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium">Username</h3>
                      <p className="text-sm text-muted-foreground">{user?.username}#{user?.discriminator}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Email</h3>
                      <p className="text-sm text-muted-foreground">{user?.email}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Account Created</h3>
                      <p className="text-sm text-muted-foreground">
                        {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Unknown"}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">Verification Status</h3>
                      <p className="text-sm text-muted-foreground flex items-center">
                        {user?.verified ? (
                          <>
                            <span className="text-green-500 mr-1">Verified</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                              <polyline points="22 4 12 14.01 9 11.01"/>
                            </svg>
                          </>
                        ) : (
                          <span className="text-yellow-500">Pending Verification</span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onChangePassword)} className="space-y-4">
                    <h3 className="text-lg font-medium">Change Password</h3>
                    
                    <FormField
                      control={passwordForm.control}
                      name="currentPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Current Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="••••••••" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={passwordForm.control}
                        name="newPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>New Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={passwordForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm New Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      disabled={isChangingPassword}
                    >
                      {isChangingPassword ? "Changing..." : "Change Password"}
                    </Button>
                  </form>
                </Form>
                
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Protect your account with 2FA</p>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Switch 
                      checked={user?.mfaEnabled || false}
                      onCheckedChange={handleMfaToggle}
                      disabled={isUpdatingMfa}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="profile" className="space-y-4 mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  Update your profile information visible to other users
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onUpdateProfile)} className="space-y-4">
                    <FormField
                      control={profileForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Your username" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            This is your public display name. 
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us a little bit about yourself" 
                              className="resize-none" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Your bio will be displayed on your profile. Max 160 characters.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={profileForm.control}
                        name="avatar"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Avatar URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://example.com/avatar.png" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Enter a URL for your profile picture
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={profileForm.control}
                        name="banner"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Banner URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="https://example.com/banner.png" 
                                {...field} 
                              />
                            </FormControl>
                            <FormDescription>
                              Enter a URL for your profile banner
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Status</h3>
                      <div className="flex flex-col space-y-2">
                        <div className="flex items-center space-x-2">
                          <Button
                            type="button"
                            variant={user?.status === "online" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleStatusChange("online")}
                            disabled={isUpdatingStatus}
                            className="flex items-center"
                          >
                            <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                            <span>Online</span>
                          </Button>
                          
                          <Button
                            type="button"
                            variant={user?.status === "idle" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleStatusChange("idle")}
                            disabled={isUpdatingStatus}
                            className="flex items-center"
                          >
                            <div className="w-2 h-2 rounded-full bg-yellow-500 mr-2"></div>
                            <span>Idle</span>
                          </Button>
                          
                          <Button
                            type="button"
                            variant={user?.status === "dnd" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleStatusChange("dnd")}
                            disabled={isUpdatingStatus}
                            className="flex items-center"
                          >
                            <div className="w-2 h-2 rounded-full bg-red-500 mr-2"></div>
                            <span>Do Not Disturb</span>
                          </Button>
                          
                          <Button
                            type="button"
                            variant={user?.status === "offline" ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleStatusChange("offline")}
                            disabled={isUpdatingStatus}
                            className="flex items-center"
                          >
                            <div className="w-2 h-2 rounded-full bg-gray-500 mr-2"></div>
                            <span>Invisible</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      type="submit" 
                      disabled={isUpdatingProfile || !profileForm.formState.isDirty}
                    >
                      {isUpdatingProfile ? "Updating..." : "Update Profile"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="privacy" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Privacy & Safety</CardTitle>
                <CardDescription>
                  Manage your privacy settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Privacy Settings</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Who can send you friend requests</p>
                      <p className="text-sm text-muted-foreground">
                        Control who can send you friend requests
                      </p>
                    </div>
                    <Select defaultValue="everyone">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Select option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="everyone">Everyone</SelectItem>
                        <SelectItem value="friends-of-friends">Friends of Friends</SelectItem>
                        <SelectItem value="server-members">Server Members</SelectItem>
                        <SelectItem value="nobody">Nobody</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Who can add you to direct messages</p>
                      <p className="text-sm text-muted-foreground">
                        Control who can message you directly
                      </p>
                    </div>
                    <Select defaultValue="friends">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Select option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="everyone">Everyone</SelectItem>
                        <SelectItem value="friends">Friends Only</SelectItem>
                        <SelectItem value="server-members">Server Members</SelectItem>
                        <SelectItem value="nobody">Nobody</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Safety Settings</h3>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Filter explicit content</p>
                        <p className="text-sm text-muted-foreground">
                          Automatically filter potentially inappropriate content
                        </p>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Allow data collection</p>
                        <p className="text-sm text-muted-foreground">
                          Allow us to collect usage data to improve the service
                        </p>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="appearance" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <CardDescription>
                  Customize how Nexus looks and feels
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Theme</h3>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="border rounded-lg p-2 cursor-pointer hover:border-primary">
                      <div className="aspect-video bg-background border-b"></div>
                      <p className="text-center pt-2">Dark (Default)</p>
                    </div>
                    <div className="border rounded-lg p-2 cursor-pointer hover:border-primary">
                      <div className="aspect-video bg-white border-b"></div>
                      <p className="text-center pt-2">Light</p>
                    </div>
                    <div className="border rounded-lg p-2 cursor-pointer hover:border-primary">
                      <div className="aspect-video bg-gradient-to-r from-background to-white border-b"></div>
                      <p className="text-center pt-2">System Default</p>
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Chat Appearance</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Message Display Density</p>
                      <p className="text-sm text-muted-foreground">
                        Adjust how compact messages appear
                      </p>
                    </div>
                    <Select defaultValue="default">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Select option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cozy">Cozy</SelectItem>
                        <SelectItem value="default">Default</SelectItem>
                        <SelectItem value="compact">Compact</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Font Size</p>
                      <p className="text-sm text-muted-foreground">
                        Adjust text size throughout the app
                      </p>
                    </div>
                    <Select defaultValue="medium">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Select option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                        <SelectItem value="xlarge">Extra Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="accessibility" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Accessibility</CardTitle>
                <CardDescription>
                  Manage accessibility settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Text & Visual</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Reduce Motion</p>
                      <p className="text-sm text-muted-foreground">
                        Reduce animation effects throughout the app
                      </p>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Increase Contrast</p>
                      <p className="text-sm text-muted-foreground">
                        Improve text readability with higher contrast
                      </p>
                    </div>
                    <Switch />
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Audio & Voice</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Text-to-Speech</p>
                      <p className="text-sm text-muted-foreground">
                        Enable text-to-speech for messages
                      </p>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Mono Audio</p>
                      <p className="text-sm text-muted-foreground">
                        Mix left and right audio channels to mono
                      </p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>
                  Manage your notification preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">General Notifications</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Enable Desktop Notifications</p>
                      <p className="text-sm text-muted-foreground">
                        Receive notifications when Nexus is running
                      </p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Enable Sounds</p>
                      <p className="text-sm text-muted-foreground">
                        Play sound effects for notifications
                      </p>
                    </div>
                    <Switch defaultChecked={true} />
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Notification Settings</h3>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Direct Messages</p>
                        <p className="text-sm text-muted-foreground">
                          Notifications for direct messages
                        </p>
                      </div>
                      <Select defaultValue="all">
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="Select option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Messages</SelectItem>
                          <SelectItem value="mentions">Only @mentions</SelectItem>
                          <SelectItem value="none">Nothing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Server Notifications</p>
                        <p className="text-sm text-muted-foreground">
                          Notifications for server messages
                        </p>
                      </div>
                      <Select defaultValue="mentions">
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="Select option" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Messages</SelectItem>
                          <SelectItem value="mentions">Only @mentions</SelectItem>
                          <SelectItem value="none">Nothing</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </div>
    </Tabs>
  );
}
