import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

export function VerificationForm() {
  const { toast } = useToast();
  const { verificationEmail, login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");

  if (!verificationEmail) {
    return (
      <div className="space-y-4 text-center">
        <p className="text-sm text-muted-foreground">
          No verification email found. Please register first.
        </p>
        <Button onClick={() => window.location.href = "/auth/register"}>
          Go to Registration
        </Button>
      </div>
    );
  }

  async function handleVerify() {
    if (!verificationCode || verificationCode.length !== 6) {
      toast({
        title: "Error",
        description: "Please enter the 6-character verification code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/verify", {
        email: verificationEmail,
        code: verificationCode,
      });
      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Success",
          description: "Email verified successfully!",
        });

        // Log in the user with the returned token
        if (result.token && result.user) {
          login(result.token, result.user);
        }

        // Redirect to channels page
        window.location.href = "/channels";
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to verify",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Verification error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-semibold tracking-tight">Verify Your Email</h1>
        <p className="text-sm text-muted-foreground">
          We've sent a verification code to {verificationEmail}.
          <br />Please enter the 6-character code below.
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <label
            htmlFor="code"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Verification Code
          </label>
          <Input
            id="code"
            placeholder="Enter 6-character code"
            value={verificationCode}
            onChange={(e) => {
              const onlyLettersAndNumbers = e.target.value.replace(/[^A-Z0-9]/gi, '');
              if (onlyLettersAndNumbers.length <= 6) {
                setVerificationCode(onlyLettersAndNumbers.toUpperCase());
              }
            }}
            disabled={isLoading}
            className="text-center text-xl tracking-widest"
            maxLength={6}
          />
        </div>

        <Button
          className="w-full"
          onClick={handleVerify}
          disabled={isLoading}
        >
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Verify Email
        </Button>

        <div className="text-center text-sm">
          <p className="text-muted-foreground">
            Didn't receive the code?{" "}
            <Button variant="link" className="p-0" onClick={() => window.location.reload()}>
              Resend
            </Button>
          </p>
        </div>
      </div>
    </div>
  );
}
