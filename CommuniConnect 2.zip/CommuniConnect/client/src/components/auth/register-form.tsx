import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

const registerSchema = z
  .object({
    username: z.string().min(3, {
      message: "Username must be at least 3 characters",
    }),
    displayName: z.string().min(1, {
      message: "Display name is required",
    }),
    email: z.string().email({
      message: "Please enter a valid email address",
    }),
    password: z.string().min(8, {
      message: "Password must be at least 8 characters",
    }),
    confirmPassword: z.string(),
    birthdate: z.string().refine((date) => {
      const birthDate = new Date(date);
      const today = new Date();
      
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      
      return age >= 13;
    }, {
      message: "You must be at least 13 years old to register",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

type RegisterFormData = z.infer<typeof registerSchema>;

export function RegisterForm() {
  const { toast } = useToast();
  const { setVerificationEmail, login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");
  const [storedEmail, setStoredEmail] = useState("");

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      displayName: "",
      email: "",
      password: "",
      confirmPassword: "",
      birthdate: "",
    },
  });

  async function onSubmit(data: RegisterFormData) {
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/register", {
        username: data.username,
        displayName: data.displayName,
        email: data.email,
        password: data.password,
        confirmPassword: data.confirmPassword,
        birthdate: data.birthdate,
      });
      const result = await response.json();

      if (response.ok) {
        console.log('Registration successful:', result);
        
        // Store the email for verification
        setStoredEmail(data.email);
        setVerificationEmail(data.email);
        
        // Check if token was returned (new immediate login feature)
        if (result.token && result.user) {
          // Log the user in automatically
          console.log('Auto-logging in user with token');
          login(result.token, result.user);
          
          toast({
            title: "Account Created",
            description: "Welcome to Nexus! Please check your email for a verification code.",
          });
          
          // Redirect to the home/channels page
          setTimeout(() => {
            window.location.href = "/channels";
          }, 1500); // Give the toast a moment to display
        } else {
          // Fall back to old behavior if token not provided
          toast({
            title: "Success",
            description: "Please check your email for a verification code",
          });
          setShowVerification(true);
        }
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to register",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function handleVerify() {
    if (!verificationCode || verificationCode.length !== 6) {
      toast({
        title: "Error",
        description: "Please enter the 6-character verification code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/verify", {
        email: storedEmail,
        code: verificationCode,
      });
      const result = await response.json();

      if (response.ok) {
        console.log('Verification successful:', result);
        
        // Check if token is returned
        if (result.token) {
          // Fetch user data to complete login
          try {
            const userResponse = await fetch('/api/users/me', {
              headers: {
                'Authorization': `Bearer ${result.token}`,
                'Accept': 'application/json',
              },
            });
            
            if (userResponse.ok) {
              const userData = await userResponse.json();
              console.log('User data retrieved for verified user:', userData);
              
              // Log the user in with the verification token
              login(result.token, userData);
              
              toast({
                title: "Verification Complete",
                description: "Your account is now verified. Welcome to Nexus!",
              });
              
              // Redirect to channels page
              setTimeout(() => {
                window.location.href = "/channels";
              }, 1500);
              return;
            }
          } catch (userError) {
            console.error('Error fetching user after verification:', userError);
          }
        }
        
        // Fallback if token is missing or user fetch fails
        toast({
          title: "Success",
          description: "Email verified successfully! You can now log in.",
        });
        
        // Redirect to login
        setTimeout(() => {
          window.location.href = "/auth/login";
        }, 1500);
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to verify",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Verification error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  if (showVerification) {
    return (
      <div className="space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Verify Your Email</h1>
          <p className="text-sm text-muted-foreground">
            We've sent a verification code to {storedEmail}.
            <br />Please enter the 6-character code below.
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <label
              htmlFor="code"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Verification Code
            </label>
            <Input
              id="code"
              placeholder="Enter 6-character code"
              value={verificationCode}
              onChange={(e) => {
                const onlyLettersAndNumbers = e.target.value.replace(/[^A-Z0-9]/gi, '');
                if (onlyLettersAndNumbers.length <= 6) {
                  setVerificationCode(onlyLettersAndNumbers.toUpperCase());
                }
              }}
              disabled={isLoading}
              className="text-center text-xl tracking-widest"
              maxLength={6}
            />
          </div>

          <Button
            className="w-full"
            onClick={handleVerify}
            disabled={isLoading}
          >
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Verify Email
          </Button>

          <div className="text-center text-sm">
            <p className="text-muted-foreground">
              Didn't receive the code?{" "}
              <Button 
                variant="link" 
                className="p-0" 
                onClick={async () => {
                  try {
                    setIsLoading(true);
                    const response = await apiRequest("POST", "/api/auth/resend-verification", {
                      email: storedEmail
                    });
                    
                    if (response.ok) {
                      toast({
                        title: "Success",
                        description: "Verification code resent. Please check your email.",
                      });
                    } else {
                      const result = await response.json();
                      toast({
                        title: "Error",
                        description: result.message || "Failed to resend verification code",
                        variant: "destructive",
                      });
                    }
                  } catch (error) {
                    console.error("Resend verification error:", error);
                    toast({
                      title: "Error",
                      description: "Something went wrong. Please try again.",
                      variant: "destructive",
                    });
                  } finally {
                    setIsLoading(false);
                  }
                }}
                disabled={isLoading}
              >
                {isLoading ? "Sending..." : "Resend"}
              </Button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-semibold tracking-tight">Create an Account</h1>
        <p className="text-sm text-muted-foreground">
          Enter your information to create an account
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input placeholder="username" {...field} disabled={isLoading} />
                </FormControl>
                <FormDescription>
                  Unique identifier for login.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="displayName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Display Name</FormLabel>
                <FormControl>
                  <Input placeholder="Your visible name" {...field} disabled={isLoading} />
                </FormControl>
                <FormDescription>
                  How others will see you in messages and servers.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input
                    type="email"
                    placeholder="name@example.com"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="birthdate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date of Birth</FormLabel>
                <FormControl>
                  <Input
                    type="date"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormDescription>
                  You must be at least 13 years old to register.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormDescription>
                  Must be at least 8 characters long.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confirm Password</FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button className="w-full" type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Account
          </Button>
        </form>
      </Form>

      <div className="text-center text-sm">
        <p className="text-muted-foreground">
          Already have an account?{" "}
          <Link href="/auth/login">
            <Button variant="link" className="p-0">
              Sign in
            </Button>
          </Link>
        </p>
      </div>
    </div>
  );
}
