import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

const loginSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters",
  }),
  password: z.string().min(8, {
    message: "Password must be at least 8 characters",
  }),
});

type LoginFormData = z.infer<typeof loginSchema>;

export function LoginForm() {
  const { toast } = useToast();
  const { login } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState("");
  const [resetSent, setResetSent] = useState(false);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  async function onSubmit(data: LoginFormData) {
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/login", data);
      const result = await response.json();

      if (response.ok) {
        login(result.token, result.user);
        toast({
          title: "Success",
          description: "You have been logged in",
        });
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to login",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function handleForgotPassword() {
    if (!forgotPasswordEmail || !forgotPasswordEmail.includes("@")) {
      toast({
        title: "Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/forgot-password", {
        email: forgotPasswordEmail,
      });
      const result = await response.json();

      if (response.ok) {
        setResetSent(true);
        toast({
          title: "Success",
          description: result.message || "Reset instructions sent to your email",
        });
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to process request",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Forgot password error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  if (showForgotPassword) {
    return (
      <div className="space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Reset Password</h1>
          <p className="text-sm text-muted-foreground">
            Enter your email address and we'll send you a password reset code
          </p>
        </div>

        {resetSent ? (
          <div className="space-y-4">
            <p className="text-center text-sm">Reset instructions sent!</p>
            <p className="text-center text-sm text-muted-foreground">
              Please check your email for instructions to reset your password.
            </p>
            <Button
              className="w-full"
              variant="outline"
              onClick={() => {
                setShowForgotPassword(false);
                setResetSent(false);
              }}
            >
              Back to Login
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="name@example.com"
                value={forgotPasswordEmail}
                onChange={(e) => setForgotPasswordEmail(e.target.value)}
                disabled={isLoading}
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              onClick={handleForgotPassword}
              disabled={isLoading}
            >
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send Reset Instructions
            </Button>

            <Button
              variant="link"
              className="w-full"
              onClick={() => setShowForgotPassword(false)}
              disabled={isLoading}
            >
              Back to Login
            </Button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1>
        <p className="text-sm text-muted-foreground">
          Enter your credentials to sign in to your account
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input placeholder="username" {...field} disabled={isLoading} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button
            type="button"
            variant="link"
            className="px-0 text-sm font-medium text-muted-foreground"
            onClick={() => setShowForgotPassword(true)}
            disabled={isLoading}
          >
            Forgot password?
          </Button>

          <Button className="w-full" type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Sign In
          </Button>
        </form>
      </Form>

      <div className="text-center text-sm">
        <p className="text-muted-foreground">
          Don't have an account?{" "}
          <Link href="/auth/register">
            <Button variant="link" className="p-0">
              Sign up
            </Button>
          </Link>
        </p>
      </div>
      
      {process.env.NODE_ENV === 'development' && (
        <div className="pt-2 border-t mt-2">
          <p className="text-xs text-muted-foreground mb-2">Debug Tools (Development Only)</p>
          <Button 
            variant="outline" 
            className="w-full text-xs" 
            size="sm"
            onClick={async () => {
              setIsLoading(true);
              try {
                const response = await fetch('/api/debug/auth');
                if (response.ok) {
                  const data = await response.json();
                  login(data.token, data.user);
                  toast({
                    title: "Debug Login",
                    description: "Logged in with test account",
                  });
                } else {
                  toast({
                    title: "Debug Error",
                    description: "Failed to login with test account",
                    variant: "destructive",
                  });
                }
              } catch (error) {
                console.error("Debug login error:", error);
                toast({
                  title: "Error",
                  description: "Something went wrong with debug login",
                  variant: "destructive",
                });
              } finally {
                setIsLoading(false);
              }
            }}
          >
            Debug Login (Test Account)
          </Button>
        </div>
      )}
    </div>
  );
}

function Label({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) {
  return (
    <label
      htmlFor={htmlFor}
      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
    >
      {children}
    </label>
  );
}
