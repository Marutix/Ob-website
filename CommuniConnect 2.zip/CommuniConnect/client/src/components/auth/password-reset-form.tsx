import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const requestResetSchema = z.object({
  email: z.string().email({
    message: "Please enter a valid email address",
  }),
});

type RequestResetFormData = z.infer<typeof requestResetSchema>;

const resetPasswordSchema = z
  .object({
    email: z.string().email({
      message: "Please enter a valid email address",
    }),
    code: z.string().min(6, {
      message: "Verification code must be 6 characters",
    }),
    newPassword: z.string().min(8, {
      message: "Password must be at least 8 characters",
    }),
    confirmPassword: z.string(),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

type ResetPasswordFormData = z.infer<typeof resetPasswordSchema>;

enum ResetStage {
  REQUEST = "REQUEST",
  RESET = "RESET",
  SUCCESS = "SUCCESS",
}

export function PasswordResetForm() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [resetStage, setResetStage] = useState<ResetStage>(ResetStage.REQUEST);
  const [email, setEmail] = useState("");

  const requestForm = useForm<RequestResetFormData>({
    resolver: zodResolver(requestResetSchema),
    defaultValues: {
      email: "",
    },
  });

  const resetForm = useForm<ResetPasswordFormData>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      email: "",
      code: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  async function onRequestReset(data: RequestResetFormData) {
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/forgot-password", {
        email: data.email,
      });
      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Success",
          description: result.message || "Reset code sent to your email",
        });
        setEmail(data.email);
        resetForm.setValue("email", data.email);
        setResetStage(ResetStage.RESET);
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to process request",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Password reset request error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  async function onResetPassword(data: ResetPasswordFormData) {
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/auth/reset-password", {
        email: data.email,
        code: data.code,
        newPassword: data.newPassword,
        confirmPassword: data.confirmPassword,
      });
      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Success",
          description: result.message || "Password reset successful",
        });
        setResetStage(ResetStage.SUCCESS);
      } else {
        toast({
          title: "Error",
          description: result.message || "Failed to reset password",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Password reset error:", error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  if (resetStage === ResetStage.SUCCESS) {
    return (
      <div className="space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Password Reset Successful</h1>
          <p className="text-sm text-muted-foreground">
            Your password has been successfully reset. You can now log in with your new password.
          </p>
        </div>

        <Button
          className="w-full"
          onClick={() => (window.location.href = "/auth/login")}
        >
          Go to Login
        </Button>
      </div>
    );
  }

  if (resetStage === ResetStage.RESET) {
    return (
      <div className="space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Reset Your Password</h1>
          <p className="text-sm text-muted-foreground">
            Enter the verification code sent to {email} and your new password.
          </p>
        </div>

        <Form {...resetForm}>
          <form onSubmit={resetForm.handleSubmit(onResetPassword)} className="space-y-4">
            <FormField
              control={resetForm.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      placeholder="name@example.com"
                      {...field}
                      disabled={true} // Email is pre-filled and not editable
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={resetForm.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Verification Code</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter 6-character code"
                      {...field}
                      onChange={(e) => {
                        const onlyLettersAndNumbers = e.target.value.replace(/[^A-Z0-9]/gi, '');
                        if (onlyLettersAndNumbers.length <= 6) {
                          field.onChange(onlyLettersAndNumbers.toUpperCase());
                        }
                      }}
                      disabled={isLoading}
                      className="text-center tracking-widest"
                      maxLength={6}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={resetForm.control}
              name="newPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>New Password</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      {...field}
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={resetForm.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm New Password</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      {...field}
                      disabled={isLoading}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button className="w-full" type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Reset Password
            </Button>
          </form>
        </Form>

        <div className="text-center text-sm">
          <p className="text-muted-foreground">
            Didn't receive the code?{" "}
            <Button
              variant="link"
              className="p-0"
              onClick={() => setResetStage(ResetStage.REQUEST)}
              disabled={isLoading}
            >
              Try again
            </Button>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2 text-center">
        <h1 className="text-2xl font-semibold tracking-tight">Forgot Password</h1>
        <p className="text-sm text-muted-foreground">
          Enter your email address and we'll send you a verification code to reset your password.
        </p>
      </div>

      <Form {...requestForm}>
        <form onSubmit={requestForm.handleSubmit(onRequestReset)} className="space-y-4">
          <FormField
            control={requestForm.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input
                    type="email"
                    placeholder="name@example.com"
                    {...field}
                    disabled={isLoading}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button className="w-full" type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Send Reset Instructions
          </Button>
        </form>
      </Form>

      <div className="text-center text-sm">
        <p className="text-muted-foreground">
          Remember your password?{" "}
          <Button
            variant="link"
            className="p-0"
            onClick={() => (window.location.href = "/auth/login")}
          >
            Back to Login
          </Button>
        </p>
      </div>
    </div>
  );
}
