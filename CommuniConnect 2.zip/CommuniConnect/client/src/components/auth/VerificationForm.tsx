import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

interface VerificationFormProps {
  onSuccess: () => void;
}

export default function VerificationForm({ onSuccess }: VerificationFormProps) {
  const { toast } = useToast();
  const { verificationEmail, login } = useAuth();
  const [verificationCode, setVerificationCode] = useState<string[]>(Array(6).fill(''));
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  
  useEffect(() => {
    // Focus the first input on mount
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);
  
  const handleInputChange = (index: number, value: string) => {
    // Only allow numbers
    if (!/^\d*$/.test(value)) return;
    
    const newCode = [...verificationCode];
    newCode[index] = value;
    setVerificationCode(newCode);
    
    // Auto-advance to next input
    if (value && index < 5 && inputRefs.current[index + 1]) {
      inputRefs.current[index + 1].focus();
    }
  };
  
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // Handle backspace to go to previous input
    if (e.key === 'Backspace' && !verificationCode[index] && index > 0 && inputRefs.current[index - 1]) {
      inputRefs.current[index - 1].focus();
    }
  };
  
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').trim();
    
    // If pasted data looks like a verification code (6 digits)
    if (/^\d{6}$/.test(pastedData)) {
      const digits = pastedData.split('');
      setVerificationCode(digits);
      
      // Focus the last input
      if (inputRefs.current[5]) {
        inputRefs.current[5].focus();
      }
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!verificationEmail) {
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: "Email address is missing. Please go back to registration.",
      });
      return;
    }
    
    const code = verificationCode.join('');
    if (code.length !== 6 || !/^\d{6}$/.test(code)) {
      toast({
        variant: "destructive",
        title: "Invalid code",
        description: "Please enter a valid 6-digit verification code",
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("POST", "/api/auth/verify", {
        email: verificationEmail,
        code: code,
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Log the user in with the token
        login(data.token, data.user);
        
        toast({
          title: "Email verified successfully",
          description: "Your account has been verified. Welcome to Nexus!",
        });
        
        onSuccess();
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Verification failed",
          description: error.message || "Failed to verify your account",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Verification failed",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleResendCode = async () => {
    // Implement code resend functionality
    toast({
      title: "Verification code resent",
      description: "Please check your email for the new verification code",
    });
  };

  return (
    <div className="text-center mb-6">
      <div className="text-primary text-4xl mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21.5 12H16c-.7 2-2 3-4 3s-3.3-1-4-3H2.5"/>
          <path d="M5.5 5.1L2 12v6c0 1.1.9 2 2 2h16a2 2 0 0 0 2-2v-6l-3.4-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.8 1.1z"/>
        </svg>
      </div>
      <h2 className="text-2xl font-bold mb-1">Check Your Email</h2>
      <p className="text-muted-foreground">We've sent a 6-digit code to your email address</p>
      
      <form onSubmit={handleSubmit} className="space-y-4 mt-6">
        <div>
          <label className="block text-sm font-medium mb-3 text-center">Enter verification code</label>
          <div className="grid grid-cols-6 gap-2">
            {verificationCode.map((digit, index) => (
              <Input
                key={index}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleInputChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={index === 0 ? handlePaste : undefined}
                ref={(el) => inputRefs.current[index] = el}
                className="w-full bg-background p-2.5 rounded border border-border focus:border-primary focus:outline-none transition-colors text-center font-mono"
              />
            ))}
          </div>
          <div className="text-xs text-muted-foreground mt-3 text-center">
            Didn't receive an email? <button type="button" onClick={handleResendCode} className="text-primary hover:underline">Resend code</button>
          </div>
        </div>
        
        <Button 
          type="submit" 
          className="w-full" 
          disabled={isSubmitting}
        >
          {isSubmitting ? "Verifying..." : "Verify Account"}
        </Button>
      </form>
    </div>
  );
}
