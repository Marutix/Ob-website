import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PlusCircleIcon, GiftIcon, ImageIcon, SmileIcon } from "lucide-react";
import { Form, FormControl, FormField } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMessages } from "@/hooks/useMessages";

const formSchema = z.object({
  content: z.string().min(1).max(2000),
});

interface MessageInputProps {
  channelId?: number | null;
  dmChannelId?: number | null;
  placeholder?: string;
}

export default function MessageInput({ channelId, dmChannelId, placeholder = "Message" }: MessageInputProps) {
  const { toast } = useToast();
  const { sendMessage, sendDirectMessage } = useMessages();
  const [isSending, setIsSending] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!channelId && !dmChannelId) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No channel selected",
      });
      return;
    }
    
    try {
      setIsSending(true);
      
      if (channelId) {
        await sendMessage(channelId, values.content);
      } else if (dmChannelId) {
        await sendDirectMessage(dmChannelId, values.content);
      }
      
      // Reset form
      form.reset();
      
      // Focus input for next message
      if (inputRef.current) {
        inputRef.current.focus();
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to send message",
        description: "An error occurred while sending your message",
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Submit form on Enter (without shift for newline)
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      form.handleSubmit(onSubmit)();
    }
  };

  return (
    <div className="p-4 border-t border-border">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="relative">
            <button 
              type="button"
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary cursor-pointer"
            >
              <PlusCircleIcon className="h-5 w-5" />
            </button>
            
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormControl>
                  <Input
                    placeholder={placeholder}
                    className="w-full bg-secondary/80 rounded-md py-3 pl-10 pr-32 focus:outline-none focus:ring-1 focus:ring-primary"
                    disabled={isSending}
                    onKeyDown={handleKeyDown}
                    {...field}
                    ref={inputRef}
                  />
                </FormControl>
              )}
            />
            
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-3 text-muted-foreground">
              <button type="button" className="hover:text-foreground transition-colors">
                <GiftIcon className="h-5 w-5" />
              </button>
              <button type="button" className="hover:text-foreground transition-colors">
                <ImageIcon className="h-5 w-5" />
              </button>
              <button type="button" className="hover:text-foreground transition-colors">
                <SmileIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
