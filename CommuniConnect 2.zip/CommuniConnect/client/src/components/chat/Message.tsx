import { forwardRef, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { MoreVertical, Reply, Trash2, Edit, Copy } from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { MessageWithUser } from "@/lib/types";
import { useAuth } from "@/hooks/useAuth";
import { useMessages } from "@/hooks/useMessages";

interface MessageProps {
  message: MessageWithUser;
  isDeleting?: boolean;
  isFirst?: boolean;
  className?: string;
}

const Message = forwardRef<HTMLDivElement, MessageProps>(({ 
  message, 
  isDeleting = false,
  isFirst = false,
  className
}, ref) => {
  const { user } = useAuth();
  const { deleteMessage, updateMessage } = useMessages();
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(message.content);
  
  const isOwnMessage = user?.id === message.sender.id;
  const formattedTime = message.createdAt ? formatDistanceToNow(new Date(message.createdAt), { addSuffix: true }) : "just now";
  const isEdited = message.createdAt !== message.updatedAt;
  
  const handleDelete = async () => {
    if (isOwnMessage) {
      await deleteMessage(message.id);
    }
  };
  
  const handleEdit = () => {
    if (isOwnMessage) {
      setIsEditing(true);
    }
  };
  
  const handleSaveEdit = async () => {
    if (editValue.trim() && editValue !== message.content) {
      await updateMessage(message.id, editValue);
    }
    setIsEditing(false);
  };
  
  const handleCancelEdit = () => {
    setEditValue(message.content);
    setIsEditing(false);
  };
  
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
  };
  
  return (
    <div 
      ref={ref}
      className={cn(
        "flex py-1 px-4 hover:bg-secondary/30 group transition-colors message-appear",
        isFirst && "pt-4 mt-2",
        className
      )}
    >
      {isFirst && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-secondary mr-3">
          {message.sender.avatar ? (
            <img src={message.sender.avatar} alt={message.sender.username} className="w-full h-full rounded-full object-cover" />
          ) : (
            <div className="w-full h-full rounded-full bg-primary/20 flex items-center justify-center text-primary-foreground">
              {message.sender.username.charAt(0).toUpperCase()}
            </div>
          )}
        </div>
      )}
      
      {!isFirst && (
        <div className="flex-shrink-0 w-10 h-10 mr-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="text-xs text-muted-foreground mt-1 text-right mr-1">
            {formattedTime.includes("minute") ? formattedTime.split(" ")[0] : formattedTime.split(" ")[0] + formattedTime.split(" ")[1].charAt(0)}
          </div>
        </div>
      )}
      
      <div className={cn("flex-grow", isDeleting && "opacity-50")}>
        {isFirst && (
          <div className="flex items-center">
            <span className="font-medium">{message.sender.username}</span>
            <span className="ml-2 text-xs text-muted-foreground">
              {formattedTime}
            </span>
          </div>
        )}
        
        {isEditing ? (
          <div className="relative">
            <input
              type="text"
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              className="w-full bg-secondary p-2 pr-20 rounded border border-primary/30 focus:border-primary focus:outline-none"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSaveEdit();
                if (e.key === "Escape") handleCancelEdit();
              }}
            />
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
              <button 
                onClick={handleCancelEdit}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveEdit}
                className="text-xs text-primary hover:text-primary/80 transition-colors"
              >
                Save
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              press ESC to cancel, ENTER to save
            </p>
          </div>
        ) : (
          <p className="text-foreground">
            {message.content}
            {isEdited && <span className="text-xs text-muted-foreground ml-1">(edited)</span>}
          </p>
        )}
      </div>
      
      <div className="ml-2 flex items-start space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
          <Reply className="h-4 w-4" />
        </button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
              <MoreVertical className="h-4 w-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={handleCopy}>
              <Copy className="h-4 w-4 mr-2" />
              <span>Copy Text</span>
            </DropdownMenuItem>
            
            {isOwnMessage && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  <span>Edit Message</span>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleDelete}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  <span>Delete Message</span>
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
});

Message.displayName = "Message";
export default Message;
