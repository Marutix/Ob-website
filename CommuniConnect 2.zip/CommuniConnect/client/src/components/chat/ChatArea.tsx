import { useEffect, useRef } from "react";
import { Loader2 } from "lucide-react";
import { useMessages } from "@/hooks/useMessages";
import Message from "./Message";
import { cn } from "@/lib/utils";

interface ChatAreaProps {
  channelId?: number | null;
  dmChannelId?: number | null;
  serverId?: number | null;
}

export default function ChatArea({ channelId, dmChannelId, serverId }: ChatAreaProps) {
  const { messages, directMessages, isLoading } = useMessages(channelId, dmChannelId);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatAreaRef = useRef<HTMLDivElement>(null);
  
  // Auto scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, directMessages]);
  
  // Determine which messages to display
  const displayMessages = channelId ? messages : directMessages;
  
  // Group messages by sender and time for better display
  const groupedMessages = displayMessages?.reduce((groups, message, index) => {
    const prevMessage = displayMessages[index - 1];
    
    // Start a new group if:
    // 1. This is the first message
    // 2. The sender changed
    // 3. Time gap > 5 minutes between messages
    const shouldStartNewGroup = !prevMessage || 
                               prevMessage.sender.id !== message.sender.id ||
                               (new Date(message.createdAt).getTime() - new Date(prevMessage.createdAt).getTime() > 5 * 60 * 1000);
    
    if (shouldStartNewGroup) {
      return [...groups, [message]];
    }
    
    // Add to the last group
    const lastGroup = groups[groups.length - 1];
    return [...groups.slice(0, -1), [...lastGroup, message]];
  }, [] as typeof displayMessages[]);

  return (
    <div 
      ref={chatAreaRef}
      className="chat-area flex-grow overflow-y-auto p-4 space-y-4"
    >
      {isLoading ? (
        <div className="flex justify-center items-center h-full">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      ) : displayMessages?.length === 0 ? (
        // Welcome message for empty channel or DM
        <div className="p-4 bg-secondary/30 rounded-lg shadow-md message-appear">
          <div className="flex items-center">
            <div className="text-primary text-2xl mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 9l-2 3h3l-4 7-3-7H8l-2 7-1-6H2"/>
              </svg>
            </div>
            <div>
              <h3 className="font-bold text-lg">Welcome to {channelId ? '#' : ''}{channelId ? 'the channel' : 'your conversation'}!</h3>
              <p className="text-muted-foreground">
                {channelId 
                  ? "This is the beginning of this channel." 
                  : "This is the beginning of your direct message history."}
              </p>
            </div>
          </div>
          <p className="mt-3 text-muted-foreground">
            {channelId 
              ? "Start the conversation by sending a message below!"
              : "No messages yet. Say hello to start the conversation!"}
          </p>
        </div>
      ) : (
        // Message groups
        <>
          {groupedMessages?.map((group, groupIndex) => (
            <div key={`group-${groupIndex}`} className="space-y-0">
              {group.map((message, index) => (
                <Message 
                  key={message.id}
                  message={message}
                  isFirst={index === 0}
                  className={cn(index === group.length - 1 && "pb-2")}
                />
              ))}
            </div>
          ))}
          <div ref={messagesEndRef} className="h-1" />
        </>
      )}
    </div>
  );
}
