import { ReactNode } from "react";
import { useLocation } from "wouter";
import { useChannels } from "@/hooks/useChannels";
import { useDmChannel } from "@/hooks/useChannels";
import ChatArea from "../chat/ChatArea";
import MessageInput from "../chat/MessageInput";

interface MainContentProps {
  children?: ReactNode;
}

export default function MainContent({ children }: MainContentProps) {
  const [location] = useLocation();
  
  // Check if we're on a channel or DM page
  const isChannelPage = location.includes('/channels/') && location.split('/').length > 3;
  const isDmPage = location.includes('/dm/');
  
  // Extract IDs from URL
  const serverId = isChannelPage ? parseInt(location.split('/')[2]) : null;
  const channelId = isChannelPage ? parseInt(location.split('/')[3]) : null;
  const dmChannelId = isDmPage ? parseInt(location.split('/')[2]) : null;
  
  // Fetch channel/server data for header
  const { currentChannel, server } = useChannels(serverId, channelId);
  const { dmChannel, otherUser } = useDmChannel(dmChannelId);
  
  // If neither channel nor DM page, render children (home/settings/etc)
  if (!isChannelPage && !isDmPage) {
    return (
      <div className="flex-grow bg-background flex flex-col overflow-hidden">
        {children}
      </div>
    );
  }

  return (
    <div className="flex-grow bg-background flex flex-col overflow-hidden">
      {/* Channel header */}
      <div className="p-4 border-b border-border flex items-center">
        {isChannelPage ? (
          <>
            <span className="text-muted-foreground mr-2">#</span>
            <h3 className="font-bold">{currentChannel?.name || "Loading..."}</h3>
            {currentChannel?.description && (
              <div className="ml-3 text-sm text-muted-foreground">{currentChannel.description}</div>
            )}
          </>
        ) : isDmPage ? (
          <>
            <div className="w-6 h-6 rounded-full bg-primary/10 mr-2 flex-shrink-0">
              {otherUser?.avatar ? (
                <img src={otherUser.avatar} alt={otherUser.username} className="w-full h-full rounded-full object-cover" />
              ) : (
                <div className="w-full h-full rounded-full bg-primary/40 flex items-center justify-center text-primary-foreground text-xs">
                  {otherUser?.username.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <h3 className="font-bold">{otherUser?.username || "Loading..."}</h3>
            <div className={`ml-2 w-2 h-2 rounded-full ${
              otherUser?.status === "online" ? "bg-green-500" : 
              otherUser?.status === "idle" ? "bg-yellow-500" : 
              otherUser?.status === "dnd" ? "bg-red-500" : "bg-gray-500"
            }`}></div>
          </>
        ) : null}
        
        <div className="ml-auto flex items-center space-x-4 text-muted-foreground">
          <button className="hover:text-foreground transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
              <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
            </svg>
          </button>
          <button className="hover:text-foreground transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" x2="12" y1="5" y2="19"/>
              <line x1="5" x2="19" y1="12" y2="12"/>
            </svg>
          </button>
          <button className="hover:text-foreground transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
              <circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </button>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search" 
              className="bg-secondary text-sm py-1 px-3 rounded-md w-48 focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="16" 
              height="16" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            >
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.3-4.3"/>
            </svg>
          </div>
        </div>
      </div>
      
      {/* Chat area with messages */}
      <ChatArea 
        channelId={channelId}
        dmChannelId={dmChannelId}
        serverId={serverId}
      />
      
      {/* Message input */}
      <MessageInput 
        channelId={channelId}
        dmChannelId={dmChannelId}
        placeholder={`Message ${isChannelPage ? `#${currentChannel?.name || ''}` : otherUser?.username || ''}`}
      />
    </div>
  );
}
