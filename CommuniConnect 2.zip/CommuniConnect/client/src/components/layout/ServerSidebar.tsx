import { PlusIcon, CompassIcon, DownloadIcon, BoltIcon } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useServers } from "@/hooks/useServers";
import CreateServerModal from "../modals/CreateServerModal";

interface ServerSidebarProps {
  onServerClick?: () => void;
}

export default function ServerSidebar({ onServerClick }: ServerSidebarProps) {
  const [location] = useLocation();
  const { servers, isLoading } = useServers();
  const [isCreateServerOpen, setIsCreateServerOpen] = useState(false);

  const handleServerClick = (serverId: number) => {
    onServerClick?.();
  };

  return (
    <>
      <div className="bg-sidebar flex flex-col items-center pt-3 pb-4 border-r border-sidebar-border overflow-y-auto w-[72px] min-w-[72px] h-full">
        {/* Home button */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button 
                className={cn(
                  "server-icon bg-primary rounded-2xl flex items-center justify-center w-12 h-12 mb-3 cursor-pointer",
                  location === "/channels" && "active"
                )}
                onClick={() => {
                  window.location.href = "/channels";
                  onServerClick?.();
                }}
              >
                <BoltIcon className="text-white" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">Home</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <div className="separator w-8 h-0.5 bg-sidebar-border rounded-full my-1"></div>
        
        {/* Server list */}
        <div className="flex flex-col items-center gap-2 mt-2 w-full px-3">
          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="server-icon bg-sidebar-accent rounded-full w-12 h-12 animate-pulse" />
            ))
          ) : (
            servers?.map((server) => (
              <TooltipProvider key={server.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      className={cn(
                        "server-icon relative bg-sidebar-accent rounded-full flex items-center justify-center w-12 h-12 cursor-pointer overflow-hidden group",
                        location.includes(`/channels/${server.id}`) && "active"
                      )}
                      onClick={() => {
                        window.location.href = `/channels/${server.id}`;
                        handleServerClick(server.id);
                      }}
                    >
                      <span className="absolute left-0 w-1 h-8 bg-white rounded-r-full opacity-0 group-hover:opacity-50 transition-opacity"></span>
                      {server.icon ? (
                        <img src={server.icon} alt={server.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-primary/20 text-primary-foreground font-medium">
                          {server.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right">{server.name}</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))
          )}
        </div>
        
        {/* Create server button */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button 
                className="server-icon bg-sidebar-accent rounded-full flex items-center justify-center w-12 h-12 my-2 cursor-pointer opacity-60 hover:opacity-100 hover:bg-green-500 transition-all"
                onClick={() => setIsCreateServerOpen(true)}
              >
                <PlusIcon className="text-white" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">Create a Server</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        {/* Explore servers button */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button className="server-icon bg-sidebar-accent rounded-full flex items-center justify-center w-12 h-12 my-2 cursor-pointer opacity-60 hover:opacity-100 hover:bg-primary transition-all">
                <CompassIcon className="text-white" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">Explore Servers</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <div className="mt-auto">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button className="server-icon bg-sidebar-accent rounded-full flex items-center justify-center w-12 h-12 my-2 cursor-pointer opacity-60 hover:opacity-100 hover:bg-blue-500 transition-all">
                  <DownloadIcon className="text-white" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="right">Download App</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <CreateServerModal 
        isOpen={isCreateServerOpen} 
        onClose={() => setIsCreateServerOpen(false)} 
      />
    </>
  );
}
