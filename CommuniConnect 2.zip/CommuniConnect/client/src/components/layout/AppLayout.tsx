import { ReactNode, useState } from "react";
import ServerSidebar from "./ServerSidebar";
import ChannelsPanel from "./ChannelsPanel";
import MainContent from "./MainContent";
import MembersList from "./MembersList";
import MobileNavbar from "./MobileNavbar";
import { useMediaQuery } from "@/hooks/use-mobile";

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const isMobile = useMediaQuery("(max-width: 768px)");
  const [mobileView, setMobileView] = useState<"servers" | "channels" | "content" | "members">("content");

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Server Sidebar - Always visible on desktop, conditionally on mobile */}
      {(!isMobile || mobileView === "servers") && (
        <ServerSidebar onServerClick={() => isMobile && setMobileView("channels")} />
      )}

      {/* Channels Panel - Always visible on desktop, conditionally on mobile */}
      {(!isMobile || mobileView === "channels") && (
        <ChannelsPanel onChannelClick={() => isMobile && setMobileView("content")} />
      )}

      {/* Main Content - Always visible on desktop, conditionally on mobile */}
      {(!isMobile || mobileView === "content") && (
        <MainContent>{children}</MainContent>
      )}

      {/* Members List - Always visible on desktop, conditionally on mobile */}
      {(!isMobile || mobileView === "members") && (
        <MembersList />
      )}

      {/* Mobile Navigation Bar - Only visible on mobile */}
      {isMobile && (
        <MobileNavbar 
          activeView={mobileView} 
          onViewChange={setMobileView}
        />
      )}
    </div>
  );
}
