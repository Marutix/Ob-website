import { useState } from "react";
import { useLocation } from "wouter";
import { PlusIcon, ChevronDownIcon, ChevronRightIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Channel } from "@/lib/types";
import { useChannels } from "@/hooks/useChannels";
import { useAuth } from "@/hooks/useAuth";
import CreateChannelModal from "../modals/CreateChannelModal";

interface ChannelsPanelProps {
  onChannelClick?: () => void;
}

export default function ChannelsPanel({ onChannelClick }: ChannelsPanelProps) {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const currentServerId = location.includes("/channels/") 
    ? parseInt(location.split("/channels/")[1].split("/")[0]) 
    : null;
  
  const { channels, dmChannels, isLoading, server } = useChannels(currentServerId);
  const [isCreateChannelOpen, setIsCreateChannelOpen] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    dm: true,
    channels: true,
    voice: true
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleChannelClick = (channelId: number) => {
    if (currentServerId) {
      setLocation(`/channels/${currentServerId}/${channelId}`);
    }
    onChannelClick?.();
  };

  const handleDmClick = (dmChannelId: number) => {
    setLocation(`/dm/${dmChannelId}`);
    onChannelClick?.();
  };

  return (
    <>
      <div className="bg-secondary w-60 min-w-60 flex-shrink-0 flex flex-col border-r border-border h-full">
        {/* Server header */}
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-bold truncate">
            {currentServerId ? server?.name || "Loading..." : "Nexus Home"}
          </h2>
          <ChevronDownIcon className="h-4 w-4 text-muted-foreground cursor-pointer" />
        </div>
        
        {/* Channels */}
        <div className="overflow-y-auto flex-grow">
          {/* Direct Messages Section */}
          <div className="px-2 mt-4">
            <div 
              className="text-xs font-semibold text-muted-foreground flex items-center justify-between px-2 cursor-pointer"
              onClick={() => toggleSection('dm')}
            >
              {expandedSections.dm ? (
                <ChevronDownIcon className="h-3 w-3 mr-1" />
              ) : (
                <ChevronRightIcon className="h-3 w-3 mr-1" />
              )}
              <span>DIRECT MESSAGES</span>
              <PlusIcon className="h-3 w-3 cursor-pointer hover:text-foreground transition-colors" />
            </div>
            
            {expandedSections.dm && (
              <div className="mt-1 space-y-0.5">
                {isLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <div key={i} className="flex items-center px-2 py-1.5 rounded">
                      <div className="w-8 h-8 rounded-full bg-primary/20 animate-pulse"></div>
                      <div className="ml-2 w-32 h-4 bg-primary/20 animate-pulse rounded"></div>
                    </div>
                  ))
                ) : dmChannels?.length ? (
                  dmChannels.map((dm) => (
                    <div 
                      key={dm.id}
                      className={cn(
                        "channel flex items-center px-2 py-1.5 rounded hover:bg-primary cursor-pointer",
                        location === `/dm/${dm.id}` && "bg-primary/60"
                      )}
                      onClick={() => handleDmClick(dm.id)}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary relative flex-shrink-0">
                        {dm.user.avatar ? (
                          <img src={dm.user.avatar} alt={dm.user.username} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <div className="w-full h-full rounded-full bg-primary/40 flex items-center justify-center text-primary-foreground">
                            {dm.user.username.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className={cn(
                          "absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-secondary",
                          dm.user.status === "online" ? "bg-green-500" : 
                          dm.user.status === "idle" ? "bg-yellow-500" : 
                          dm.user.status === "dnd" ? "bg-red-500" : "bg-gray-500"
                        )}></div>
                      </div>
                      <div className="ml-2 truncate">{dm.user.username}</div>
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-muted-foreground px-2 py-1.5">
                    No direct messages yet
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Server Channels - Only show if on a server */}
          {currentServerId && (
            <>
              <div className="px-2 mt-6">
                <div 
                  className="text-xs font-semibold text-muted-foreground flex items-center justify-between px-2 cursor-pointer"
                  onClick={() => toggleSection('channels')}
                >
                  {expandedSections.channels ? (
                    <ChevronDownIcon className="h-3 w-3 mr-1" />
                  ) : (
                    <ChevronRightIcon className="h-3 w-3 mr-1" />
                  )}
                  <span>CHANNELS</span>
                  {/* Only show plus icon if user has permissions */}
                  {server?.ownerId === user?.id && (
                    <PlusIcon 
                      className="h-3 w-3 cursor-pointer hover:text-foreground transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsCreateChannelOpen(true);
                      }}
                    />
                  )}
                </div>
                
                {expandedSections.channels && (
                  <div className="mt-1 space-y-0.5">
                    {isLoading ? (
                      Array(3).fill(0).map((_, i) => (
                        <div key={i} className="flex items-center px-2 py-1.5 rounded">
                          <div className="w-4 h-4 bg-primary/20 animate-pulse rounded-full"></div>
                          <div className="ml-2 w-32 h-4 bg-primary/20 animate-pulse rounded"></div>
                        </div>
                      ))
                    ) : channels?.filter(c => c.type === 'text')?.length ? (
                      channels.filter(c => c.type === 'text').map((channel) => (
                        <div 
                          key={channel.id}
                          className={cn(
                            "channel flex items-center px-2 py-1.5 rounded hover:bg-primary cursor-pointer",
                            location === `/channels/${currentServerId}/${channel.id}` && "bg-primary/60"
                          )}
                          onClick={() => handleChannelClick(channel.id)}
                        >
                          <span className="text-sm text-muted-foreground">#</span>
                          <div className="ml-2 truncate">{channel.name}</div>
                          {/* Notification indicator */}
                          {channel.hasNotification && (
                            <div className="ml-1.5 w-2 h-2 rounded-full bg-primary animate-pulse-slow"></div>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-xs text-muted-foreground px-2 py-1.5">
                        No text channels
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <div className="px-2 mt-6">
                <div 
                  className="text-xs font-semibold text-muted-foreground flex items-center px-2 cursor-pointer"
                  onClick={() => toggleSection('voice')}
                >
                  {expandedSections.voice ? (
                    <ChevronDownIcon className="h-3 w-3 mr-1" />
                  ) : (
                    <ChevronRightIcon className="h-3 w-3 mr-1" />
                  )}
                  <span>VOICE CHANNELS</span>
                </div>
                
                {expandedSections.voice && (
                  <div className="mt-1 space-y-0.5">
                    {isLoading ? (
                      Array(2).fill(0).map((_, i) => (
                        <div key={i} className="flex items-center px-2 py-1.5 rounded">
                          <div className="w-4 h-4 bg-primary/20 animate-pulse rounded-full"></div>
                          <div className="ml-2 w-32 h-4 bg-primary/20 animate-pulse rounded"></div>
                        </div>
                      ))
                    ) : channels?.filter(c => c.type === 'voice')?.length ? (
                      channels.filter(c => c.type === 'voice').map((channel) => (
                        <div 
                          key={channel.id}
                          className="channel flex items-center px-2 py-1.5 rounded hover:bg-primary cursor-pointer"
                        >
                          <span className="text-sm text-muted-foreground">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                              <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                              <line x1="12" x2="12" y1="19" y2="22"/>
                            </svg>
                          </span>
                          <div className="ml-2 truncate">{channel.name}</div>
                          {channel.activeUsers > 0 && (
                            <div className="ml-auto flex items-center text-xs text-muted-foreground">
                              <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                                <circle cx="9" cy="7" r="4"/>
                                <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                              </svg>
                              <span className="ml-1">{channel.activeUsers}</span>
                            </div>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-xs text-muted-foreground px-2 py-1.5">
                        No voice channels
                      </div>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
        
        {/* User panel */}
        <div className="p-2 bg-primary/10 flex items-center">
          <div className="w-8 h-8 rounded-full bg-primary relative flex-shrink-0">
            {user?.avatar ? (
              <img src={user.avatar} alt="Your avatar" className="w-full h-full rounded-full object-cover" />
            ) : (
              <div className="w-full h-full rounded-full bg-primary/40 flex items-center justify-center text-primary-foreground">
                {user?.username.charAt(0).toUpperCase()}
              </div>
            )}
            <div className={cn(
              "absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-secondary",
              user?.status === "online" ? "bg-green-500" : 
              user?.status === "idle" ? "bg-yellow-500" : 
              user?.status === "dnd" ? "bg-red-500" : "bg-gray-500"
            )}></div>
          </div>
          <div className="ml-2 truncate">
            <div className="font-medium text-sm truncate">
              {user ? `${user.username}#${user.discriminator}` : "Loading..."}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {user?.status.charAt(0).toUpperCase() + user?.status.slice(1) || "Offline"}
            </div>
          </div>
          <div className="ml-auto flex space-x-2 text-muted-foreground">
            <button className="hover:text-foreground transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                <line x1="12" x2="12" y1="19" y2="22"/>
              </svg>
            </button>
            <button className="hover:text-foreground transition-colors" onClick={() => setLocation('/settings')}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {currentServerId && (
        <CreateChannelModal
          isOpen={isCreateChannelOpen}
          onClose={() => setIsCreateChannelOpen(false)}
          serverId={currentServerId}
        />
      )}
    </>
  );
}
