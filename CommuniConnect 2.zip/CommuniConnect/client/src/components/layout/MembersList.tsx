import { useLocation } from "wouter";
import { useChannels } from "@/hooks/useChannels";
import { cn } from "@/lib/utils";

export default function MembersList() {
  const [location] = useLocation();
  
  // Only show members list on server pages
  const isServerPage = location.includes('/channels/') && location.split('/').length >= 3;
  const serverId = isServerPage ? parseInt(location.split('/')[2]) : null;
  
  const { members, isLoading, roles } = useChannels(serverId);
  
  if (!isServerPage) return null;
  
  // Group members by online status
  const onlineMembers = members?.filter(m => m.status !== 'offline') || [];
  const offlineMembers = members?.filter(m => m.status === 'offline') || [];
  
  // Group members by role (for display)
  const getMemberRole = (memberId: number) => {
    if (!roles) return null;
    // Find the highest role (assuming sorted by priority)
    const userRoles = roles.filter(role => 
      role.members?.includes(memberId)
    );
    return userRoles.length > 0 ? userRoles[0] : null;
  };

  return (
    <div className="bg-secondary w-60 border-l border-border p-4 overflow-y-auto hidden lg:block">
      <h3 className="text-xs font-semibold text-muted-foreground mb-4">
        MEMBERS — {members?.length || 0}
      </h3>
      
      {/* Online members */}
      <div className="mb-6">
        <h4 className="text-xs font-medium text-muted-foreground mb-2">
          ONLINE — {onlineMembers.length}
        </h4>
        
        <div className="space-y-2">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-primary/20 animate-pulse"></div>
                <div className="ml-2 w-32 h-4 bg-primary/20 animate-pulse rounded"></div>
              </div>
            ))
          ) : onlineMembers.length > 0 ? (
            onlineMembers.map(member => {
              const role = getMemberRole(member.id);
              return (
                <div key={member.id} className="flex items-center group cursor-pointer">
                  <div className="w-8 h-8 rounded-full bg-primary relative flex-shrink-0">
                    {member.avatar ? (
                      <img src={member.avatar} alt={member.username} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <div className="w-full h-full rounded-full bg-primary/40 flex items-center justify-center text-primary-foreground">
                        {member.username.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className={cn(
                      "absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-secondary",
                      member.status === "online" ? "bg-green-500" : 
                      member.status === "idle" ? "bg-yellow-500" : 
                      member.status === "dnd" ? "bg-red-500" : "bg-gray-500"
                    )}></div>
                  </div>
                  <div className={cn(
                    "ml-2 truncate group-hover:text-foreground transition-colors",
                    role && `text-[${role.color}]`
                  )}>
                    {member.username}
                    {role && role.name !== "@everyone" && (
                      <span className={cn(
                        "ml-1 text-[10px] px-1 py-0.5 rounded",
                        `bg-[${role.color}]/20 text-[${role.color}]`
                      )}>
                        {role.name}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-xs text-muted-foreground">No members online</div>
          )}
        </div>
      </div>
      
      {/* Offline members */}
      <div>
        <h4 className="text-xs font-medium text-muted-foreground mb-2">
          OFFLINE — {offlineMembers.length}
        </h4>
        
        <div className="space-y-2">
          {isLoading ? (
            Array(2).fill(0).map((_, i) => (
              <div key={i} className="flex items-center opacity-50">
                <div className="w-8 h-8 rounded-full bg-primary/20 animate-pulse"></div>
                <div className="ml-2 w-32 h-4 bg-primary/20 animate-pulse rounded"></div>
              </div>
            ))
          ) : offlineMembers.length > 0 ? (
            offlineMembers.map(member => {
              const role = getMemberRole(member.id);
              return (
                <div key={member.id} className="flex items-center opacity-50 group cursor-pointer">
                  <div className="w-8 h-8 rounded-full bg-primary relative flex-shrink-0">
                    {member.avatar ? (
                      <img src={member.avatar} alt={member.username} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <div className="w-full h-full rounded-full bg-gray-600 flex items-center justify-center text-gray-300">
                        {member.username.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-gray-500 rounded-full border-2 border-secondary"></div>
                  </div>
                  <div className={cn(
                    "ml-2 truncate group-hover:text-foreground transition-colors",
                    role && `text-[${role.color}]`
                  )}>
                    {member.username}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-xs text-muted-foreground">No offline members</div>
          )}
        </div>
      </div>
    </div>
  );
}
