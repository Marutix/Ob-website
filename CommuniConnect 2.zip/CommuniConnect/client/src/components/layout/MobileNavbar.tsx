import { ServerIcon, MessageSquareIcon, InboxIcon, UsersIcon, UserIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileNavbarProps {
  activeView: "servers" | "channels" | "content" | "members";
  onViewChange: (view: "servers" | "channels" | "content" | "members") => void;
}

export default function MobileNavbar({ activeView, onViewChange }: MobileNavbarProps) {
  return (
    <div className="md:hidden bg-background border-t border-border p-2 flex justify-around items-center">
      <button 
        className={cn(
          "p-2 text-muted-foreground hover:text-foreground focus:outline-none transition-colors",
          activeView === "servers" && "text-primary"
        )}
        onClick={() => onViewChange("servers")}
      >
        <ServerIcon className="h-5 w-5" />
      </button>
      <button 
        className={cn(
          "p-2 text-muted-foreground hover:text-foreground focus:outline-none transition-colors",
          activeView === "channels" && "text-primary"
        )}
        onClick={() => onViewChange("channels")}
      >
        <MessageSquareIcon className="h-5 w-5" />
      </button>
      <button 
        className={cn(
          "p-2 text-muted-foreground hover:text-foreground focus:outline-none transition-colors",
          activeView === "content" && "text-primary"
        )}
        onClick={() => onViewChange("content")}
      >
        <InboxIcon className="h-5 w-5" />
      </button>
      <button 
        className={cn(
          "p-2 text-muted-foreground hover:text-foreground focus:outline-none transition-colors",
          activeView === "members" && "text-primary"
        )}
        onClick={() => onViewChange("members")}
      >
        <UsersIcon className="h-5 w-5" />
      </button>
      <button 
        className="p-2 text-muted-foreground hover:text-foreground focus:outline-none transition-colors"
        onClick={() => window.location.href = "/settings"}
      >
        <UserIcon className="h-5 w-5" />
      </button>
    </div>
  );
}
