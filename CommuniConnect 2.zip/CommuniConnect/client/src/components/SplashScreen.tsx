import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence, useTransform, useMotionValue, animate } from "framer-motion";
import nexusSymbol from "@/assets/nexus-symbol.svg";

type SplashScreenProps = {
  setShowSplash?: (show: boolean) => void;
};

export function SplashScreen({ setShowSplash: externalSetShowSplash }: SplashScreenProps = {}) {
  const [showSplash, setShowSplash] = useState(true);
  const [, setLocation] = useLocation();
  const containerRef = useRef<HTMLDivElement>(null);

  // Create motion values for 3D effect
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotation = useMotionValue(0);
  
  // Transform these values for rotation
  const rotateX = useTransform(y, [-300, 300], [30, -30]);
  const rotateY = useTransform(x, [-300, 300], [-30, 30]);
  
  // Text animation refs
  const flyingTextRefs = useRef<Array<HTMLDivElement | null>>([]);
  
  // Set up auto rotation
  useEffect(() => {
    const rotationControls = animate(rotation, 360, {
      duration: 8,
      repeat: Infinity,
      ease: "linear"
    });
    
    return () => rotationControls.stop();
  }, [rotation]);
  
  // Handle mouse movement for 3D effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      
      const rect = containerRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      // Calculate distance from center (with dampening)
      const deltaX = (e.clientX - centerX) * 0.5;
      const deltaY = (e.clientY - centerY) * 0.5;
      
      x.set(deltaX);
      y.set(deltaY);
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [x, y]);

  // Flying text animation setup
  useEffect(() => {
    flyingTextRefs.current.forEach((el, i) => {
      if (!el) return;
      
      const delay = i * 0.15;
      const duration = 1.5 + Math.random() * 0.5;
      const initialX = (Math.random() - 0.5) * window.innerWidth;
      const initialY = (Math.random() - 0.5) * window.innerHeight;
      const initialZ = -500 - Math.random() * 500;
      
      el.style.opacity = "0";
      el.style.transform = `translate3d(${initialX}px, ${initialY}px, ${initialZ}px)`;
      
      setTimeout(() => {
        el.style.transition = `transform ${duration}s cubic-bezier(0.19, 1, 0.22, 1), opacity ${duration * 0.5}s ease-in`;
        el.style.opacity = "1";
        el.style.transform = "translate3d(0, 0, 0)";
      }, delay * 1000);
    });
  }, []);

  useEffect(() => {
    // After animation completes, redirect to auth page
    const timer = setTimeout(() => {
      // Use external setter if provided, otherwise use local state
      if (externalSetShowSplash) {
        externalSetShowSplash(false);
      } else {
        setShowSplash(false);
      }
      
      setTimeout(() => {
        setLocation("/auth/login");
      }, 800); // Give exit animation time to complete
    }, 9000); // Extended animation time for the impressive effect

    return () => clearTimeout(timer);
  }, [setLocation, externalSetShowSplash]);

  // Words for flying text animation
  const flyingWords = [
    "Connect", "Chat", "Community", "Voice", "Friends", 
    "Team", "Gaming", "Share", "Create", "Stream", 
    "Build", "Discover", "Together", "Collaborate"
  ];

  return (
    <AnimatePresence>
      {showSplash && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-gray-900 to-background overflow-hidden perspective-[1200px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          ref={containerRef}
        >
          {/* Flying background words layer */}
          <div className="absolute inset-0 overflow-hidden">
            {flyingWords.map((word, i) => (
              <div 
                key={i}
                className={`absolute text-purple-500/20 font-bold select-none pointer-events-none`}
                style={{
                  fontSize: `${Math.floor(Math.random() * 30) + 20}px`,
                  left: `${Math.floor(Math.random() * 100)}%`,
                  top: `${Math.floor(Math.random() * 100)}%`,
                  transform: 'scale(0) translate3d(0, 0, 0)',
                  opacity: 0,
                  zIndex: 10
                }}
                ref={el => flyingTextRefs.current[i] = el}
              >
                {word}
              </div>
            ))}
          </div>

          {/* 3D Container */}
          <motion.div
            className="flex flex-col items-center relative z-20"
            style={{
              rotateX,
              rotateY,
              transformStyle: "preserve-3d",
            }}
            initial={{ scale: 0.2, z: -800, opacity: 0, y: 300 }}
            animate={{
              scale: [0.2, 0.4, 1.2, 1.2, 1],
              z: [-800, -400, 300, 300, 0],
              opacity: [0, 0.5, 1, 1, 1],
              y: [300, 0, 0, 0, 0],
              rotateX: [0, 0, 0, 360, 0],
              rotateY: [0, 0, 0, 360, 0],
              rotateZ: [0, 0, 0, 360, 0],
            }}
            transition={{
              times: [0, 0.2, 0.4, 0.7, 1],
              duration: 7,
              ease: "easeInOut"
            }}
            exit={{ scale: 1.5, z: 200, opacity: 0 }}
            onMouseMove={(e) => {
              // Calculate cursor position relative to the center of the container
              const rect = e.currentTarget.getBoundingClientRect();
              const centerX = rect.left + rect.width / 2;
              const centerY = rect.top + rect.height / 2;
              x.set(e.clientX - centerX);
              y.set(e.clientY - centerY);
            }}
            onMouseLeave={() => {
              // Reset to center when mouse leaves
              x.set(0);
              y.set(0);
            }}
          >
            {/* Logo with 3D animation */}
            <motion.div 
              className="relative mb-8"
              style={{ 
                transformStyle: "preserve-3d", 
                rotate: rotation  // Apply continuous rotation
              }}
              animate={{
                rotateX: [0, 180, 360, 180, 0],
                rotateY: [0, 180, 360, 180, 0]
              }}
              transition={{
                duration: 7,
                times: [0, 0.25, 0.5, 0.75, 1],
                ease: "easeInOut",
                delay: 2.5
              }}
            >
              {/* Hexagon logo */}
              <motion.svg 
                className="w-44 h-44"
                viewBox="0 0 100 100" 
                xmlns="http://www.w3.org/2000/svg"
                initial={{ 
                  scale: 0,
                  rotateY: -180,
                  z: -100,
                  opacity: 0
                }}
                animate={{ 
                  scale: 1,
                  rotateY: 0,
                  z: 0,
                  opacity: 1 
                }}
                transition={{ 
                  type: "spring",
                  delay: 0.5,
                  duration: 1.5
                }}
              >
                {/* Glow effect */}
                <defs>
                  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#9333EA" />
                    <stop offset="100%" stopColor="#7C3AED" />
                  </linearGradient>
                </defs>
                {/* Outer glow hexagon */}
                <motion.polygon 
                  points="50,10 85,30 85,70 50,90 15,70 15,30" 
                  fill="none" 
                  stroke="#a855f7"
                  strokeWidth="1"
                  opacity="0.6"
                  filter="url(#glow)"
                  initial={{ scale: 1.1, opacity: 0 }}
                  animate={{ scale: 1.2, opacity: 0.6 }}
                  transition={{ 
                    delay: 1, 
                    duration: 2,
                    repeat: Infinity,
                    repeatType: "reverse"
                  }}
                />
                <motion.polygon 
                  points="50,10 85,30 85,70 50,90 15,70 15,30" 
                  fill="url(#logoGradient)" 
                  stroke="#8B5CF6"
                  strokeWidth="2"
                />
                <motion.path 
                  d="M35,35 L50,65 L65,35" 
                  fill="none"
                  stroke="white"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ delay: 1.5, duration: 1, ease: "easeInOut" }}
                />
                <motion.circle 
                  cx="35" cy="35" r="5" fill="white" 
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 2, duration: 0.3 }}
                />
                <motion.circle 
                  cx="50" cy="65" r="5" fill="white" 
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 2.2, duration: 0.3 }}
                />
                <motion.circle 
                  cx="65" cy="35" r="5" fill="white" 
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 2.4, duration: 0.3 }}
                />
                {/* Extra visual elements for more impressive animation */}
                <motion.circle 
                  cx="50" cy="50" r="30" 
                  fill="none" 
                  stroke="#c4b5fd" 
                  strokeWidth="1"
                  strokeDasharray="5 5"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.5 }}
                  transition={{ delay: 3, duration: 0.5 }}
                />
              </motion.svg>
            </motion.div>

            {/* Nexus text with glowing effect */}
            <motion.div
              className="relative mb-8"
              style={{ transformStyle: "preserve-3d" }}
            >
              {/* Shadow/glow text below */}
              <motion.h1
                className="absolute text-6xl font-bold text-purple-300/20 blur-md select-none"
                style={{ 
                  transformStyle: "preserve-3d",
                  transform: "translate(-50%, -50%)",
                  left: "50%",
                  top: "50%",
                }}
                initial={{ 
                  scale: 1.2,
                  opacity: 0,
                  z: -10
                }}
                animate={{ 
                  scale: 1.4,
                  opacity: 0.5,
                  z: -5
                }}
                transition={{ 
                  delay: 2.8,
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                NEXUS
              </motion.h1>
              
              {/* Main text */}
              <motion.h1
                className="text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-700 relative"
                style={{ transformStyle: "preserve-3d" }}
                initial={{ 
                  x: -1000,
                  rotateZ: -45,
                  opacity: 0,
                  scale: 0.5
                }}
                animate={{ 
                  x: 0,
                  rotateZ: 0,
                  opacity: 1,
                  scale: 1,
                  z: 30 // Give text a 3D position
                }}
                transition={{ 
                  delay: 2.6, 
                  duration: 0.8,
                  type: "spring",
                  stiffness: 100,
                  damping: 15
                }}
              >
                NEXUS
              </motion.h1>
            </motion.div>

            {/* Tagline */}
            <motion.p
              className="text-xl text-purple-200"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 3.2, duration: 0.5 }}
            >
              Connect with your community
            </motion.p>

            {/* Loading indicator */}
            <motion.div 
              className="mt-8 flex items-center justify-center gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 3.8, duration: 0.5 }}
            >
              {[0, 1, 2].map((i) => (
                <motion.div 
                  key={i}
                  className="h-2 w-2 rounded-full bg-purple-500"
                  animate={{ 
                    scale: [1, 1.5, 1],
                    opacity: [0.7, 1, 0.7]
                  }}
                  transition={{ 
                    duration: 0.8, 
                    repeat: Infinity, 
                    delay: i * 0.2,
                    ease: "easeInOut"
                  }}
                />
              ))}
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
