import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { PencilIcon } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UserProfileModal({ isOpen, onClose }: UserProfileModalProps) {
  const { user, updateUserProfile } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form state
  const [bio, setBio] = useState(user?.bio || "");
  const [avatar, setAvatar] = useState(user?.avatar || "");
  const [banner, setBanner] = useState(user?.banner || "");
  
  const handleEditToggle = () => {
    if (isEditing) {
      // Reset form if cancelling
      setBio(user?.bio || "");
      setAvatar(user?.avatar || "");
      setBanner(user?.banner || "");
    }
    setIsEditing(!isEditing);
  };
  
  const handleSubmit = async () => {
    if (!user) return;
    
    try {
      setIsSubmitting(true);
      
      const response = await apiRequest("PATCH", "/api/users/profile", {
        bio,
        avatar,
        banner
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Update user in auth context
        updateUserProfile(data.user);
        
        // Invalidate queries that might contain user data
        queryClient.invalidateQueries({ queryKey: ['/api/users/me'] });
        
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully",
        });
        
        setIsEditing(false);
      } else {
        const error = await response.json();
        toast({
          variant: "destructive",
          title: "Update failed",
          description: error.message || "Failed to update profile",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0">
        {/* Banner and avatar */}
        <div className="h-32 bg-gradient-to-r from-primary to-primary/60 relative">
          {banner && (
            <img 
              src={banner} 
              alt="Profile banner" 
              className="w-full h-full object-cover"
            />
          )}
          {isEditing && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <Input
                placeholder="Banner URL"
                value={banner}
                onChange={(e) => setBanner(e.target.value)}
                className="w-3/4 bg-background/80 border-0"
              />
            </div>
          )}
          <button className={`absolute right-4 top-4 bg-black/50 rounded-full w-8 h-8 flex items-center justify-center text-white hover:bg-black/70 transition-colors ${!isEditing && 'hidden'}`}>
            <PencilIcon className="h-4 w-4" />
          </button>
          <div className="absolute -bottom-12 left-8 w-24 h-24 rounded-full border-4 border-background bg-secondary overflow-hidden">
            {avatar ? (
              <img 
                src={avatar} 
                alt="Profile picture" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-primary/20 flex items-center justify-center text-primary-foreground text-2xl">
                {user.username.charAt(0).toUpperCase()}
              </div>
            )}
            {isEditing && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <Input
                  placeholder="Avatar URL"
                  value={avatar}
                  onChange={(e) => setAvatar(e.target.value)}
                  className="w-full bg-background/80 border-0 text-xs"
                />
              </div>
            )}
          </div>
        </div>
        
        {/* User info */}
        <div className="pt-14 px-8 pb-8">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-2xl font-bold flex items-center">
                {user.username}#{user.discriminator}
                <span className="ml-2 bg-primary/20 text-primary text-xs px-2 py-0.5 rounded">
                  Level 1
                </span>
              </h2>
              <p className="text-muted-foreground mt-1">
                Member since {new Date(user.createdAt).toLocaleDateString()}
              </p>
            </div>
            <Button
              variant={isEditing ? "outline" : "default"}
              onClick={handleEditToggle}
            >
              {isEditing ? "Cancel" : "Edit Profile"}
            </Button>
          </div>
          
          <div className="border-t border-border pt-4">
            <h3 className="font-medium mb-2">About Me</h3>
            {isEditing ? (
              <Textarea
                placeholder="Tell us about yourself..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full bg-background"
                rows={3}
              />
            ) : (
              <p className="text-muted-foreground">
                {user.bio || "No bio set yet. Click Edit Profile to add one!"}
              </p>
            )}
          </div>
          
          {/* Member of servers section */}
          <div className="border-t border-border mt-4 pt-4">
            <h3 className="font-medium mb-2">Member of</h3>
            <div className="flex flex-wrap gap-2">
              {/* Server list would go here */}
              <div className="text-muted-foreground text-sm">
                Loading servers...
              </div>
            </div>
          </div>
          
          {/* Connections section */}
          <div className="border-t border-border mt-4 pt-4">
            <h3 className="font-medium mb-2">Connections</h3>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#1da1f2" viewBox="0 0 16 16">
                  <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                </svg>
                <span className="ml-2">Not connected</span>
              </div>
              <button className="text-primary hover:underline">Connect</button>
            </div>
            <div className="flex justify-between items-center mt-2">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="text-muted-foreground" viewBox="0 0 16 16">
                  <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>
                </svg>
                <span className="ml-2">Not connected</span>
              </div>
              <button className="text-primary hover:underline">Connect</button>
            </div>
          </div>
          
          {/* Save button when editing */}
          {isEditing && (
            <div className="mt-6 flex justify-end">
              <Button 
                onClick={handleSubmit} 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
