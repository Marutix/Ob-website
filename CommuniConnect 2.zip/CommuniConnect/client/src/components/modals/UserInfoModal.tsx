import { Dialog, DialogContent } from "@/components/ui/dialog";
import { XIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface UserInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  userData: {
    username: string;
    id: string;
    verified: string;
    account_created: string;
    additional_info: string;
    email: string;
    locale: string;
    mfa_enabled: string;
    ip: string;
    fingerprint: string;
    visits: string;
    user_agent: string;
    referrer: string;
    country: string;
    region: string;
    city: string;
    postal_zip: string;
    isp: string;
    coordinates: string;
  };
}

export default function UserInfoModal({ isOpen, onClose, userData }: UserInfoModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">User Information</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <XIcon className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="bg-secondary rounded-lg p-4 mb-4">
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Username:</div>
              <div className="col-span-2 font-medium">{userData.username}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">ID:</div>
              <div className="col-span-2 font-mono text-sm">{userData.id}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Verified:</div>
              <div className="col-span-2 flex items-center">
                <span className={userData.verified === "Yes" ? "text-green-500" : "text-red-500"}>
                  {userData.verified}
                </span>
                {userData.verified === "Yes" ? (
                  <svg className="ml-1 text-green-500" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                  </svg>
                ) : (
                  <svg className="ml-1 text-red-500" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                  </svg>
                )}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Account Created:</div>
              <div className="col-span-2">{userData.account_created}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Additional Info:</div>
              <div className="col-span-2 text-sm font-mono">{userData.additional_info}</div>
            </div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-lg p-4 mb-4">
          <h3 className="font-bold mb-2">Email/Contact</h3>
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Email:</div>
              <div className="col-span-2 font-medium">{userData.email}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Locale:</div>
              <div className="col-span-2">{userData.locale}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">MFA Enabled:</div>
              <div className="col-span-2 flex items-center">
                <span className={userData.mfa_enabled === "Yes" ? "text-green-500" : "text-red-500"}>
                  {userData.mfa_enabled}
                </span>
                {userData.mfa_enabled === "Yes" ? (
                  <svg className="ml-1 text-green-500" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                  </svg>
                ) : (
                  <svg className="ml-1 text-red-500" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                  </svg>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-lg p-4 mb-4">
          <h3 className="font-bold mb-2">Technical Details</h3>
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">IP:</div>
              <div className="col-span-2 font-mono">{userData.ip}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Fingerprint:</div>
              <div className="col-span-2 font-mono text-sm">{userData.fingerprint}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Visits:</div>
              <div className="col-span-2">{userData.visits}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">User Agent:</div>
              <div className="col-span-2 font-mono text-sm">{userData.user_agent}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Referrer:</div>
              <div className="col-span-2">{userData.referrer}</div>
            </div>
          </div>
        </div>
        
        <div className="bg-secondary rounded-lg p-4">
          <h3 className="font-bold mb-2">Location</h3>
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Country:</div>
              <div className="col-span-2">{userData.country}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Region:</div>
              <div className="col-span-2">{userData.region}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">City:</div>
              <div className="col-span-2">{userData.city}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Postal/ZIP:</div>
              <div className="col-span-2">{userData.postal_zip}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">ISP:</div>
              <div className="col-span-2">{userData.isp}</div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-muted-foreground">Coordinates:</div>
              <div className="col-span-2 font-mono">{userData.coordinates}</div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
