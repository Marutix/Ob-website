import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { AuthContext } from "./AuthContext";
import { WebSocketEvent } from "@shared/types";

interface WebSocketContextType {
  connected: boolean;
  send: (event: WebSocketEvent) => void;
  events: WebSocketEvent[];
}

export const WebSocketContext = createContext<WebSocketContextType>({
  connected: false,
  send: () => {},
  events: [],
});

export function WebSocketProvider({ children }: { children: React.ReactNode }) {
  const { token, isAuthenticated } = useContext(AuthContext);
  const [connected, setConnected] = useState(false);
  const [events, setEvents] = useState<WebSocketEvent[]>([]);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const socketRef = useRef<WebSocket | null>(null);
  const maxReconnectAttempts = 3;

  useEffect(() => {
    // Don't try to connect if not authenticated
    if (!isAuthenticated || !token) {
      setConnected(false);
      return;
    }

    // Reset connection attempts when auth state changes
    setConnectionAttempts(0);

    const connectWebSocket = () => {
      try {
        // Check if we've exceeded max reconnect attempts
        if (connectionAttempts >= maxReconnectAttempts) {
          console.log(`WebSocket: Maximum reconnect attempts (${maxReconnectAttempts}) reached, stopping reconnection`);
          return;
        }

        // Update connection attempt counter
        setConnectionAttempts(prev => prev + 1);

        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`;
        
        console.log(`WebSocket: Connecting to ${wsUrl.split('?')[0]} (attempt ${connectionAttempts + 1}/${maxReconnectAttempts})`);
        
        const socket = new WebSocket(wsUrl);
        socketRef.current = socket;

        socket.onopen = () => {
          console.log("WebSocket: Connected successfully");
          setConnected(true);
          // Reset connection attempts on successful connection
          setConnectionAttempts(0);
        };

        socket.onclose = (event) => {
          console.log(`WebSocket: Disconnected with code ${event.code}, reason: ${event.reason}`);
          setConnected(false);
          
          // Only attempt to reconnect if we haven't reached the limit
          if (connectionAttempts < maxReconnectAttempts) {
            console.log(`WebSocket: Will attempt reconnection in 3 seconds...`);
            setTimeout(connectWebSocket, 3000);
          }
        };

        socket.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data) as WebSocketEvent;
            console.log("WebSocket: Message received:", data.type);
            
            // Add new event to our events array, but limit to last 100 events
            setEvents((prev) => [...prev.slice(-99), data]);
            
            // Handle specific events
            handleWebSocketEvent(data);
          } catch (error) {
            console.error("WebSocket: Error parsing message:", error);
          }
        };

        socket.onerror = (error) => {
          console.error("WebSocket: Connection error:", error);
        };
      } catch (error) {
        console.error("WebSocket: Setup error:", error);
      }
    };

    // Only try to connect if we're authenticated
    connectWebSocket();

    // Cleanup function
    return () => {
      if (socketRef.current) {
        console.log("WebSocket: Closing connection due to cleanup");
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, [isAuthenticated, token]);

  const handleWebSocketEvent = (event: WebSocketEvent) => {
    switch (event.type) {
      case "CONNECTED":
        console.log("Connected to WebSocket server");
        break;
      // Add other event handlers as needed
    }
  };

  const send = (event: WebSocketEvent) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(event));
    } else {
      console.warn("WebSocket not connected, cannot send message");
    }
  };

  const value = {
    connected,
    send,
    events,
  };

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
}
