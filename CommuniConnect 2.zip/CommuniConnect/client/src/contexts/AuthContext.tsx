import React, { createContext, useCallback, useEffect, useState } from "react";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: Error | null;
  login: (token: string, user: User) => void;
  logout: () => void;
  verificationEmail: string | null;
  setVerificationEmail: (email: string) => void;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
  login: () => {},
  logout: () => {},
  verificationEmail: null,
  setVerificationEmail: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [verificationEmail, setVerificationEmail] = useState<string | null>(null);

  useEffect(() => {
    const initializeAuth = async () => {
      // Check if token is stored in localStorage
      const storedToken = localStorage.getItem('token');
      
      // Handle no token case early
      if (!storedToken) {
        console.log('No token found in localStorage, skipping user fetch');
        setIsLoading(false);
        return;
      }
      
      try {
        console.log('Found token in localStorage, attempting to fetch user data');
        // Verify the token by attempting to decode it
        const tokenParts = storedToken.split('.');
        if (tokenParts.length !== 3) {
          console.error('Invalid token format');
          throw new Error('Invalid token format');
        }
        
        // Set token in state
        setToken(storedToken);
        
        // Fetch the user data
        await fetchUser(storedToken);
      } catch (err) {
        console.error('Auth initialization error:', err);
        // Token is invalid or user fetch failed
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
        setIsAuthenticated(false);
        setIsLoading(false);
      }
    };
    
    // Set a timeout to prevent infinite loading state
    const timeoutId = setTimeout(() => {
      if (isLoading) {
        console.log('Auth timeout reached - forcing loading state to false');
        setIsLoading(false);
        setError(new Error('Authentication timed out. Please try again.'));
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
        setIsAuthenticated(false);
      }
    }, 5000); // 5 second timeout
    
    // Initialize authentication
    initializeAuth();
    
    return () => clearTimeout(timeoutId);
  }, []);

  const fetchUser = async (authToken: string) => {
    console.log('Fetching user data with token...');
    try {
      // Make the API request with proper headers
      const response = await fetch('/api/users/me', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Accept': 'application/json',
        },
      });
      
      console.log(`User fetch response status: ${response.status}`);
      
      if (response.ok) {
        // Successfully fetched user data
        const userData = await response.json();
        console.log('User data retrieved successfully');
        
        // Update authentication state
        setUser(userData);
        setIsAuthenticated(true);
        setError(null);
      } else {
        // Handle error responses based on status code
        let errorMessage = 'Failed to authenticate';
        
        if (response.status === 401) {
          errorMessage = 'Your session has expired. Please log in again.';
        } else if (response.status === 403) {
          errorMessage = 'You do not have permission to access this resource.';
        } else if (response.status >= 500) {
          errorMessage = 'Server error. Please try again later.';
        }
        
        console.error(`Failed to fetch user: ${response.status} - ${errorMessage}`);
        
        try {
          // Try to get more detailed error from response
          const errorData = await response.json();
          if (errorData && errorData.message) {
            errorMessage = errorData.message;
          }
        } catch (parseError) {
          // Ignore JSON parsing errors
        }
        
        // Clear authentication state
        localStorage.removeItem('token');
        setToken(null);
        setUser(null);
        setIsAuthenticated(false);
        setError(new Error(errorMessage));
      }
    } catch (err) {
      // Handle network errors
      const errorMessage = err instanceof Error 
        ? err.message 
        : 'Failed to connect to the server. Please check your internet connection.';
      
      console.error('Error fetching user:', errorMessage);
      
      // Clear authentication state
      localStorage.removeItem('token');
      setToken(null);
      setUser(null);
      setIsAuthenticated(false);
      setError(new Error(errorMessage));
    } finally {
      setIsLoading(false);
    }
  };

  const login = useCallback((newToken: string, userData: User) => {
    localStorage.setItem('token', newToken);
    setToken(newToken);
    setUser(userData);
    setIsAuthenticated(true);
    setIsLoading(false);
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiRequest('POST', '/api/auth/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('token');
      setToken(null);
      setUser(null);
      setIsAuthenticated(false);
    }
  }, []);

  const value = {
    user,
    token,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    verificationEmail,
    setVerificationEmail,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
