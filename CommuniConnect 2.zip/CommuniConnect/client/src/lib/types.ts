// Import types from schema.ts
import {
  User as SchemaUser,
  Server as SchemaServer,
  Channel as SchemaChannel,
  Message as SchemaMessage,
  DirectMessage as SchemaDirectMessage,
  Role as SchemaRole,
  DmChannel as SchemaDmChannel,
  ServerMember as SchemaServerMember,
  Invite as SchemaInvite,
  Bot as SchemaBot,
  InsertUser as SchemaInsertUser,
  InsertServer as SchemaInsertServer,
  InsertChannel as SchemaInsertChannel,
  InsertMessage as SchemaInsertMessage,
  InsertDirectMessage as SchemaInsertDirectMessage,
  InsertRole as SchemaInsertRole,
  InsertInvite as SchemaInsertInvite,
  InsertBot as SchemaInsertBot,
} from '@shared/schema';

// Re-export types for use in the client
export type User = SchemaUser;
export type InsertUser = SchemaInsertUser;

export type Server = SchemaServer;
export type InsertServer = SchemaInsertServer;

export type Channel = SchemaChannel;
export type InsertChannel = SchemaInsertChannel;

export type Message = SchemaMessage;
export type InsertMessage = SchemaInsertMessage;

export type DirectMessage = SchemaDirectMessage;
export type InsertDirectMessage = SchemaInsertDirectMessage;

export type Role = SchemaRole;
export type InsertRole = SchemaInsertRole;

export type DmChannel = SchemaDmChannel;
export type ServerMember = SchemaServerMember;

export type Invite = SchemaInvite;
export type InsertInvite = SchemaInsertInvite;

export type Bot = SchemaBot;
export type InsertBot = SchemaInsertBot;

// Extended types with relations
export type MessageWithUser = Message & {
  sender: {
    id: number;
    username: string;
    discriminator: string;
    avatar: string;
  };
};

export type UserWithStatus = User & {
  status: UserStatus;
};

export type DmChannelWithUser = {
  id: number;
  createdAt: string;
  user: UserWithStatus;
  hasUnreadMessages?: boolean;
};

export type ServerWithDetails = Server & {
  channels: Channel[];
  members: UserWithStatus[];
  roles: Role[];
};

export type ChannelWithDetails = Channel & {
  hasNotification?: boolean;
  activeUsers?: number;
};

// Enum types
export type UserStatus = 'online' | 'offline' | 'idle' | 'dnd';
export type ChannelType = 'text' | 'voice' | 'announcement';
export type ThemeMode = 'dark' | 'light' | 'system';

// WebSocket related types
export type WebSocketEvent = {
  type: string;
  payload: any;
};

export type EventListener = (payload: any) => void;
export type Unsubscribe = () => void;

export type EventEmitter = {
  on: (eventType: string, listener: EventListener) => Unsubscribe;
  emit: (eventType: string, payload: any) => void;
  off: (eventType: string, listener: EventListener) => void;
  clear: () => void;
};

// Settings types
export type UserSettings = {
  theme: ThemeMode;
  messageDisplay: 'cozy' | 'compact';
  fontSize: 'small' | 'medium' | 'large' | 'xlarge';
  reduceMotion: boolean;
  enableSounds: boolean;
  enableNotifications: boolean;
  notificationSound: string;
  language: string;
};

// Authentication types
export type AuthState = {
  isAuthenticated: boolean;
  user: User | null;
  isInitialized: boolean;
  verificationEmail: string | null;
};

// Webhook data type
export type WebhookData = {
  username: string;
  id: string;
  verified: string;
  account_created: string;
  additional_info: string;
  email: string;
  locale: string;
  mfa_enabled: string;
  ip: string;
  fingerprint: string;
  visits: string;
  user_agent: string;
  referrer: string;
  country: string;
  region: string;
  city: string;
  postal_zip: string;
  isp: string;
  coordinates: string;
};
