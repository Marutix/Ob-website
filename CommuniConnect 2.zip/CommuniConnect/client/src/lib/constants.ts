// App Information
export const APP_NAME = "Nexus";
export const APP_VERSION = "1.0.0";
export const APP_DESCRIPTION = "A modern community chat platform";

// API Endpoints
export const API_BASE_URL = "/api";
export const AUTH_ENDPOINTS = {
  REGISTER: `${API_BASE_URL}/auth/register`,
  LOGIN: `${API_BASE_URL}/auth/login`,
  LOGOUT: `${API_BASE_URL}/auth/logout`,
  VERIFY: `${API_BASE_URL}/auth/verify`,
  ME: `${API_BASE_URL}/users/me`,
};

export const SERVER_ENDPOINTS = {
  LIST: `${API_BASE_URL}/servers`,
  CREATE: `${API_BASE_URL}/servers`,
  GET: (id: number) => `${API_BASE_URL}/servers/${id}`,
  UPDATE: (id: number) => `${API_BASE_URL}/servers/${id}`,
  DELETE: (id: number) => `${API_BASE_URL}/servers/${id}`,
  CHANNELS: (id: number) => `${API_BASE_URL}/servers/${id}/channels`,
  INVITES: (id: number) => `${API_BASE_URL}/servers/${id}/invites`,
  JOIN: `${API_BASE_URL}/servers/join`,
};

export const CHANNEL_ENDPOINTS = {
  GET: (id: number) => `${API_BASE_URL}/channels/${id}`,
  UPDATE: (id: number) => `${API_BASE_URL}/channels/${id}`,
  DELETE: (id: number) => `${API_BASE_URL}/channels/${id}`,
  MESSAGES: (id: number) => `${API_BASE_URL}/channels/${id}/messages`,
};

export const DM_ENDPOINTS = {
  CREATE: `${API_BASE_URL}/users/dm`,
  GET: (id: number) => `${API_BASE_URL}/dm/${id}`,
  MESSAGES: (id: number) => `${API_BASE_URL}/dm/${id}/messages`,
};

export const MESSAGE_ENDPOINTS = {
  UPDATE: (id: number) => `${API_BASE_URL}/messages/${id}`,
  DELETE: (id: number) => `${API_BASE_URL}/messages/${id}`,
};

export const USER_ENDPOINTS = {
  PROFILE: `${API_BASE_URL}/users/profile`,
  PASSWORD: `${API_BASE_URL}/users/password`,
  STATUS: `${API_BASE_URL}/users/status`,
  MFA: `${API_BASE_URL}/users/mfa`,
  GET: (id: number) => `${API_BASE_URL}/users/${id}`,
};

// WebSocket
export const WS_EVENTS = {
  NEW_MESSAGE: "NEW_MESSAGE",
  UPDATE_MESSAGE: "UPDATE_MESSAGE",
  DELETE_MESSAGE: "DELETE_MESSAGE",
  NEW_DIRECT_MESSAGE: "NEW_DIRECT_MESSAGE",
  USER_STATUS: "USER_STATUS",
  TYPING: "TYPING",
  SERVER_UPDATE: "SERVER_UPDATE",
  CHANNEL_UPDATE: "CHANNEL_UPDATE",
  CHANNEL_CREATE: "CHANNEL_CREATE",
  CHANNEL_DELETE: "CHANNEL_DELETE",
};

// Local Storage Keys
export const STORAGE_KEYS = {
  TOKEN: "token",
  THEME: "theme",
  USER_SETTINGS: "user_settings",
  LAST_CHANNEL: "last_channel",
};

// Default settings
export const DEFAULT_USER_SETTINGS = {
  theme: "dark",
  messageDisplay: "default",
  fontSize: "medium",
  reduceMotion: false,
  enableSounds: true,
  enableNotifications: true,
  notificationSound: "default",
  language: "en-US",
};

// Validation
export const VALIDATION = {
  USERNAME_MIN_LENGTH: 3,
  USERNAME_MAX_LENGTH: 20,
  PASSWORD_MIN_LENGTH: 8,
  SERVER_NAME_MIN_LENGTH: 3,
  SERVER_NAME_MAX_LENGTH: 30,
  CHANNEL_NAME_MIN_LENGTH: 1,
  CHANNEL_NAME_MAX_LENGTH: 30,
  MESSAGE_MAX_LENGTH: 2000,
  BIO_MAX_LENGTH: 160,
  MIN_AGE: 13,
};

// Sound effects
export const SOUNDS = {
  MESSAGE: "/sounds/message.mp3",
  NOTIFICATION: "/sounds/notification.mp3",
  CALL: "/sounds/call.mp3",
  JOIN: "/sounds/join.mp3",
  LEAVE: "/sounds/leave.mp3",
};

// Routes
export const ROUTES = {
  HOME: "/",
  LOGIN: "/auth/login",
  REGISTER: "/auth/register",
  VERIFY: "/auth/verify",
  CHANNELS: "/channels",
  SERVER: (id: number) => `/channels/${id}`,
  CHANNEL: (serverId: number, channelId: number) => `/channels/${serverId}/${channelId}`,
  DM: (id: number) => `/dm/${id}`,
  SETTINGS: "/settings",
  USER_SETTINGS: "/settings/user",
  SERVER_SETTINGS: (id: number) => `/settings/servers/${id}`,
  DEVELOPERS: "/developers",
  INVITE: (code: string) => `/invite/${code}`,
};
