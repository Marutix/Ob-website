import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  headers?: Record<string, string>,
): Promise<Response> {
  const defaultHeaders: Record<string, string> = data ? { "Content-Type": "application/json" } : {};
  
  // Add auth token to headers if available
  const token = localStorage.getItem('token');
  if (token) {
    defaultHeaders['Authorization'] = `Bearer ${token}`;
  }
  
  console.log(`${method} ${url} - Auth token:`, token ? 'Present' : 'Missing');
  
  const res = await fetch(url, {
    method,
    headers: { ...defaultHeaders, ...headers },
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    try {
      // Add auth token to headers if available
      const headers: Record<string, string> = {};
      const token = localStorage.getItem('token');
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      console.log(`GET ${queryKey[0]} - Auth token:`, token ? 'Present' : 'Missing');
      
      // Make the request
      const res = await fetch(queryKey[0] as string, {
        method: 'GET',
        credentials: "include",
        headers
      });
      
      console.log(`Response status for ${queryKey[0]}: ${res.status}`);
      
      // Handle 401 according to configuration
      if (unauthorizedBehavior === "returnNull" && res.status === 401) {
        console.log(`GET ${queryKey[0]} returned 401, returning null as configured`);
        return null;
      }
      
      // Throw for other errors
      if (!res.ok) {
        const errorText = await res.text();
        console.error(`Error fetching ${queryKey[0]}: ${res.status}`, errorText);
        throw new Error(`${res.status}: ${errorText || res.statusText}`);
      }
      
      // Parse and return the JSON response
      const data = await res.json();
      return data;
    } catch (error) {
      console.error(`Query error for ${queryKey[0]}:`, error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
