import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { SplashScreen } from "@/components/SplashScreen";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [, setLocation] = useLocation();
  
  // Check if this is the initial load
  useEffect(() => {
    const hasVisited = sessionStorage.getItem('hasVisitedNexus');
    if (hasVisited) {
      // Skip splash screen for returning visitors in this session
      setShowSplash(false);
    } else {
      // Mark as visited
      sessionStorage.setItem('hasVisitedNexus', 'true');
      // Auto redirect after splash - allow enough time for the full animation
      const timer = setTimeout(() => {
        setLocation('/auth/login');
      }, 4500); // Extended time to fully appreciate the animation
      return () => clearTimeout(timer);
    }
  }, [setLocation]);

  // Show splash screen on initial visit
  if (showSplash) {
    return <SplashScreen setShowSplash={setShowSplash} />
  }

  // Regular home page content
  return (
    <motion.div 
      className="min-h-screen bg-background flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <header className="border-b py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <svg 
              className="w-8 h-8" 
              viewBox="0 0 100 100" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="headerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#9333EA" />
                  <stop offset="100%" stopColor="#7C3AED" />
                </linearGradient>
              </defs>
              <polygon 
                points="50,10 85,30 85,70 50,90 15,70 15,30" 
                fill="url(#headerGradient)" 
                stroke="#8B5CF6"
                strokeWidth="2"
              />
              <path 
                d="M35,35 L50,65 L65,35" 
                fill="none"
                stroke="white"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="35" cy="35" r="5" fill="white" />
              <circle cx="50" cy="65" r="5" fill="white" />
              <circle cx="65" cy="35" r="5" fill="white" />
            </svg>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-purple-700">Nexus</h1>
          </div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <Button asChild>
                <Link href="/channels">Open Nexus</Link>
              </Button>
            ) : (
              <>
                <Button variant="outline" asChild>
                  <Link href="/auth/login">Login</Link>
                </Button>
                <Button asChild>
                  <Link href="/auth/register">Register</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold mb-6"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            Welcome to Nexus
          </motion.h2>
          <motion.p 
            className="text-xl mb-8 text-muted-foreground"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            A modern communication platform for communities and friends.
          </motion.p>
          
          {!isAuthenticated && (
            <motion.div 
              className="flex justify-center gap-4"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <Button size="lg" asChild>
                <Link href="/auth/register">Sign Up</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/auth/login">Sign In</Link>
              </Button>
            </motion.div>
          )}
        </div>
      </main>
    </motion.div>
  );
}
