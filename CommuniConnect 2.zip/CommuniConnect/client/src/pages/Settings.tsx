import { useRoute } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function Settings() {
  const [, params] = useRoute("/settings/:page");
  const activePage = params?.page || "account";

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <Card className="mx-auto max-w-4xl">
        <CardHeader>
          <CardTitle>User Settings</CardTitle>
          <CardDescription>
            Manage your account settings and preferences
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={activePage} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="account">Account</TabsTrigger>
              <TabsTrigger value="appearance">Appearance</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
            </TabsList>
            <TabsContent value="account" className="p-4">
              <h3 className="text-lg font-medium">Account Settings</h3>
              <p className="text-muted-foreground mt-2">
                Account settings will be implemented here
              </p>
            </TabsContent>
            <TabsContent value="appearance" className="p-4">
              <h3 className="text-lg font-medium">Appearance Settings</h3>
              <p className="text-muted-foreground mt-2">
                Appearance settings will be implemented here
              </p>
            </TabsContent>
            <TabsContent value="notifications" className="p-4">
              <h3 className="text-lg font-medium">Notification Settings</h3>
              <p className="text-muted-foreground mt-2">
                Notification settings will be implemented here
              </p>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
