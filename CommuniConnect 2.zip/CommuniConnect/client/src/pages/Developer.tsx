import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Developer() {
  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <Card className="mx-auto max-w-4xl">
        <CardHeader>
          <CardTitle>Developer Portal</CardTitle>
          <CardDescription>
            Create and manage bots and applications for Nexus
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="applications" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="applications">Applications</TabsTrigger>
              <TabsTrigger value="documentation">Documentation</TabsTrigger>
            </TabsList>
            <TabsContent value="applications" className="p-4">
              <h3 className="text-lg font-medium">Your Applications</h3>
              <p className="text-muted-foreground mt-2">
                You haven't created any applications yet.
              </p>
              <div className="mt-4 p-6 border rounded-md flex items-center justify-center">
                <p className="text-center text-muted-foreground">
                  Application creation will be implemented here
                </p>
              </div>
            </TabsContent>
            <TabsContent value="documentation" className="p-4">
              <h3 className="text-lg font-medium">API Documentation</h3>
              <p className="text-muted-foreground mt-2">
                Learn how to build bots and applications with our API
              </p>
              <div className="mt-4 p-6 border rounded-md">
                <p className="text-center text-muted-foreground">
                  API documentation will be displayed here
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
