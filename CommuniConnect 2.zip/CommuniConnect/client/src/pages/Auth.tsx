import { useRoute } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { LoginForm } from "@/components/auth/login-form";
import { RegisterForm } from "@/components/auth/register-form";
import { VerificationForm } from "@/components/auth/verification-form";
import { PasswordResetForm } from "@/components/auth/password-reset-form";
import { useAuth } from "@/hooks/useAuth";
import { Redirect } from "wouter";

export default function Auth() {
  const [, params] = useRoute("/auth/:type");
  const authType = params?.type || "login";
  const { isAuthenticated } = useAuth();

  // Redirect to channels if already authenticated
  if (isAuthenticated) {
    return <Redirect to="/channels" />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="flex min-h-screen">
        <div className="flex flex-col justify-center w-full md:w-1/2 p-4 md:p-10">
          <div className="flex justify-center mb-6">
            <svg 
              className="w-16 h-16" 
              viewBox="0 0 100 100" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="formLogoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#9333EA" />
                  <stop offset="100%" stopColor="#7C3AED" />
                </linearGradient>
              </defs>
              <polygon 
                points="50,10 85,30 85,70 50,90 15,70 15,30" 
                fill="url(#formLogoGradient)" 
                stroke="#8B5CF6"
                strokeWidth="2"
              />
              <path 
                d="M35,35 L50,65 L65,35" 
                fill="none"
                stroke="white"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="35" cy="35" r="5" fill="white" />
              <circle cx="50" cy="65" r="5" fill="white" />
              <circle cx="65" cy="35" r="5" fill="white" />
            </svg>
          </div>
          <Card className="w-full max-w-md mx-auto">
            <CardContent className="pt-6">
              {authType === "register" && <RegisterForm />}
              {authType === "login" && <LoginForm />}
              {authType === "verify" && <VerificationForm />}
              {authType === "reset-password" && <PasswordResetForm />}
            </CardContent>
          </Card>
        </div>

        {/* Right hero section - hidden on mobile */}
        <div className="hidden md:flex md:w-1/2 bg-gradient-to-r from-primary/20 to-primary/30 flex-col justify-center items-center p-10">
          <div className="max-w-md">
            <div className="flex items-center gap-4 mb-6">
              <svg 
                className="w-12 h-12" 
                viewBox="0 0 100 100" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#9333EA" />
                    <stop offset="100%" stopColor="#7C3AED" />
                  </linearGradient>
                </defs>
                <polygon 
                  points="50,10 85,30 85,70 50,90 15,70 15,30" 
                  fill="url(#heroGradient)" 
                  stroke="#8B5CF6"
                  strokeWidth="2"
                />
                <path 
                  d="M35,35 L50,65 L65,35" 
                  fill="none"
                  stroke="white"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <circle cx="35" cy="35" r="5" fill="white" />
                <circle cx="50" cy="65" r="5" fill="white" />
                <circle cx="65" cy="35" r="5" fill="white" />
              </svg>
              <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-purple-700">Nexus</h1>
            </div>
            <p className="text-xl mb-6">Connect with friends and communities in real-time.</p>
            <ul className="space-y-2">
              <li className="flex items-center">✓ Real-time messaging</li>
              <li className="flex items-center">✓ Voice & video channels</li>
              <li className="flex items-center">✓ Private servers</li>
              <li className="flex items-center">✓ Custom themes</li>
              <li className="flex items-center">✓ Bot integration</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
