import { useRoute } from "wouter";

export default function Chat() {
  const [,params] = useRoute("/channels/:serverId/:channelId");
  const [isDmRoute] = useRoute("/dm/:dmId");
  
  return (
    <div className="h-screen flex flex-col bg-background">
      <div className="flex-1 flex">
        {/* Sidebar */}
        <div className="w-64 bg-muted border-r h-full">
          <div className="p-4 font-semibold">Server List</div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Channel Header */}
          <header className="h-14 border-b flex items-center px-4">
            <h2 className="font-semibold">
              {isDmRoute ? "Direct Message" : `Channel: ${params?.channelId || 'general'}`}
            </h2>
          </header>
          
          {/* Message Area */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="text-center text-muted-foreground">
              <p>Message content will be displayed here</p>
            </div>
          </div>
          
          {/* Message Input */}
          <div className="px-4 pb-4">
            <div className="border rounded-md p-2 bg-muted/30">
              <p className="text-center text-muted-foreground">Message input will go here</p>
            </div>
          </div>
        </div>
        
        {/* Right Sidebar (Members) */}
        <div className="w-64 bg-muted border-l h-full">
          <div className="p-4 font-semibold">Members</div>
        </div>
      </div>
    </div>
  );
}
