import { Route, Switch, Redirect } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Auth from "@/pages/Auth";
import Chat from "@/pages/Chat";
import Settings from "@/pages/Settings";
import Developer from "@/pages/Developer";
import { useAuth } from "./hooks/useAuth";
import { Loader2 } from "lucide-react";

function App() {
  const { error, user } = useAuth();

  // Skip loading and directly render the app
  // Auth state will be determined later
  
  if (error) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background flex-col gap-4">
        <div className="text-destructive text-center max-w-md p-4 border rounded-lg shadow-sm">
          <h2 className="text-xl font-bold mb-2">Error Loading Application</h2>
          <p className="mb-2">{error.message}</p>
          <p className="text-sm text-muted-foreground mb-4">
            This may be due to authentication issues or server connectivity problems.
          </p>
          <div className="flex gap-2 justify-center">
            <button 
              onClick={() => {
                localStorage.removeItem('token');
                window.location.reload();
              }}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
            >
              Reset and Reload
            </button>
            <button 
              onClick={() => {
                window.location.href = '/auth/login';
              }}
              className="px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/90"
            >
              Go to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Determine if user is authenticated based on user object existence
  const isAuthenticated = !!user;

  return (
    <TooltipProvider>
      <Switch>
        {/* Public routes that don't require authentication */}
        <Route path="/" component={Home} />
        <Route path="/auth" component={Auth} />
        <Route path="/auth/:type" component={Auth} />
        
        {/* Protected routes that require authentication */}
        <Route path="/channels">
          {isAuthenticated ? <Chat /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/channels/:serverId">
          {isAuthenticated ? <Chat /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/channels/:serverId/:channelId">
          {isAuthenticated ? <Chat /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/dm/:dmId">
          {isAuthenticated ? <Chat /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/settings">
          {isAuthenticated ? <Settings /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/settings/:page">
          {isAuthenticated ? <Settings /> : <Redirect to="/auth/login" />}
        </Route>
        <Route path="/developers">
          {isAuthenticated ? <Developer /> : <Redirect to="/auth/login" />}
        </Route>
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
