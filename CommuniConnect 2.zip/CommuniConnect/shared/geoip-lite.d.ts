declare module 'geoip-lite' {
  interface GeoData {
    range: [number, number];
    country: string;
    region: string;
    eu: string;
    timezone: string;
    city: string;
    ll: [number, number]; // latitude, longitude
    metro: number;
    area: number;
    zip?: string;
  }

  export function lookup(ip: string): GeoData | null;
}
