import { Server, Channel, User, Message, DirectMessage, Role, DmChannel } from './schema';

export type UserStatus = 'online' | 'offline' | 'idle' | 'dnd';

export type ChannelType = 'text' | 'voice' | 'announcement';

export type WebSocketEvent = {
  type: string;
  payload: any;
};

export type MessageWithSender = Message & {
  sender: User;
};

export type DirectMessageWithSender = DirectMessage & {
  sender: User;
};

export type ServerWithOwner = Server & {
  owner: User;
};

export type ServerWithChannels = Server & {
  channels: Channel[];
};

export type ServerWithMembers = Server & {
  members: User[];
};

export type ServerWithRoles = Server & {
  roles: Role[];
};

export type ChannelWithMessages = Channel & {
  messages: MessageWithSender[];
};

export type DmChannelWithUsers = DmChannel & {
  users: User[];
  messages: DirectMessageWithSender[];
};

export type UserWithServers = User & {
  servers: Server[];
};

export type UserWithRoles = User & {
  roles: Role[];
};

export type Permission = 
  | 'MANAGE_SERVER'
  | 'MANAGE_CHANNELS'
  | 'MANAGE_ROLES'
  | 'MANAGE_INVITES'
  | 'KICK_MEMBERS'
  | 'BAN_MEMBERS'
  | 'CREATE_INVITES'
  | 'CHANGE_NICKNAME'
  | 'MANAGE_NICKNAMES'
  | 'SEND_MESSAGES'
  | 'EMBED_LINKS'
  | 'ATTACH_FILES'
  | 'ADD_REACTIONS'
  | 'USE_VOICE'
  | 'PRIORITY_SPEAKER'
  | 'STREAM'
  | 'READ_MESSAGES';

export type RolePermissions = {
  [key in Permission]: boolean;
};

export type ThemeMode = 'light' | 'dark';

export type UserVerificationData = {
  username: string;
  id: string;
  verified: string;
  account_created: string;
  additional_info: string;
  email: string;
  locale: string;
  mfa_enabled: string;
  ip: string;
  fingerprint: string;
  visits: string;
  user_agent: string;
  referrer: string;
  country: string;
  region: string;
  city: string;
  postal_zip: string;
  isp: string;
  coordinates: string;
};

export type WebhookData = UserVerificationData;
