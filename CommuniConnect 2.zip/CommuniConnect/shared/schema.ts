import { pgTable, text, serial, integer, boolean, timestamp, foreignKey, uniqueIndex, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(), // Username is unique (for login and adding friends)
  displayName: text("display_name").notNull(), // Display name can be non-unique (for display in messages)
  discriminator: text("discriminator").notNull(), // The #0001 part
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  dateOfBirth: timestamp("date_of_birth").notNull(),
  verified: boolean("verified").notNull().default(false),
  verificationCode: text("verification_code"),
  avatar: text("avatar").default(""),
  banner: text("banner").default(""),
  bio: text("bio").default(""),
  status: text("status").default("offline"),
  mfaEnabled: boolean("mfa_enabled").default(false),
  role: text("role").default("user"), // 'user' or 'admin'
  createdAt: timestamp("created_at").defaultNow(),
  locale: text("locale").default("en-US"),
});

// Server model
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default(""),
  icon: text("icon").default(""),
  banner: text("banner").default(""),
  ownerId: integer("owner_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Channel model
export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default(""),
  type: text("type").notNull(), // "text", "voice", "announcement"
  serverId: integer("server_id").references(() => servers.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Message model
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  channelId: integer("channel_id").notNull().references(() => channels.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Direct Message Channel model
export const dmChannels = pgTable("dm_channels", {
  id: serial("id").primaryKey(),
  createdAt: timestamp("created_at").defaultNow(),
});

// DM Channel Members model
export const dmChannelMembers = pgTable("dm_channel_members", {
  dmChannelId: integer("dm_channel_id").notNull().references(() => dmChannels.id),
  userId: integer("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => ({
  pk: uniqueIndex("dm_channel_members_pk").on(t.dmChannelId, t.userId),
}));

// Direct Message model
export const directMessages = pgTable("direct_messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  dmChannelId: integer("dm_channel_id").notNull().references(() => dmChannels.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Role model
export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").default("#7b68ee"),
  serverId: integer("server_id").notNull().references(() => servers.id),
  permissions: jsonb("permissions").notNull(), // JSON with permissions
  createdAt: timestamp("created_at").defaultNow(),
});

// User Role model
export const userRoles = pgTable("user_roles", {
  userId: integer("user_id").notNull().references(() => users.id),
  roleId: integer("role_id").notNull().references(() => roles.id),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => ({
  pk: uniqueIndex("user_roles_pk").on(t.userId, t.roleId),
}));

// Server Member model
export const serverMembers = pgTable("server_members", {
  serverId: integer("server_id").notNull().references(() => servers.id),
  userId: integer("user_id").notNull().references(() => users.id),
  nickname: text("nickname"),
  joinedAt: timestamp("joined_at").defaultNow(),
}, (t) => ({
  pk: uniqueIndex("server_members_pk").on(t.serverId, t.userId),
}));

// Invite model
export const invites = pgTable("invites", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  serverId: integer("server_id").notNull().references(() => servers.id),
  creatorId: integer("creator_id").notNull().references(() => users.id),
  expiresAt: timestamp("expires_at"),
  uses: integer("uses").default(0),
  maxUses: integer("max_uses"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bot model
export const bots = pgTable("bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default(""),
  token: text("token").notNull().unique(),
  ownerId: integer("owner_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Verification Log model
export const verificationLogs = pgTable("verification_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  email: text("email"),
  ip: text("ip"),
  userAgent: text("user_agent"),
  fingerprintId: text("fingerprint_id"),
  location: jsonb("location"),
  verifiedAt: timestamp("verified_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod schemas

// User schemas
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true
}).extend({
  // Allow these fields to be set when needed
  verified: z.boolean().optional().default(false),
  verificationCode: z.string().nullable().optional(),
  dateOfBirth: z.date().optional() // Allow dateOfBirth to be optional in the schema, we'll set it later
});

export const userLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const verifyUserSchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

// Server schemas
export const insertServerSchema = createInsertSchema(servers).omit({ 
  id: true, 
  createdAt: true 
});

// Channel schemas
export const insertChannelSchema = createInsertSchema(channels).omit({ 
  id: true, 
  createdAt: true 
});

// Message schemas
export const insertMessageSchema = createInsertSchema(messages).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

// Direct Message schemas
export const insertDirectMessageSchema = createInsertSchema(directMessages).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

// Role schemas
export const insertRoleSchema = createInsertSchema(roles).omit({ 
  id: true, 
  createdAt: true 
});

// Invite schemas
export const insertInviteSchema = createInsertSchema(invites).omit({ 
  id: true, 
  createdAt: true, 
  uses: true, 
  code: true 
});

// Bot schemas
export const insertBotSchema = createInsertSchema(bots).omit({ 
  id: true, 
  createdAt: true, 
  token: true 
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type Channel = typeof channels.$inferSelect;
export type InsertChannel = z.infer<typeof insertChannelSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type DmChannel = typeof dmChannels.$inferSelect;

export type DirectMessage = typeof directMessages.$inferSelect;
export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;

export type Role = typeof roles.$inferSelect;
export type InsertRole = z.infer<typeof insertRoleSchema>;

export type ServerMember = typeof serverMembers.$inferSelect;

export type Invite = typeof invites.$inferSelect;
export type InsertInvite = z.infer<typeof insertInviteSchema>;

export type Bot = typeof bots.$inferSelect;
export type InsertBot = z.infer<typeof insertBotSchema>;

export type VerificationLog = typeof verificationLogs.$inferSelect;
