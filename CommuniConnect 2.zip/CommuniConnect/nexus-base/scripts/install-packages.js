/**
 * Package Installation Script
 * 
 * This script automatically installs packages from the package-list.json file
 * located in the packages directory.
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Path to the package list file
const packageListPath = path.join(__dirname, '..', 'packages', 'package-list.json');

// Check if package list exists
if (!fs.existsSync(packageListPath)) {
  console.error('Error: package-list.json not found in packages directory');
  process.exit(1);
}

// Read package list
const packageList = JSON.parse(fs.readFileSync(packageListPath, 'utf8'));

// Available package types
const packageTypes = Object.keys(packageList);

// Function to install packages
async function installPackages(type, isDev = false) {
  if (!packageList[type] || !packageList[type].length) {
    console.log(`No ${type} packages to install.`);
    return;
  }

  const packages = packageList[type].join(' ');
  const command = `npm install ${isDev ? '--save-dev' : '--save'} ${packages}`;
  
  console.log(`\nInstalling ${type} packages:\n${packageList[type].join(', ')}\n`);
  
  return new Promise((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error installing ${type} packages:`, error);
        return reject(error);
      }
      console.log(`✅ Successfully installed ${type} packages`);
      resolve();
    });
  });
}

// Main function to run package installation
async function main() {
  try {
    console.log('📦 Starting package installation...');
    
    // Install server packages
    if (packageList.server) {
      await installPackages('server');
    }
    
    // Install client packages
    if (packageList.client) {
      await installPackages('client');
    }
    
    // Install dev tools
    if (packageList.devTools) {
      await installPackages('devTools', true);
    }
    
    console.log('\n✨ All packages installed successfully! ✨');
  } catch (error) {
    console.error('❌ Package installation failed:', error);
    process.exit(1);
  }
}

// Run the installation
main();
